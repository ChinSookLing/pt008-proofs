from fractions import Fraction as F
from itertools import combinations
from math import ceil

def vertices(inequalities, dim):
    result = set()
    for active in combinations(inequalities, dim):
        rows = [list(map(F, a)) + [F(b)] for a, b in active]
        for j in range(dim):
            pivot = next((i for i in range(j, dim) if rows[i][j]), None)
            if pivot is None:
                break
            rows[j], rows[pivot] = rows[pivot], rows[j]
            d = rows[j][j]
            rows[j] = [x/d for x in rows[j]]
            for i in range(dim):
                if i != j:
                    f = rows[i][j]
                    rows[i] = [x-f*y for x,y in zip(rows[i],rows[j])]
        else:
            v = tuple(r[-1] for r in rows)
            if all(sum(x*y for x,y in zip(a,v))>=b for a,b in inequalities):
                result.add(v)
    return result

expected = {6:744,7:4630,8:246,9:728,10:289,11:521,12:332,13:540}
for Z, target in expected.items():
    S = F(4*Z,9) - Z%2
    common = [((-1,2,0),0),((0,-1,2),0),((0,0,-1),-2),((1,1,1),S)]
    cap = F(Z**4,21609)
    high = vertices(common+[((1,0,0),F(1,2))],3)
    high_min = min(a*b*c for a,b,c in high)
    use_half = high_min > cap
    products = []
    for weight, threshold in [(3,S)]+([(1,S-F(1,2))] if use_half else []):
        lower = vertices([((-1,2),0),((0,-1),-2),((1,0),0),((0,1),0),
                          ((weight,1),threshold)],2)
        products.append(min(b*c for b,c in lower))
    min_product = max(products)
    upper = Z**3/min_product
    bound = ceil(upper)-1
    assert bound <= target, (Z,bound,target)
    print(Z, 'sum threshold', S, 'exclude beta1>=1/2',use_half,'minimum product', min_product,
          'strict upper D', upper, 'integer Dmax',bound)
