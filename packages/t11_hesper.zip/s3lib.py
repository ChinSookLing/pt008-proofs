import numpy as np, numba as nb
@nb.njit(parallel=True,cache=True)
def centre_search(Mrows, Y, D):
    # first candidate (margin-desc order) y/d with M.y ≡ 0 (mod d) for all 3 rows; -1 if none (d<=12)
    n=Mrows.shape[0]; out=np.full(n,-1,np.int64); K=Y.shape[0]
    for p in nb.prange(n):
        for c in range(K):
            d=D[c]; ok=True
            for r in range(3):
                s=0
                for j in range(5): s+=Mrows[p,r,j]*Y[c,j]
                if s%d!=0:
                    ok=False;break
            if ok:
                out[p]=c;break
    return out
