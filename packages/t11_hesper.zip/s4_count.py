import numpy as np,numba as nb,time
from s4lib import plane_resid,kernel_basis
c=np.load('cands12.npz');MNc,MDc=c['MN'],c['MD']
u=np.load('union.npz');M=u['M'].astype(np.int64);Dg=u['D'];ci=np.load('centre_idx.npy')
ok=np.nonzero(ci>=0)[0]
# sanity: kernel basis on sample
rng=np.random.default_rng(1)
for p in rng.choice(ok,2000,replace=False):
    b1,b2=kernel_basis(M[p]); assert (M[p]@b1==0).all() and (M[p]@b2==0).all()
    G=np.array([[b1@b1,b1@b2],[b1@b2,b2@b2]]); assert G[0,0]*G[1,1]-G[0,1]**2==Dg[p],(p,)
print('kernel ok')
@nb.njit(parallel=True)
def countall(M,Dg,MN,MD,idx):
    out=np.zeros(len(idx),np.int64); dummy=np.zeros((1,7),np.int64)
    for k in nb.prange(len(idx)):
        p=idx[k]; c,f,b=plane_resid(M[p],MN[k],MD[k],Dg[p],0,dummy,0); out[k]=c
    return out
t=time.time()
cnt=countall(M,Dg,MNc[ci[ok]],MDc[ci[ok]],ok)
np.save('resid_count.npy',cnt)
print('planes with resid',int((cnt>0).sum()),'total resid U',int(cnt.sum()),'max/plane',int(cnt.max()),round(time.time()-t))
import collections
m=MNc[ci[ok]]/MDc[ci[ok]]
for v in sorted(set(np.round(m,5)),reverse=True)[:12]:
    s=np.isclose(m,v); print(round(v,5),int(s.sum()),int(cnt[s].sum()))
