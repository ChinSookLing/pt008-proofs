import numpy as np, numba as nb
TAIL=21609
@nb.njit(cache=True)
def kernel_basis(Mr):
    # 5 generalized cross products (omit column o) span Λ = ker(M) ∩ Z^5 when M saturated; reduce to 2 rows by integer elimination
    V=np.zeros((5,5),np.int64)
    for o in range(5):
        cols=np.empty(4,np.int64);k=0
        for c in range(5):
            if c!=o: cols[k]=c;k+=1
        for r in range(4):
            sub=np.empty(3,np.int64);kk=0
            for q in range(4):
                if q!=r: sub[kk]=cols[q];kk+=1
            a=Mr[0,sub[0]];b=Mr[0,sub[1]];c_=Mr[0,sub[2]]
            d=Mr[1,sub[0]];e=Mr[1,sub[1]];f=Mr[1,sub[2]]
            g=Mr[2,sub[0]];h=Mr[2,sub[1]];i=Mr[2,sub[2]]
            det=a*(e*i-f*h)-b*(d*i-f*g)+c_*(d*h-e*g)
            V[o,cols[r]]=det if r%2==0 else -det
    # integer row reduction
    rows=5; piv=0
    for col in range(5):
        while True:
            # find smallest nonzero |V[r,col]| among r>=piv
            best=-1
            for r in range(piv,rows):
                if V[r,col]!=0 and (best<0 or abs(V[r,col])<abs(V[best,col])): best=r
            if best<0: break
            for j in range(5):
                tmp=V[piv,j];V[piv,j]=V[best,j];V[best,j]=tmp
            done=True
            for r in range(piv+1,rows):
                if V[r,col]!=0:
                    q=V[r,col]//V[piv,col]
                    for j in range(5): V[r,j]-=q*V[piv,j]
                    if V[r,col]!=0: done=False
            if done:
                piv+=1;break
        if piv==2: break
    b1=V[0].copy();b2=V[1].copy()
    # Lagrange reduce
    while True:
        n1=0;n2=0;dt=0
        for j in range(5): n1+=b1[j]*b1[j];n2+=b2[j]*b2[j];dt+=b1[j]*b2[j]
        if n2<n1:
            t=b1;b1=b2;b2=t;tn=n1;n1=n2;n2=tn
        q=int(np.floor(dt/n1+0.5)) if n1>0 else 0
        if q==0: break
        for j in range(5): b2[j]-=q*b1[j]
    return b1,b2
@nb.njit(cache=True)
def gcd(a,b):
    a=abs(a);b=abs(b)
    while b: a,b=b,a%b
    return a
@nb.njit(cache=True)
def nondeg(U):
    for i in range(5):
        if U[i]==0: return False
        for j in range(i):
            if abs(U[i])==abs(U[j]): return False
    return True
@nb.njit(cache=True)
def witness(U):
    # first safe endpoint t=(6n±1)/(6V_j) in (0,1), closed condition ||V_i t||>=1/6 for all i; returns (num,den,strict) or (-1,0,0)
    V=np.abs(U)
    for j in range(5):
        den=6*V[j]
        for n in range(V[j]):
            for s in (-1,1):
                num=6*n+s
                if num<=0: continue
                ok=True;strict=True
                for i in range(5):
                    r=(num*V[i])%den; d=min(r,den-r)
                    if d<V[j]: ok=False;break
                    if d==V[j]: strict=False
                if ok: return num,den,strict
    return -1,0,False
@nb.njit(cache=True)
def plane_resid(Mr,MN,MD,Dg,mode,out,outpos):
    # enumerate primitive U in Λ (mod ±) with TAIL<=|U|^2 and 4 MN^2 |U|^2 < MD^2 Dg, nondegenerate.
    # mode 0: count only; mode 1: write (U, num, den) rows into out starting at outpos. returns (count, fails, boundary_only)
    b1,b2=kernel_basis(Mr)
    g11=0;g12=0;g22=0
    for j in range(5): g11+=b1[j]*b1[j];g12+=b1[j]*b2[j];g22+=b2[j]*b2[j]
    det=g11*g22-g12*g12
    lhs=MD*MD*Dg  # condition 4 MN^2 |U|^2 < lhs
    Bf=lhs/(4.0*MN*MN)
    if Bf<=TAIL: return 0,0,0
    bmax=int(np.sqrt(Bf*g11/det))+1
    cnt=0;fails=0;bnd=0
    U=np.zeros(5,np.int64)
    for be in range(0,bmax+1):
        # alpha range: g11 a^2 + 2 g12 a be + g22 be^2 < Bf
        disc=(g12*g12-g11*g22)*be*be+g11*Bf
        if disc<0: continue
        c0=-g12*be/g11; w=np.sqrt(disc)/g11
        alo=int(np.floor(c0-w))-1; ahi=int(np.ceil(c0+w))+1
        for al in range(alo,ahi+1):
            if be==0 and al<=0: continue
            if gcd(al,be)!=1: continue
            n2=0
            for j in range(5):
                U[j]=al*b1[j]+be*b2[j]; n2+=U[j]*U[j]
            if n2<TAIL or 4*MN*MN*n2>=lhs: continue
            if not nondeg(U): continue
            cnt+=1
            if mode==1:
                num,den,st=witness(U)
                if num<0: fails+=1
                elif not st: bnd+=1
                k=outpos+cnt-1
                for j in range(5): out[k,j]=U[j]
                out[k,5]=num;out[k,6]=den
    return cnt,fails,bnd
MASK=(1<<61)-1
@nb.njit(cache=True)
def mix(h,x):
    h=(h*1000003+ (x & 0xFFFFFFFF)) & MASK
    return h
@nb.njit(cache=True)
def plane_witness(Mr,MN,MD,Dg,FA,fpos):
    # witness every residual U; returns cnt, fails, boundary_only, fingerprint; failing U written to FA
    b1,b2=kernel_basis(Mr)
    g11=0;g12=0;g22=0
    for j in range(5): g11+=b1[j]*b1[j];g12+=b1[j]*b2[j];g22+=b2[j]*b2[j]
    det=g11*g22-g12*g12; lhs=MD*MD*Dg; Bf=lhs/(4.0*MN*MN)
    if Bf<=TAIL: return 0,0,0,0
    bmax=int(np.sqrt(Bf*g11/det))+1
    cnt=0;fails=0;bnd=0;h=0
    U=np.zeros(5,np.int64)
    for be in range(0,bmax+1):
        disc=(g12*g12-g11*g22)*be*be+g11*Bf
        if disc<0: continue
        c0=-g12*be/g11; w=np.sqrt(disc)/g11
        for al in range(int(np.floor(c0-w))-1,int(np.ceil(c0+w))+2):
            if be==0 and al<=0: continue
            if gcd(al,be)!=1: continue
            n2=0
            for j in range(5):
                U[j]=al*b1[j]+be*b2[j]; n2+=U[j]*U[j]
            if n2<TAIL or 4*MN*MN*n2>=lhs: continue
            if not nondeg(U): continue
            cnt+=1
            num,den,st=witness(U)
            for j in range(5): h=mix(h,U[j])
            h=mix(h,num);h=mix(h,den)
            if num<0:
                if fpos+fails<FA.shape[0]:
                    for j in range(5): FA[fpos+fails,j]=U[j]
                fails+=1
            elif not st: bnd+=1
    return cnt,fails,bnd,h
