import numpy as np,time
from s3lib import centre_search
c=np.load('cands12.npz');Y,D=c['Y'],c['D']
u=np.load('union.npz');M=u['M'].astype(np.int64);deg=u['deg']
idx=np.nonzero(~deg)[0];out=np.full(len(M),-2,np.int64)
t=time.time()
for s in range(0,len(idx),1_000_000):
    j=idx[s:s+1_000_000]; out[j]=centre_search(M[j],Y,D); print(s,round(time.time()-t),flush=True)
np.save('centre_idx.npy',out)
print('DONE nocentre',int((out==-1).sum()),round(time.time()-t))
