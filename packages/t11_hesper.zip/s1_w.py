# S1: the 3-dim speed spaces W for Z=5 (C09): z1 in {(2,-1,0,0,0),(1,1,1,1,1)}, z2 with |z2|^2<=37, saturated relation lattice L=<a,b> (Lagrange-reduced),
# drop L containing e_i or e_i±e_j. For each W: best centre x=y/d (d<=12) with a.y≡b.y≡0 (mod d); margin m_W=MN/MD; T_W=7/(12 m_W^2)=A/B.
import sys,itertools,numpy as np,math,json
sys.path.insert(0,'..')
from rel import run
c=np.load('cands12.npz');Y,D,MN,MD=c['Y'],c['D'],c['MN'],c['MD']
SPECIAL=[]
for i in range(5):
    e=[0]*5;e[i]=1;SPECIAL.append(e)
for i,j in itertools.combinations(range(5),2):
    for s in (1,-1):
        e=[0]*5;e[i]=1;e[j]=s;SPECIAL.append(e)
def inL(a,b,e):  # rank([a;b;e])==2, exact integer 3x3 minors
    for cols in itertools.combinations(range(5),3):
        m=np.array([[a[k] for k in cols],[b[k] for k in cols],[e[k] for k in cols]],dtype=np.int64)
        if round(np.linalg.det(m))!=0: return False
    return True
rows=[]
for name,z1 in (('A',(2,-1,0,0,0)),('B',(1,1,1,1,1))):
    n,seen=run(z1,37)
    for a,b in seen.values():
        if any(inL(a,b,e) for e in SPECIAL): continue
        ok=np.nonzero(((Y@np.array(a))%D==0)&((Y@np.array(b))%D==0))[0]
        if len(ok)==0: rows.append([name,list(a),list(b),None]);continue
        i=ok[0]; mn,md=int(MN[i]),int(MD[i]); g=math.gcd(7*md*md,12*mn*mn)
        rows.append([name,list(a),list(b),[Y[i].tolist(),int(D[i]),mn,md,7*md*md//g,12*mn*mn//g]])
    print(name,'nondeg W',sum(r[0]==name for r in rows),'no centre',sum(r[0]==name and r[3] is None for r in rows),flush=True)
json.dump(rows,open('W.json','w'))
import collections
print(collections.Counter((r[0],r[3][2],r[3][3]) for r in rows if r[3]).most_common())
TA=[r[3][4]/r[3][5] for r in rows if r[3]]; print('T_W max',max(TA))
