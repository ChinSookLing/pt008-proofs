import numpy as np,numba as nb,time,sys,hashlib
from s4lib import plane_witness
c=np.load('cands12.npz');MNc,MDc=c['MN'],c['MD']
u=np.load('union.npz');M=u['M'].astype(np.int64);Dg=u['D'];ci=np.load('centre_idx.npy');rc=np.load('resid_count.npy')
ok=np.nonzero(ci>=0)[0]; idx=ok[rc>0]; MN=MNc[ci[idx]];MD=MDc[ci[idx]]
@nb.njit(parallel=True)
def run(M,Dg,MN,MD,idx):
    n=len(idx);C=np.zeros(n,np.int64);F=np.zeros(n,np.int64);B=np.zeros(n,np.int64);H=np.zeros(n,np.int64)
    FA=np.zeros((n,8,5),np.int64)
    for k in nb.prange(n):
        p=idx[k]; c,f,b,h=plane_witness(M[p],MN[k],MD[k],Dg[p],FA[k],0)
        C[k]=c;F[k]=f;B[k]=b;H[k]=h
    return C,F,B,H,FA
s,e=int(sys.argv[1]),int(sys.argv[2]); t=time.time()
C,F,B,H,FA=run(M,Dg,MN[s:e],MD[s:e],idx[s:e])
np.savez(f'wit_{s}.npz',idx=idx[s:e],C=C,F=F,B=B,H=H,FA=FA[F>0])
print('DONE',s,e,'U',int(C.sum()),'fail',int(F.sum()),'bnd',int(B.sum()),round(time.time()-t),flush=True)
