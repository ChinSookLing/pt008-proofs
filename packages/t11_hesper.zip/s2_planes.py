# S2 (T11): stream planes. For each W=(a,b) from W.json with T_W=A/B:
#   z3 integer, |z3|^2 < T_W + (|a|^2+|b|^2)/4 (Babai lift range), projection test exact in integers:
#   perpD = |z3|^2*Dg - (g22 p^2 - 2 g12 p q + g11 q^2), Dg=det Gram(a,b), p=a.z3, q=b.z3;  0 < perpD  and  B*perpD < A*Dg.
#   keep only z3 with gcd(3x3 minors of [a;b;z3]) == 1 (then <a,b,z3> is the saturated rank-3 relation lattice; every plane has such a z3 in range).
#   key = primitive sign-normalised Plücker vector (first nonzero > 0). Dedupe streaming.
# usage: python3 s2_planes.py SHAPE(A|B) START END OUT.npz
import sys,json,itertools,math,numpy as np,time
shape=sys.argv[1]; st=int(sys.argv[2]); en=int(sys.argv[3]); out=sys.argv[4]
W=[r for r in json.load(open('W.json')) if r[0]==shape][st:en]
NMAX=max(r[3][4]/r[3][5]+(sum(x*x for x in r[1])+sum(x*x for x in r[2]))/4 for r in W)
R=int(math.isqrt(int(NMAX)+1))
Z=np.array([v for v in itertools.product(range(-R,R+1),repeat=5) if 0<sum(t*t for t in v)<=NMAX],dtype=np.int64)
N2=(Z*Z).sum(1); o=np.argsort(N2,kind='stable'); Z=Z[o]; N2=N2[o]
C3=list(itertools.combinations(range(5),3))
def plucker(a,b,Zs):
    cols=[a[i]*(b[j]*Zs[:,k]-b[k]*Zs[:,j])-a[j]*(b[i]*Zs[:,k]-b[k]*Zs[:,i])+a[k]*(b[i]*Zs[:,j]-b[j]*Zs[:,i]) for i,j,k in C3]
    return np.stack(cols,1)
def vkey(P): return np.ascontiguousarray(P).view(np.dtype((np.void,P.dtype.itemsize*P.shape[1]))).ravel()
accP=[];accR=[];hits=0;sat=0;t0=time.time()
store_P=np.zeros((0,10),np.int16); store_R=np.zeros((0,6),np.int32)
def merge():
    global store_P,store_R,accP,accR
    if not accP: return
    P=np.vstack([store_P]+accP); Rr=np.vstack([store_R]+accR); accP=[];accR=[]
    _,i=np.unique(vkey(P),return_index=True); store_P=P[i]; store_R=Rr[i]
for wi,(sh,a,b,cen) in enumerate(W):
    A,B=cen[4],cen[5]; a=np.array(a);b=np.array(b)
    g11=int(a@a);g12=int(a@b);g22=int(b@b);Dg=g11*g22-g12*g12
    lim=A/B+(g11+g22)/4
    n=np.searchsorted(N2,lim,side='left')   # strict <
    Zs=Z[:n];p=Zs@a;q=Zs@b
    perpD=N2[:n]*Dg-(g22*p*p-2*g12*p*q+g11*q*q)
    idx=np.nonzero((perpD>0)&(B*perpD<A*Dg))[0]
    hits+=len(idx)
    if len(idx)==0: continue
    P=plucker(a,b,Zs[idx]); g=np.gcd.reduce(np.abs(P),axis=1)
    k=g==1; sat+=int(k.sum()); P=P[k]; zz=Zs[idx][k]
    s=np.sign(P[np.arange(len(P)),(P!=0).argmax(1)]); P=(P*s[:,None]).astype(np.int16)
    _,u=np.unique(vkey(P),return_index=True)
    accP.append(P[u]); accR.append(np.hstack([zz[u],np.full((len(u),1),st+wi)]).astype(np.int32))
    if sum(len(x) for x in accP)>3_000_000: merge()
    if wi%500==0: print(shape,st+wi,hits,sat,len(store_P),round(time.time()-t0,1),flush=True)
merge()
np.savez(out,P=store_P,R=store_R)
print('DONE',shape,st,en,'hits',hits,'saturated',sat,'planes',len(store_P),round(time.time()-t0,1),flush=True)
