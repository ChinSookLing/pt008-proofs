# PT008-TF-R002-A47-T11 · Hesper part (status: TEST, not PROVED)
Planes (integer test B·kᵀadj(G)k < A·det G, saturated z3, canonical Plücker dedup):
  A 6,293,630 · B 3,636,650 · union 9,928,398  (= chair C10 counts exactly)
Disposition of every union plane (t11_disposition.npz, local, 136 MB, sha dc333ae0…f17a0d):
  DEG (contains e_i or e_i±e_j)            48,438
  centre d≤12, no residual U              6,507,342
  centre d≤12, residual U all witnessed   3,372,522
  no centre d≤12 → centre at d=15/19       96   (nocentre.tsv; all margin ≥17/114; residual 31,728 U, 0 fail)
D = det Gram(p,q) = ‖Plücker‖² (Cauchy–Binet), checked on 2,000 random planes. m_P = best-margin centre y/d.
Residual U: primitive, mod ±, nondegenerate, TAIL ‖U‖²≥21609, and 4·mN²·‖U‖² < mD²·D (strict).
  total 594,332,286 U (+31,728 on the 96 planes), witness fail 0.
Witness: t = (6n±1)/(6|U_j|), closed check ‖U_i t‖ ≥ 1/6 by integer test min(r,den−r) ≥ |U_j|.
  Witnesses are deterministic and replayed (not stored: ~16 GB); per-plane fingerprint in fp column.
Assumptions for chair to confirm: tail 21609 + nondegenerate filter on U; closed (≥1/6) condition.
Opus items (equality of rank-one bound, completeness, A45 degenerate branch) NOT done here.
Replay: python3 s1_w.py; s2_planes.py A|B 0 7000 …; s3_union.py; s3_centre.py; s4_count.py; s5_witness.py S E (1M-plane chunks); s6_nocentre.py.
Times: s2 48.5 s + 24.0 s; centre 54 s; count 23 s; witness 72 s.
