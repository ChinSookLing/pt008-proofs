# union of planes A,B; build M rows (a,b,z3); degeneracy (plane contains e_i or e_i±e_j) via Plücker wedge; D = |P|^2 (Cauchy-Binet = det Gram of Λ).
import numpy as np,json,itertools
W=json.load(open('W.json'))
WA=np.array([[r[1],r[2]] for r in W if r[0]=='A']);WB=np.array([[r[1],r[2]] for r in W if r[0]=='B'])
a=np.load('planesA.npz');b=np.load('planesB.npz')
P=np.vstack([a['P'],b['P']]);R=np.vstack([a['R'],b['R']]);S=np.r_[np.zeros(len(a['P']),np.int8),np.ones(len(b['P']),np.int8)]
v=np.ascontiguousarray(P).view(np.dtype((np.void,20))).ravel()
_,i=np.unique(v,return_index=True); i=np.sort(i); P=P[i].astype(np.int64);R=R[i];S=S[i]
print('union',len(P))
AB=np.where(S[:,None,None]==0,WA[np.where(S==0,R[:,5],0)],WB[np.where(S==1,R[:,5],0)])
M=np.concatenate([AB,R[:,None,:5]],axis=1).astype(np.int8)
C3=list(itertools.combinations(range(5),3));pos={c:k for k,c in enumerate(C3)}
SPECIAL=[]
for k in range(5):
    e=[0]*5;e[k]=1;SPECIAL.append(e)
for k,j in itertools.combinations(range(5),2):
    for s in (1,-1):
        e=[0]*5;e[k]=1;e[j]=s;SPECIAL.append(e)
deg=np.zeros(len(P),bool)
for e in SPECIAL:
    z=np.ones(len(P),bool)
    for abcd in itertools.combinations(range(5),4):
        acc=np.zeros(len(P),np.int64)
        for r in range(4):
            sub=tuple(x for x in abcd if x!=abcd[r]); acc+=(-1)**r*P[:,pos[sub]]*e[abcd[r]]
        z&=acc==0
    deg|=z
Dg=(P*P).sum(1)
print('degenerate',int(deg.sum()),'nondeg',int((~deg).sum()),'D range',Dg.min(),Dg.max())
np.savez('union.npz',P=P.astype(np.int16),M=M,S=S,deg=deg,D=Dg)
