import numpy as np,time
from cands import cands
from s3lib import centre_search
u=np.load('union.npz');M=u['M'].astype(np.int64);P=u['P'];Dg=u['D'];S=u['S'];ci=np.load('centre_idx.npy')
nc=np.nonzero(ci==-1)[0];print('nocentre',len(nc))
for dm in (24,36,60):
    Y,D,MN,MD=cands(dm); o=centre_search(M[nc],Y,D)
    print('dmax',dm,'still none',int((o<0).sum()))
    if (o<0).sum()==0: break
with open('nocentre.tsv','w') as f:
    f.write('plane\tshape\tD\ta\tb\tz3\tcentre_y\tcentre_d\tmargin\n')
    for k,p in enumerate(nc):
        y=Y[o[k]].tolist() if o[k]>=0 else '-'; d=int(D[o[k]]) if o[k]>=0 else '-'; m=f'{MN[o[k]]}/{MD[o[k]]}' if o[k]>=0 else '-'
        f.write(f"{p}\t{'AB'[S[p]]}\t{Dg[p]}\t{M[p,0].tolist()}\t{M[p,1].tolist()}\t{M[p,2].tolist()}\t{y}\t{d}\t{m}\n")
import collections;print(collections.Counter(Dg[nc]).most_common(6))
