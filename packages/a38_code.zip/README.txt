PT-008 R002 A38 certificate package (Hesper), Z=13 tail |U|^2>=21609, wedge bound |U^m|^2<=540.
Shapes: A z1=(3,2,0,0,0) ; B z1=(3,1,1,1,1) ; C z1=(2,2,2,1,0).
Replay per shape X with z1:
  python3 gen.py z1 540 21609 planes_X.tsv
  python3 resid.py planes_X.tsv 21609 > resid_X.txt
  node times.js resid_X.txt rt_X.txt
  python3 verify.py z1 540 21609 planes_X.tsv rt_X.txt
gen.py solves z1.v=0 for the coord with smallest |coef|; verify.py (A) re-enumerates solving for the coord with largest |coef| (different parametrization).
Columns as in A37: planes p,q,det^2,tr,x0,y0,rr(exact rho^2),closed ; rt: p q a b u1..u5 i k, t=(6k+1)/(6|u_i|).
Expected:
  A: planes 99696 closed 73752 residual planes 25944 residual inputs 8470896 max |U|^2 1659025 ALL PASS
  B: planes 99972 closed 88500 residual planes 11472 residual inputs 1113324 max |U|^2 241202 ALL PASS
  C: planes 96678 closed 83244 residual planes 13434 residual inputs 2935008 max |U|^2 1308328 ALL PASS
