A43 Z=9 tail (|U|^2>=21609), wedge^2<=728, shape (2,2,1,0,0) only. Hesper, WEB OFF.
Replay: python3 bound.py 9; bash run.sh A 2,2,1,0,0 728; python3 neon_rules.py planes_A.tsv
Expect: planes 275056 closed 229880 resid planes 45176 resid inputs 16277256 max|U|^2 5655763 ALL PASS
verify.py v2: part C streamed per plane (v1 held 16M tuples in memory and was OOM-killed at 7 GB); checks identical, plus per-plane no-duplicate and plane-contiguity asserts.
Closed planes use Lean lemmaT_T6 (commit d2128613), rounding floor(s+1/2); cert does no rounding. Residual times explicit rationals.
