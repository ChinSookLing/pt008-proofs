# Rational centre candidates x = y/d, exact common denominator d <= DMAX, every coordinate strictly in (1/6,5/6).
# margin(x) = min_i min(x_i-1/6, 5/6-x_i) = MN/MD exactly, MN = min_i min(6y_i-d, 5d-6y_i), MD = 6d.
# Sorted by margin desc, then d asc.
import itertools, numpy as np, math, sys
def cands(dmax=12):
    rows=[]
    for d in range(1,dmax+1):
        ks=[k for k in range(d+1) if 6*k>d and 6*k<5*d]
        for y in itertools.product(ks,repeat=5):
            g=d
            for k in y: g=math.gcd(g,k)
            if g!=1: continue
            mn=min(min(6*k-d,5*d-6*k) for k in y)
            rows.append((mn/(6*d),mn,6*d,d,y))
    rows.sort(key=lambda r:(-r[0],r[3]))
    Y=np.array([r[4] for r in rows],dtype=np.int64); D=np.array([r[3] for r in rows],dtype=np.int64)
    MN=np.array([r[1] for r in rows],dtype=np.int64); MD=np.array([r[2] for r in rows],dtype=np.int64)
    return Y,D,MN,MD
if __name__=='__main__':
    dm=int(sys.argv[1]) if len(sys.argv)>1 else 12
    Y,D,MN,MD=cands(dm); np.savez(f'cands{dm}.npz',Y=Y,D=D,MN=MN,MD=MD)
    print(len(Y), MN[0],MD[0], MN[-1],MD[-1])
