# A48-T01: 3-dim speed spaces W for Z=3 z1=(1,1,-1,0,0) and Z=4 z1=(1,1,-1,-1,0); z2 with |z2|^2<=37 (C10 lift bound),
# saturated relation lattice L=<a,b>; drop L containing e_i or e_i±e_j; best centre y/d (d<=DMAX) with a.y≡b.y≡0 (mod d).
import sys,itertools,numpy as np,math,json,collections
sys.path.insert(0,'..')
from rel import run
from cands import cands
name=sys.argv[1]; z1=tuple(int(x) for x in sys.argv[2].split(',')); out=sys.argv[3]
SPECIAL=[]
for i in range(5):
    e=[0]*5;e[i]=1;SPECIAL.append(e)
for i,j in itertools.combinations(range(5),2):
    for s in (1,-1):
        e=[0]*5;e[i]=1;e[j]=s;SPECIAL.append(e)
def rank3(a,b,e):
    for cols in itertools.combinations(range(5),3):
        x=[[v[k] for k in cols] for v in (a,b,e)]
        d=(x[0][0]*(x[1][1]*x[2][2]-x[1][2]*x[2][1])-x[0][1]*(x[1][0]*x[2][2]-x[1][2]*x[2][0])+x[0][2]*(x[1][0]*x[2][1]-x[1][1]*x[2][0]))
        if d: return True
    return False
CC={dm:cands(dm) for dm in (12,24)}
n,seen=run(z1,37)
rows=[];deg=0
for a,b in seen.values():
    if any(not rank3(a,b,e) for e in SPECIAL): deg+=1;continue
    best=None
    for dm,(Y,D,MN,MD) in CC.items():
        ok=np.nonzero(((Y@np.array(a))%D==0)&((Y@np.array(b))%D==0))[0]
        if len(ok): i=ok[0]; best=[Y[i].tolist(),int(D[i]),int(MN[i]),int(MD[i]),dm]; break
    rows.append([name,list(a),list(b),best])
print(name,z1,'L total',len(seen),'deg',deg,'nondeg W',len(rows),'no centre d<=12',sum(r[3] is None or r[3][4]>12 for r in rows),'no centre d<=60',sum(r[3] is None for r in rows))
print(collections.Counter((r[3][2],r[3][3]) for r in rows if r[3]).most_common(12))
json.dump(rows,open(out,'w'))
