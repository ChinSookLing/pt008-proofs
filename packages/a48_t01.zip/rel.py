# PT-008 Z=5 finite descent: relation table. z1 fixed; z2 integer, independent of z1, |z2|^2<=BOUND.
# Dedupe by saturated rank-2 relation lattice L = span_Q(z1,z2) ∩ Z^5 (canonical: HNF-like reduced basis {z1, w}).
import sys,math,itertools,json
from fractions import Fraction as F
def minors_gcd(a,b):
    g=0
    for i,j in itertools.combinations(range(5),2): g=math.gcd(g,a[i]*b[j]-a[j]*b[i])
    return g
def saturate(z1,z2):
    c=minors_gcd(z1,z2)       # index of <z1,z2> in L (z1 primitive)
    for e in range(c):
        v=[z2[i]-e*z1[i] for i in range(5)]
        if all(x%c==0 for x in v): return c,tuple(x//c for x in v)
    raise Exception
def canon(z1,w):
    # canonical rep of L: rational RREF of [z1;w]
    M=[[F(x) for x in z1],[F(x) for x in w]]
    r=0;piv=[]
    for col in range(5):
        p=next((i for i in range(r,2) if M[i][col]!=0),None)
        if p is None: continue
        M[r],M[p]=M[p],M[r]; pv=M[r][col]; M[r]=[x/pv for x in M[r]]
        for i in range(2):
            if i!=r and M[i][col]!=0:
                f=M[i][col]; M[i]=[a-f*b for a,b in zip(M[i],M[r])]
        r+=1
        if r==2: break
    return tuple(tuple(x) for x in M)
def reduce_w(z1,w):
    # make w the shortest coset rep w+k z1 (Lagrange/Gauss reduction of {z1,w}) for a nice basis
    a=list(z1); b=list(w)
    while True:
        n1=sum(x*x for x in a); n2=sum(x*x for x in b)
        if n2<n1: a,b=b,a; n1,n2=n2,n1
        k=round(sum(x*y for x,y in zip(a,b))/n1)
        if k==0: break
        b=[y-k*x for x,y in zip(a,b)]
    return tuple(a),tuple(b)
def run(z1,B):
    R=int(math.isqrt(B)); seen={}
    n=0
    for z2 in itertools.product(range(-R,R+1),repeat=5):
        if sum(x*x for x in z2)>B: continue
        if minors_gcd(z1,z2)==0: continue
        n+=1
        c,w=saturate(z1,z2)
        key=canon(z1,w)
        if key not in seen: seen[key]=reduce_w(z1,w)
    return n,seen
if __name__=='__main__':
    B=int(sys.argv[1]); out={}
    for name,z1 in (('A',(2,-1,0,0,0)),('B',(1,1,1,1,1))):
        n,seen=run(z1,B)
        print(name,z1,'z2 vectors',n,'distinct subspaces',len(seen),flush=True)
        out[name]=[list(map(list,v)) for v in seen.values()]
    json.dump(out,open(f'subspaces_B{B}.json','w'))
