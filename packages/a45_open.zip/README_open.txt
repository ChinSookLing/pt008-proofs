A45 (Z=7, tail 21609, shape (2,1,1,1,0)) probe D<=728 — open-plane list (Hesper, TEST)
probe728.tsv : python3 gen.py 2,1,1,1,0 728 21609 probe728.tsv   (cols: p q det tr x0 y0 rho^2 trace_closed)
open728.tsv  : python3 mk_open.py probe728.tsv 21609 > open728.tsv  (cols: p q det tr x0 y0 rho^2 resid_count)
  open = spectral criterion fails: c=4*21609*rho^2; need c>=|p|^2, c>=|q|^2, (c-|p|^2)(c-|q|^2)>=(p.q)^2
  resid_count = #primitive (a,b) up to sign with 4rho^2(a^2+b^2)<1 and |ap+bq|^2>=21609
Stats (open728_stats.txt): planes 358794, trace closed 304450, spectral closed 305938, open 52856,
  residual records 10766844, max per plane 3024, open planes with 0 residual 2426.
Cross-check: python3 spectral.py probe728.tsv
