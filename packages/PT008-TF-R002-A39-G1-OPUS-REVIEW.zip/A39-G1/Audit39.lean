import PT008.LemmaT
/-! Opus A39 audit: independent statement checks against the compiled PT008.LemmaT (not part of the submission). -/
open PT008

-- (0) the exact statements as compiled
#check @lemmaT
#check @closed_plane_criterion
#check @lemmaT_T6
#print lemmaT_time

-- (1) rounding offset: δ = s - ⌊s + 1/2⌋ lies in [-1/2, 1/2) for every real s (stronger than the δ² ≤ 1/4 used in the file)
theorem audit_round_offset (s : ℝ) :
    -1/2 ≤ s - (⌊s + 1/2⌋ : ℝ) ∧ s - (⌊s + 1/2⌋ : ℝ) < 1/2 := by
  have h1 : ((⌊s + 1 / 2⌋ : ℤ) : ℝ) ≤ s + 1 / 2 := Int.floor_le _
  have h2 : s + 1 / 2 < ((⌊s + 1 / 2⌋ : ℤ) : ℝ) + 1 := Int.lt_floor_add_one _
  constructor <;> linarith

-- (2) half-integers round UP: s = n + 1/2 gives δ = -1/2 (the end point -1/2 is attained, +1/2 is not)
theorem audit_half_integer (n : ℤ) : ((n : ℝ) + 1/2) - (⌊((n : ℝ) + 1/2) + 1/2⌋ : ℝ) = -1/2 := by
  have : ⌊((n : ℝ) + 1/2) + 1/2⌋ = n + 1 := by
    rw [Int.floor_eq_iff]; push_cast; constructor <;> linarith
  rw [this]; push_cast; ring

-- (3) equality end points: lemmaT accepts hypotheses holding with equality and its conclusion is non-strict.
--     A concrete instance (ι = Unit, p = 1, q = 0, a = 1, b = 0, α = 1, β = 0, x₀ = 1/2, y₀ = 0, ρ = 1/2, θ = 0):
--     hcenter holds with equality at m = 0 (0 + 1/2·1 = |1/2 - 0|), 4ρ²D = 1 exactly, and the theorem applies.
example : ∀ m : ℤ, (0:ℝ) ≤ |((1 * (1:ℤ) + 0 * (0:ℤ) : ℤ) : ℝ) * lemmaT_time 1 0 1 0 (1/2) 0 - m| := by
  have h := lemmaT (ι := Unit) (fun _ => (1:ℤ)) (fun _ => (0:ℤ)) 1 0 1 0 (by norm_num) (1/2) 0 (1/2) 0
    (by norm_num) le_rfl
    (by
      intro _ m
      have hs : Real.sqrt (((1:ℤ):ℝ) ^ 2 + ((0:ℤ):ℝ) ^ 2) = 1 := by norm_num
      rw [hs]
      rcases le_or_lt m 0 with hm | hm
      · have : (m:ℝ) ≤ 0 := by exact_mod_cast hm
        rw [abs_of_nonneg (by push_cast; linarith)]; push_cast; linarith
      · have : (1:ℝ) ≤ m := by exact_mod_cast hm
        rw [abs_of_nonpos (by push_cast; linarith)]; push_cast; linarith)
    (by norm_num)
  exact fun m => h () m

-- (4) the five-coordinate corollary is literally lemmaT ∘ closed_plane_criterion with θ = 1/6, L = 21609 = 147²
example : (21609 : ℝ) = 147 ^ 2 := by norm_num

#print axioms audit_round_offset
#print axioms audit_half_integer
