# PT008-TF-R002-A39 · Gate 1 主审：引理 T 的独立重建与核验

**TO:** PT-008 Chair（经 Tuzi 转交）　**FROM:** Opus（主审）　**DATE:** 2026-11-23
**WEB OFF · WORKING · NOT FOR ARCHIVE · 不上墙 · 不改台账 · 不交 Hesper**
**R002 OPEN · R003 NOT STARTED · TF OPEN**

本报告只审 A39 Gate 1 提交的 Lean 文件 PT008/LemmaT.lean，不涉及 A37/A38 的枚举证书。本报告不宣布 TF SOLVED，也不宣称任何新的 LRC 情形。

---

## 0. 结论

| # | 项目 | 结果 |
|---|---|---|
| 1 | 私有仓库访问 | 已取得（本会话附加 ChinSookLing/pt008-lean，只读），**不需要 Hesper 另交原码封包** |
| 2 | commit、源码与锁定文件的 SHA-256 | **三项全部一致**（§1） |
| 3 | 工具链 | Lean 4.16.0（commit 128a1e6b0a82）、Mathlib a6276f4c…，**与声明一致** |
| 4 | 重建 | `lake exe cache get` 后 `lake env lean PT008/LemmaT.lean`：**无错误**，唯一警告是 unused variable `hθ`。`lake build PT008.LemmaT` 也成功 |
| 5 | 三条 `#print axioms` | **原始输出与提交逐字相同**，都只依赖 [propext, Classical.choice, Quot.sound]（§2） |
| 6 | 禁用结构 | 无 sorry / admit / axiom / unsafe / native_decide，也无 implemented_by / extern |
| 7 | CI run 45191975958 | 核实：headSha = d2128613…，结论 success；日志中的公理行与三个哈希与本地相同 |
| 8 | 逐项规格（半整数取整、安全等号、封闭平面推论、五坐标版本） | **全部符合**（§3），另有独立的 Lean 审计文件与手算证明对照 |
| 9 | 需要 Chair 知道的一点 | lemmaT_time 的取整是 ⌊s+½⌋（半整数向上取整），**与 BD-v19 的 rnd（就近、平局取偶）不同**。若 A37/A38 用 Python round() 算时间，在半整数处会与 lemmaT_time 差一个格点；不影响引理本身的正确性（§4） |

**主审意见：Gate 1 通过独立重建。** 文件形式化的正是规格所述的三条陈述，证明由 Lean 内核检查，公理只有 Lean/Mathlib 的三条标准公理。

---

## 1. 源码与版本锁定

**取得方式：** `git clone --depth 1 --branch lemmaT-gate1 https://github.com/ChinSookLing/pt008-lean`。HEAD = d2128613f3d7912df436af56b9699d094de22539，作者 ChinSookLing，2026-11-23 14:13:56 UTC，提交信息 "Lemma T: opaque D/s/k/δ, explicit shift"。工作区干净（git status 为空）。

| 文件 | 提交声明的 SHA-256 | Opus 实测 | |
|---|---|---|---|
| PT008/LemmaT.lean | 27b81029e1c82611a3429cbafbc278cf91c836809a40c5408450b07fcd80f805 | 27b81029e1c82611a3429cbafbc278cf91c836809a40c5408450b07fcd80f805 | ✓ |
| lean-toolchain | b3f7d43e005c36e7980721171c8809899ec3c0bc338f35568f54606beb7149a8 | b3f7d43e005c36e7980721171c8809899ec3c0bc338f35568f54606beb7149a8 | ✓ |
| lake-manifest.json | 0520d30cf1d98f16fbd69792cf6f28cd7038a121777a12cb068d3b7c51f308bc | 0520d30cf1d98f16fbd69792cf6f28cd7038a121777a12cb068d3b7c51f308bc | ✓ |

**工具链与依赖：**
- lean-toolchain 内容为 `leanprover/lean4:v4.16.0`；`lean --version` 输出 commit 128a1e6b0a82。
- lakefile.toml 的 mathlib 依赖写 `rev = "v4.16.0"`；manifest 锁定 rev a6276f4c6097675b1cf5ebd49b1146b735f38c02。实际检出的 `.lake/packages/mathlib` HEAD 也是 a6276f4c…。

---

## 2. 重建与公理输出

**环境：** 全新安装 elan（仅装 v4.16.0 工具链）；`lake exe cache get` 下载 6,014 个 Mathlib 预编译文件，100% 成功。

**编译：**
- `lake env lean PT008/LemmaT.lean`：约 20 秒，退出码 0。
- `lake build PT008.LemmaT`：Build completed successfully。

**原始输出（逐字）：**
```
Lean (version 4.16.0, x86_64-unknown-linux-gnu, commit 128a1e6b0a82, Release)
PT008/LemmaT.lean:29:34: warning: unused variable `hθ`
note: this linter can be disabled with `set_option linter.unusedVariables false`
'PT008.lemmaT' depends on axioms: [propext, Classical.choice, Quot.sound]
'PT008.closed_plane_criterion' depends on axioms: [propext, Classical.choice, Quot.sound]
'PT008.lemmaT_T6' depends on axioms: [propext, Classical.choice, Quot.sound]
```

**其他检查：**
- **禁用结构：** 与 CI 相同的 `grep -En '\b(sorry|admit|axiom|unsafe|native_decide)\b'` 无匹配（"axioms" 不触发 `\baxiom\b`）；另查 implemented_by / extern 也无。
- **CI 交叉核对：** `gh run view 45191975958` 显示 headSha d2128613…、event push、conclusion success。作业日志中的 Lean 版本行、三条公理行和三个 sha256 行，与本地完全相同。

---

## 3. 逐项规格核对

### 3.1 lemmaT（`#check` 的编译后陈述，见 Audit39.log）

| 规格 | 文件 | |
|---|---|---|
| ι 任意类型 | `{ι : Type u_1}`，没有 Fintype 假设 | ✓ |
| p, q : ι → ℤ；αa + βb = 1 | `α * a + β * b = 1`，全在 ℤ | ✓ |
| ρ > 0，θ ≥ 0 | `0 < ρ`、`0 ≤ θ`（后者未被使用，见 §4） | ✓ |
| 中心安全（含边界） | `θ + ρ·√(p_i² + q_i²) ≤ \|p_i x₀ + q_i y₀ − m\|`，对所有 i 与 m ∈ ℤ，**非严格不等号** | ✓ |
| 4ρ²D ≥ 1 | `1 ≤ 4 * ρ ^ 2 * (a² + b²)`，**允许等号** | ✓ |
| 结论针对实际返回的 t | `θ ≤ \|(a p_i + b q_i) · lemmaT_time a b α β x₀ y₀ − m\|`，**非严格**，对所有 i 与 m | ✓ |

**lemmaT_time（`#print` 原文）：** D = a² + b²，s = b x₀ − a y₀，δ = s − ⌊s + ½⌋，t = αx₀ + βy₀ − δ(αb − βa)/D。与规格逐字相同。

**取整与半整数（Audit39.lean，已由 Lean 检查）：**
- `audit_round_offset`：对所有实数 s，−½ ≤ δ < ½，即 δ ∈ [−½, ½)。
- `audit_half_integer`：s = n + ½ 时 δ = −½，即半整数向上取整；端点 −½ 可取到，+½ 取不到。
- 文件本身只用到较弱的 δ² ≤ ¼（`round_offset_sq_le`），这已足够完成证明。

**等号端点（Audit39.lean 第 3 段）：** 构造了一个中心条件在 m = 0 处取等号、且 4ρ²D = 1 恰好成立的实例，lemmaT 直接适用并通过编译。这确认了两处等号都被允许。

**独立手算证明（与 Lean 证明的思路一致）：**
1. 设 n = ⌊s + ½⌋。点 (x, y) = (x₀ − δb/D, y₀ + δa/D) 满足 bx − ay = s − δ = n。
2. 由 αa + βb = 1：(x, y) = t(a, b) + n(β, −α)，其中 t = αx + βy 正是 lemmaT_time。
3. 于是 u_i t = p_i x + q_i y − n(p_i β − q_i α)，与 p_i x₀ + q_i y₀ 只差一个整数，加上偏移 (δ/D)(q_i a − p_i b)。
4. 由 Cauchy 与 \|δ\| ≤ ½，偏移的绝对值 ≤ \|δ\|·√(p_i² + q_i²)/√D ≤ √(p_i² + q_i²)/(2√D) ≤ ρ√(p_i² + q_i²)，最后一步用的是 4ρ²D ≥ 1。
5. 由三角不等式，‖u_i t‖ ≥ θ。

Lean 证明中的 hkey（整数平移 −p_iβk + q_iαk）与 heabs（偏移界）正对应第 3、4 步。

### 3.2 closed_plane_criterion

| 规格 | 文件 | |
|---|---|---|
| ι 有限 | `[Fintype ι]` | ✓ |
| L > 0 | `0 < L` | ✓ |
| L ≤ Σu_i² | `L ≤ ∑ (a p_i + b q_i)²` | ✓ |
| Σp_i² + Σq_i² ≤ 4Lρ² | 同 | ✓ |
| 结论 | `1 ≤ 4ρ²(a² + b²)` | ✓ |

**手算：** 逐项 Cauchy 给出 u_i² ≤ D(p_i² + q_i²)，求和得 L ≤ D·4Lρ²，除以 L > 0 即得。文件中的 hterm、hsum 正是这两步。

### 3.3 lemmaT_T6

- ι = Fin 5，θ = 1/6，L = 21609（= 147²，Audit39 中以 norm_num 验证）。
- 证明项就是 `lemmaT … (1/6) … (closed_plane_criterion p q a b ρ 21609 …)`，直接由前两条推出，与规格一致。

---

## 4. 观察（不影响 Gate 1 结论）

1. **取整约定与 BD-v19 不同。** lemmaT_time 用 ⌊s+½⌋（半整数向上）；BD-v19 的 rnd 是就近、平局取偶。
   - 引理 T 的定理只对 lemmaT_time 本身成立。
   - 若 A37/A38 的证书在半整数 s 处用 Python `round()` 计算时间，算出的 t 会落在相邻的平行线上（δ 取 +½ 而不是 −½）。
   - 数学上 \|δ\| = ½ 的另一选择同样满足 δ² ≤ ¼，所以那个时间也是安全的；但这一点**没有被本文件形式化**。
   - **建议：** 证书统一按 ⌊s+½⌋ 计算时间，或另加一行引理覆盖 \|δ\| ≤ ½ 的任意选择。
2. **hθ 未被使用。** 结论对任意实数 θ 都成立。按规格保留为假设无害。
3. **ρ > 0** 只在 √(ρ²) = ρ 一步用到。
4. **建置方式。** 本次与 CI 相同，使用 Mathlib 预编译缓存（`lake exe cache get`），没有从源码重编整个 Mathlib。缓存与 manifest 锁定的 rev 对应。
5. **审计文件的位置。** Audit39.lean 是主审自己的检查文件，放在仓库之外，没有改动仓库任何内容。

---

## 5. 范围与限制

- 只审 Gate 1 的三条定理；A37/A38 的枚举与剩余时间表仍由各自证书支撑，本报告不对它们作结论。
- 不宣称 LRC 新情形；不宣称 TF SOLVED；R002 OPEN，R003 NOT STARTED。
- 不上墙；不改台账；不归档。

---

## 6. 附件（ZIP）

| 文件 | 内容 |
|---|---|
| lemmaT_opus.log | 本地 `lake env lean PT008/LemmaT.lean` 的完整输出 |
| env39.txt | HEAD、工作区状态、三个 sha256、Mathlib 检出、lean/lake 版本 |
| Audit39.lean、Audit39.log | 主审的独立 Lean 检查：陈述、δ 范围、半整数、等号实例、147²；以及它们的公理输出 |
| LemmaT.lean.d2128613 | 被审源码的副本（sha256 同上） |

**重跑命令：**
```
git clone --depth 1 --branch lemmaT-gate1 https://github.com/ChinSookLing/pt008-lean && cd pt008-lean
git rev-parse HEAD     # d2128613f3d7912df436af56b9699d094de22539
sha256sum PT008/LemmaT.lean lean-toolchain lake-manifest.json
lake exe cache get && lake env lean PT008/LemmaT.lean
lake build PT008.LemmaT && lake env lean <path>/Audit39.lean
```

—— Opus · A39 Gate 1 主审
