# A48-T01 (Opus): Z = 3, 4 starting step, exact checks.
#  (1) classification of integer vectors of squared norm 1..5 up to signed permutation;
#  (2) centres c in z1^perp with all distances 1/3;
#  (3) normal-correction bound max_k (alpha - k)^2 Z over alpha in (1/Z)Z  (= floor(Z/2)^2 / Z);
#  (4) the 3-dim table W = {z1, z2}^perp, |z2|^2 <= 37, exclusions, strict centres (saturation test, q <= 12),
#      and how many W also contain a relation SHORTER than Z (those U belong to a lower branch).
import itertools, json
from fractions import Fraction as F
from math import gcd
from wtable import int_kernel, plucker, excluded
from level3 import best_centre
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)
def canon(v):
    return tuple(sorted((abs(x) for x in v), reverse=True))
cls = {}
for v in itertools.product(range(-3, 4), repeat=5):
    n = sum(x * x for x in v)
    if 1 <= n <= 5: cls.setdefault(n, set()).add(canon(v))
print("(1) squared norm -> classes up to signed permutation:", {n: sorted(c) for n, c in sorted(cls.items())})
Z1 = {3: (1, 1, -1, 0, 0), 4: (1, 1, -1, -1, 0)}; C = {3: (1, 1, 2, 1, 1), 4: (1, 1, 1, 1, 1)}
for Z in (3, 4):
    z1, c = Z1[Z], [F(x, 3) for x in C[Z]]
    print("(2) Z=%d: <z1,c> = %s, distances %s" % (Z, sum(a * b for a, b in zip(z1, c)), [str(dist(x)) for x in c]))
for Z in (3, 4, 5):
    worst = max(min((F(j, Z) - k) ** 2 * Z for k in range(-2, 3)) for j in range(Z))
    print("(3) Z=%d: worst normal correction = %s ; |z2|^2 < 37 + %s -> <= 37" % (Z, worst, worst))
def short_rel(Wb, Zmax):
    """does span(z1,z2) (i.e. W^perp cap Z^5) contain a nonzero integer vector of squared norm < Zmax ?"""
    S = int_kernel(Wb)
    for a in range(-6, 7):
        for b in range(-6, 7):
            if (a, b) == (0, 0): continue
            v = [a * x + b * y for x, y in zip(S[0], S[1])]
            if 0 < sum(x * x for x in v) < Zmax: return True
    return False
for Z in (3, 4):
    z1 = Z1[Z]; W = {}
    for z2 in itertools.product(range(-6, 7), repeat=5):
        if sum(x * x for x in z2) > 37: continue
        if all(z1[i] * z2[j] == z1[j] * z2[i] for i in range(5) for j in range(5)): continue
        key, g = plucker(z1, z2)
        W.setdefault(key, (z2, g))
    st = {"W": len(W), "zero": 0, "equal": 0, "kept": 0, "lower_branch(shorter relation)": 0, "no_centre_q12": 0, "margins": {}}
    nocent = []
    for key, (z2, g) in W.items():
        Wb = int_kernel([z1, z2]); ex = excluded(Wb)
        if ex: st[ex] += 1; continue
        st["kept"] += 1
        if short_rel(Wb, Z): st["lower_branch(shorter relation)"] += 1
        m, cen = best_centre(int_kernel(Wb))
        if m <= 0: st["no_centre_q12"] += 1; nocent.append(list(z2)); continue
        st["margins"][str(m)] = st["margins"].get(str(m), 0) + 1
    print("(4) Z=%d:" % Z, st, "no-centre examples", nocent[:5], flush=True)
    json.dump({"stats": st, "no_centre": nocent}, open("z%d_table.json" % Z, "w"))
