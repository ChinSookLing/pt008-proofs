# rank-one step on Z = 3 and Z = 4 planes (exact): residual enumeration, witnesses, Babai above threshold incl. equality.
import random, sys, itertools, time
from fractions import Fraction as F
from math import gcd
from wtable import int_kernel, plucker, excluded
from exactplanes import planes_exact
from level3 import best_centre, safe_exists
from rank1 import residual, babai_time, dot, dist
from rank1_test import centre_in_plane
random.seed(int(sys.argv[1])); t0 = time.time()
for name, z1, zmax in (("Z3", (1, 1, -1, 0, 0), 37), ("Z4", (1, 1, -1, -1, 0), 10)):
    z2s = [z2 for z2 in itertools.product(range(-6, 7), repeat=5) if 0 < sum(x * x for x in z2) <= zmax
           and any(z1[i] * z2[j] != z1[j] * z2[i] for i in range(5) for j in range(5))]
    st = {"W": 0, "planes": 0, "U_residual": 0, "witness": 0, "babai": 0, "babai_safe": 0, "equality": 0, "equality_safe": 0}
    while st["W"] < 3:
        z2 = random.choice(z2s); Wb = int_kernel([z1, z2])
        if excluded(Wb): continue
        m, cen = best_centre(int_kernel(Wb)); T = F(7, 12) / (m * m); st["W"] += 1
        P = list(planes_exact(Wb, T).values())
        for p, q in random.sample(P, min(60, len(P))):
            cols = [(p[i], q[i]) for i in range(5)]
            if any(c == (0, 0) for c in cols) or any(cols[i] == cols[j] or cols[i] == (-cols[j][0], -cols[j][1]) for i in range(5) for j in range(i + 1, 5)): continue
            Pp = int_kernel([p, q]); mp, cp = best_centre(Pp)
            if mp <= 0: st["no_centre"] = st.get("no_centre", 0) + 1; continue
            st["planes"] += 1; r_, s_ = mp.numerator, mp.denominator
            for a, b in residual(p, q, r_, s_):
                U = [a * x + b * y for x, y in zip(p, q)]
                if any(u == 0 for u in U): continue
                st["U_residual"] += 1; st["witness"] += safe_exists(U) is not None
            c = centre_in_plane(Pp, cp[0], cp[1]); A, B, C = dot(p, p), dot(p, q), dot(q, q); D = A * C - B * B; bnd = s_ * s_ * D
            amax = int((s_ * s_ * C / (4 * r_ * r_)) ** 0.5) + 3; bmax = int((s_ * s_ * A / (4 * r_ * r_)) ** 0.5) + 3
            for a in range(0, 2 * amax + 1):
                for b in range(-2 * bmax, 2 * bmax + 1):
                    if (a == 0 and b <= 0) or gcd(a, b) != 1: continue
                    lhs = 4 * r_ * r_ * (A * a * a + 2 * B * a * b + C * b * b)
                    if not (bnd <= lhs <= 4 * bnd): continue
                    t, e2, U = babai_time(p, q, a, b, c)
                    if any(u == 0 for u in U): continue
                    ok = all(dist(t * u) >= F(1, 6) for u in U); st["babai"] += 1; st["babai_safe"] += ok
                    if lhs == bnd: st["equality"] += 1; st["equality_safe"] += ok
    print(name, st, "%.0f s" % (time.time() - t0), flush=True)
