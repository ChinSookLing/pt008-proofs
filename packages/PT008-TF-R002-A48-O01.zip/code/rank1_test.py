# tests: (1) residual() == level3.lines_of_plane on the 585 sampled planes; (2) on every sampled plane, for every primitive
# (a,b) with s^2 D <= 4 r^2 Q < s^2 D + (a window), the explicit Babai time is safe and its error^2 <= m^2 -- including all
# exact equality cases 4 r^2 Q = s^2 D found; (3) every residual U has an exact safe-time witness.
import json, random, sys, time, itertools
from fractions import Fraction as F
from math import gcd
from wtable import int_kernel
from exactplanes import planes_exact
from level3 import best_centre, lines_of_plane, safe_exists
from rank1 import residual, babai_time, dot, dist
def centre_in_plane(Pperp, qc, rc):
    """shift c = r/q into P exactly: solve <s, lam> = <s, c> over Z for the saturated basis of P^perp"""
    c = [F(x, qc) for x in rc]; n = 5; cols = [[int(i == j) for j in range(n)] for i in range(n)]; x = [F(0)] * n; used = []
    for row in Pperp:
        vals = [dot(row, cc) for cc in cols]; idx = [i for i in range(n) if i not in used]
        while sum(1 for i in idx if vals[i]) > 1:
            nz = [i for i in idx if vals[i]]; pv = min(nz, key=lambda i: abs(vals[i]))
            for i in nz:
                if i != pv:
                    t = vals[i] // vals[pv]; vals[i] -= t * vals[pv]; cols[i] = [u - t * v for u, v in zip(cols[i], cols[pv])]
        pv = next(i for i in idx if vals[i]); used.append(pv)
        need = dot(row, c) - dot(row, x); coef = need / vals[pv]; assert coef.denominator == 1
        x = [xi + coef * ci for xi, ci in zip(x, cols[pv])]
    cw = [ci - xi for ci, xi in zip(c, x)]
    assert all(dot(row, cw) == 0 for row in Pperp)
    return cw
if __name__ == "__main__":
    st = {"planes": 0, "residual_match": 0, "U_residual": 0, "U_residual_witness": 0, "babai_checked": 0, "babai_safe": 0,
          "babai_err_ok": 0, "equality_cases": 0, "equality_safe": 0}
    t0 = time.time()
    for seed, shape, z1 in ((1, "double", (2, -1, 0, 0, 0)), (2, "double", (2, -1, 0, 0, 0)), (3, "ones", (1, 1, 1, 1, 1))):
        random.seed(seed); rows = [r for r in json.load(open("wbounds_%s.json" % shape))]
        Ws = random.sample(rows, 3); planes = []
        for r in Ws: planes += list(planes_exact(int_kernel([z1, r["z2"]]), F(r["T"])).values())
        for p, q in random.sample(planes, 200):
            cols = [(p[i], q[i]) for i in range(5)]
            if any(c == (0, 0) for c in cols) or any(cols[i] == cols[j] or cols[i] == (-cols[j][0], -cols[j][1]) for i in range(5) for j in range(i + 1, 5)): continue
            Pperp = int_kernel([p, q]); m, cen = best_centre(Pperp)
            if m <= 0: continue
            st["planes"] += 1; r_, s_ = m.numerator, m.denominator
            R = residual(p, q, r_, s_)
            Us = {tuple(a * x + b * y for x, y in zip(p, q)) for a, b in R if all(a * x + b * y != 0 for x, y in zip(p, q))}
            canon = lambda S: {max(U, tuple(-x for x in U)) for U in S}
            L3 = lines_of_plane(p, q, m); st["residual_match"] += canon(Us) == canon(L3)
            if canon(Us) != canon(L3) and st.get("mm", 0) < 2: st["mm"] = st.get("mm", 0) + 1; print("MISMATCH", p, q, m, len(canon(Us)), len(canon(L3)), sorted(canon(Us) ^ canon(L3))[:3])
            st["U_residual"] += len(Us)
            for U in Us: st["U_residual_witness"] += safe_exists(U) is not None
            c = centre_in_plane(Pperp, cen[0], cen[1])
            A, B, C = dot(p, p), dot(p, q), dot(q, q); D = A * C - B * B
            # Babai side: primitive (a,b) just above the threshold (and exact equalities)
            bnd = s_ * s_ * D; amax = int((bnd * 4 * C / (4 * r_ * r_ * D)) ** 0.5) + 3; bmax = int((bnd * 4 * A / (4 * r_ * r_ * D)) ** 0.5) + 3
            for a in range(0, amax + 1):
                for b in range(-bmax, bmax + 1):
                    if (a == 0 and b <= 0) or gcd(a, b) != 1: continue
                    Q = A * a * a + 2 * B * a * b + C * b * b; lhs = 4 * r_ * r_ * Q
                    if not (bnd <= lhs <= 4 * bnd): continue
                    t, e2, U = babai_time(p, q, a, b, c)
                    if any(u == 0 for u in U): continue
                    st["babai_checked"] += 1; ok = all(dist(t * u) >= F(1, 6) for u in U)
                    st["babai_safe"] += ok; st["babai_err_ok"] += e2 <= m * m
                    if lhs == bnd: st["equality_cases"] += 1; st["equality_safe"] += ok
        print(shape, seed, st, "%.0f s" % (time.time() - t0), flush=True)
