# A47-T11 (Opus): rank-one step, exact.
#  plane P with saturated basis (p, q), Gram G, D = det G; U = a p + b q primitive; centre c in P + Z^5 with margin m = r/s.
#  (i)  |b''|^2 = |U|^2 / D ; Babai (1-D) error <= sqrt(D)/(2|U|) ; safe whenever 4 r^2 |U|^2 >= s^2 D (equality included).
#  (ii) residual set = { primitive (a,b) mod +-1 : 4 r^2 Q(a,b) < s^2 D } enumerated exactly with integer bounds
#       a^2 < s^2 C/(4 r^2), b^2 < s^2 A/(4 r^2)   (Q >= D a^2 / C and Q >= D b^2 / A for the positive form Q = A a^2 + 2B ab + C b^2).
from fractions import Fraction as F
from math import gcd, isqrt
def dot(u, v): return sum(x * y for x, y in zip(u, v))
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)
def residual(p, q, r, s):
    A, B, C = dot(p, p), dot(p, q), dot(q, q); D = A * C - B * B
    amax = isqrt(s * s * C // (4 * r * r) + 1) + 1; bmax = isqrt(s * s * A // (4 * r * r) + 1) + 1
    out = []
    for a in range(0, amax + 1):
        for b in range(-bmax, bmax + 1):
            if a == 0 and b <= 0: continue
            if gcd(a, b) != 1: continue
            Q = A * a * a + 2 * B * a * b + C * b * b
            if 4 * r * r * Q < s * s * D: out.append((a, b))
    # completeness guard: the integer bounds are implied by the inequality (checked, not assumed)
    for a, b in out: assert 4 * r * r * a * a * D <= s * s * C * D and 4 * r * r * b * b * D <= s * s * A * D
    return out
def babai_time(p, q, a, b, c):
    """explicit 1-D Babai: c in P (rational, already shifted into P).  Returns (t, euclidean error^2)."""
    U = [a * x + b * y for x, y in zip(p, q)]; nU = dot(U, U)
    # Lambda_P basis (U, w) with det = 1 in (p,q)-coordinates: w = e p + f q with a f - b e = 1
    def eg(x, y):
        if y == 0: return (x, 1, 0)
        g, s1, t1 = eg(y, x % y); return (g, t1, s1 - (x // y) * t1)
    g, f, e = eg(a, b)            # a*f + b*e = 1  -> take w = -e p + f q : a*f - b*(-e) = 1
    w = [-e * x + f * y for x, y in zip(p, q)]
    gvec = [wi - F(dot(w, U), nU) * ui for wi, ui in zip(w, U)]       # generator of Gamma_P
    cE = [ci - F(dot(c, U), nU) * ui for ci, ui in zip(c, U)]          # pi_E(c)
    k = round(F(dot(cE, gvec), dot(gvec, gvec)))
    lam = [k * wi for wi in w]
    t = F(dot([ci - li for ci, li in zip(c, lam)], U), nU)
    res = [ci - li - t * ui for ci, li, ui in zip(c, lam, U)]
    return t, dot(res, res), U
