# level-1 margin per branch: best centre in H + Z^5 = {x : <z1,x> in Z}; threshold |b1|^2 >= 37/(36 m1^2); z2 bound;
# then the reduced 3-dim tables for Z = 4 (|z2|^2 <= 10) and Z = 5 all-ones (|z2|^2 <= 19).
import itertools, json
from fractions import Fraction as F
from math import floor
from wtable import int_kernel, plucker, excluded
from level3 import best_centre
Z1 = {"3": (1, 1, -1, 0, 0), "4": (1, 1, -1, -1, 0), "5d": (2, -1, 0, 0, 0), "5o": (1, 1, 1, 1, 1)}
NORM = {"3": 3, "4": 4, "5d": 5, "5o": 5}
res = {}
for k, z1 in Z1.items():
    m1, cen = best_centre([list(z1)], qmax=12)
    Z = NORM[k]; corr = F(floor(Z / 2) ** 2, Z); T1 = F(37, 36) / (m1 * m1)
    bound = T1 + corr; zmax = int(bound) if bound != int(bound) else int(bound) - 1
    res[k] = (m1, cen, T1, corr, zmax)
    print("branch %s z1=%s: best level-1 margin %s (centre %s) ; threshold |b1|^2 >= %s ; normal corr <= %s ; |z2|^2 <= %d" % (k, z1, m1, cen, T1, corr, zmax))
for k in ("4", "5o"):
    z1 = Z1[k]; zmax = res[k][4]; W = {}
    for z2 in itertools.product(range(-4, 5), repeat=5):
        if sum(x * x for x in z2) > zmax: continue
        if all(z1[i] * z2[j] == z1[j] * z2[i] for i in range(5) for j in range(5)): continue
        key, g = plucker(z1, z2); W.setdefault(key, (z2, g))
    st = {"W": len(W), "zero": 0, "equal": 0, "kept": 0, "no_centre": 0, "margins": {}}
    for key, (z2, g) in W.items():
        Wb = int_kernel([z1, z2]); ex = excluded(Wb)
        if ex: st[ex] += 1; continue
        st["kept"] += 1; m, c = best_centre(int_kernel(Wb))
        if m <= 0: st["no_centre"] += 1
        else: st["margins"][str(m)] = st["margins"].get(str(m), 0) + 1
    print("reduced table %s (|z2|^2 <= %d):" % (k, zmax), st)
