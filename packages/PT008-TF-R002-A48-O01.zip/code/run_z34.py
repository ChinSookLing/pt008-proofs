# exact audit of the first descent step for the branches Z = 3 (m1 = 1/6), Z = 4 (m1 = 1/3), Z = 5 all-ones (m1 = 7/30)
import random, sys
from fractions import Fraction as F
from math import gcd
from zlemma import audit
random.seed(int(sys.argv[1])); N = int(sys.argv[2]); NMAX = int(sys.argv[3])
BR = {"Z3": ((1, 1, -1, 0, 0), [F(1, 3), F(1, 3), F(2, 3), F(1, 3), F(1, 3)], F(37), 37),
      "Z4": ((1, 1, -1, -1, 0), [F(1, 2)] * 5, F(37, 4), 10),
      "Z4_m1/6": ((1, 1, -1, -1, 0), [F(1, 3)] * 5, F(37), 37),
      "Z5o": ((1, 1, 1, 1, 1), [F(-8, 5)] + [F(2, 5)] * 4, F(925, 49), 19)}
for name, (z1, c, thr, zmax) in BR.items():
    st = {"A": 0, "A_ok": 0, "B": 0, "B_ok": 0}; mz = 0
    for _ in range(N):
        while True:
            x = [random.randrange(1, NMAX) for _ in range(4)]
            if name == "Z3": U = [x[0], x[1], x[0] + x[1], x[2], x[3]]
            elif name.startswith("Z4"): U = [x[0], x[1], x[2], x[0] + x[1] - x[2], x[3]]
            else: U = [x[0], x[1], x[2], x[3], -(x[0] + x[1] + x[2] + x[3])]
            if all(u != 0 for u in U) and len({abs(u) for u in U}) == 5 and gcd(*U) == 1: break
        o = audit(U, z1, c, F(1), thr, zmax); k = o["lemma_case"][0]; st[k] += 1; st[k + "_ok"] += o["lemma_ok"]
        if k == "B": mz = max(mz, o["|z2|^2"])
    print("%s (entries < %d): %s ; max |z2|^2 in case B = %d (bound %d)" % (name, NMAX, st, mz, zmax), flush=True)
