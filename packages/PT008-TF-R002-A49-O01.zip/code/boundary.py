# all sorted distinct positive U with |U|^2 in [LO, HI]: run select() and the independent oracle
import sys, json, time
from math import isqrt
from fractions import Fraction as F
from collections import Counter
sys.path.insert(0, "/home/claude/TF/R002/A49/sel")
from selector import select
LO, HI = int(sys.argv[1]), int(sys.argv[2]); t0 = time.time(); st = Counter(); fails = []
def oracle(u, t): return all(min((v * t) % 1, 1 - (v * t) % 1) >= F(1, 6) for v in u)
for a in range(1, 148):
    for b in range(a + 1, 148):
        if a*a + b*b + (b+1)**2 + (b+2)**2 + (b+3)**2 > HI: break
        for c in range(b + 1, 148):
            if a*a + b*b + c*c + (c+1)**2 + (c+2)**2 > HI: break
            for d in range(c + 1, 148):
                s4 = a*a + b*b + c*c + d*d
                if s4 + (d+1)**2 > HI: break
                r = LO - s4; e0 = max(d + 1, isqrt(r - 1) + 1 if r > 0 else d + 1)
                for e in range(e0, isqrt(HI - s4) + 1):
                    U = (a, b, c, d, e); n2 = s4 + e*e
                    if not (LO <= n2 <= HI): continue
                    try:
                        res = select(U); ok = oracle(U, res.time); st[(n2 >= 21609, res.branch, ok)] += 1
                        if not ok: fails.append((U, "oracle"))
                    except Exception as ex:
                        st[("EXC", type(ex).__name__)] += 1; fails.append((U, type(ex).__name__, str(ex)[:100]))
print(json.dumps({"range": [LO, HI], "counts": {str(k): v for k, v in st.items()}, "fails": fails[:20], "seconds": round(time.time() - t0)}))
