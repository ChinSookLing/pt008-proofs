# drive the Z <= 5 descent into its last layer: U small (|U|^2 in [21609, HI]) inside W = {z1, z2}^perp
import sys, time, random, json, signal, itertools
from fractions import Fraction as F
from math import gcd
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/TF/R002/A49/sel"); from selector import select
sys.path.insert(0, "/home/claude/TF/R002/A48/opus"); from wtable import int_kernel
class TO(Exception): pass
def _al(*a): raise TO()
signal.signal(signal.SIGALRM, _al)
def oracle(u, t): return all(min((v * t) % 1, 1 - (v * t) % 1) >= F(1, 6) for v in u)
rng = random.Random(int(sys.argv[1])); N = int(sys.argv[2]); HI = int(sys.argv[3]); st = Counter(); fails = []; D = defaultdict(list); T0 = time.time()
Z1 = [(1, 1, -1, 0, 0), (1, 1, -1, -1, 0), (2, -1, 0, 0, 0), (1, 1, 1, 1, -1)]
done = 0
while done < N:
    z1 = rng.choice(Z1); z2 = [rng.randint(-4, 4) for _ in range(5)]
    if sum(x * x for x in z2) > 37 or len(int_kernel([z1, z2])) != 3: continue
    K = int_kernel([z1, z2])
    for _ in range(40):
        c = [rng.randint(-60, 60) for _ in K]
        if gcd(*c) != 1: continue
        u = [sum(ci * k[j] for ci, k in zip(c, K)) for j in range(5)]
        n2 = sum(x * x for x in u)
        if not (21609 <= n2 <= HI) or not all(u): continue
        perm = list(range(5)); rng.shuffle(perm); u = [u[i] * rng.choice((1, -1)) for i in perm]
        done += 1
        try:
            signal.alarm(120); r = select(tuple(u)); signal.alarm(0)
            st[r.branch] += 1
            if r.plane_determinant: D[r.branch].append(r.plane_determinant)
            if not oracle(u, r.time): st["ORACLE_FAIL"] += 1; fails.append(u)
        except Exception as e:
            signal.alarm(0); st["EXC:" + type(e).__name__] += 1; fails.append((u, str(e)[:120]))
        break
print("done %d in %.0f s:" % (done, time.time() - T0), dict(st), {k: (min(v), max(v), len(v)) for k, v in D.items()}, "failures", fails[:10])
