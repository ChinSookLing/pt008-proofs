# exhaustive check of the finite branch: every sorted distinct positive U with |U|^2 < 21609 has a nonempty mask
# intersection (so select() never raises there).  Mask bits themselves are checked by replay.py.  Work split by a.
import sys, json, time
from math import isqrt
sys.path.insert(0, "/home/claude/TF/R002/A49/sel")
from selector import finite_table
times, masks = finite_table(); M = [0] + [masks[v] for v in range(1, 147)]
CAP = 21608
part, parts = int(sys.argv[1]), int(sys.argv[2]); t0 = time.time()
n = bad = 0; badlist = []
for a in range(1, 147):
    if a % parts != part: continue
    sa = a * a
    for b in range(a + 1, 147):
        sb = sa + b * b
        if sb + (b + 1) ** 2 + (b + 2) ** 2 + (b + 3) ** 2 > CAP: break
        mb = M[a] & M[b]
        for c in range(b + 1, 147):
            sc = sb + c * c
            if sc + (c + 1) ** 2 + (c + 2) ** 2 > CAP: break
            mc = mb & M[c]
            for d in range(c + 1, 147):
                sd = sc + d * d
                if sd + (d + 1) ** 2 > CAP: break
                md = mc & M[d]
                emax = isqrt(CAP - sd)
                for e in range(d + 1, emax + 1):
                    n += 1
                    if not (md & M[e]):
                        bad += 1
                        if len(badlist) < 20: badlist.append((a, b, c, d, e))
print(json.dumps({"part": part, "parts": parts, "tuples": n, "empty": bad, "examples": badlist, "seconds": round(time.time() - t0)}))
