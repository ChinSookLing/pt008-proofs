# targeted inputs for the rare branches: plane-middle (shortest relation Z in 6..13 plus a second short relation),
# plane-low / rank1 (three small relations, small plane coordinates), A47-O07 counterexamples, tight cases.
import sys, time, random, json, signal
from fractions import Fraction as F
from math import gcd, isqrt
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/TF/R002/A49/sel"); from selector import select
sys.path.insert(0, "/home/claude/TF/R002/A48/opus"); from wtable import int_kernel
class TO(Exception): pass
def _al(*a): raise TO()
signal.signal(signal.SIGALRM, _al)
def oracle(u, t): return all(min((v * t) % 1, 1 - (v * t) % 1) >= F(1, 6) for v in u)
st = Counter(); fails = []; ex = {}; tmax = defaultdict(float); Dmid = defaultdict(int)
def run(u, tag):
    t0 = time.time()
    try:
        signal.alarm(120); r = select(tuple(u)); signal.alarm(0)
    except Exception as e:
        signal.alarm(0); st["EXC:%s:%s" % (tag, type(e).__name__)] += 1
        if len(fails) < 30: fails.append((tag, list(u), type(e).__name__, str(e)[:150]))
        return
    dt = time.time() - t0; tmax[r.branch] = max(tmax[r.branch], dt)
    st["%s:%s" % (tag, r.branch)] += 1; ex.setdefault(r.branch, (list(u), str(r.time), r.shortest_relation_squared, r.plane_determinant))
    if r.branch == "plane-middle": Dmid[r.shortest_relation_squared] = max(Dmid[r.shortest_relation_squared], r.plane_determinant)
    if not oracle(u, r.time): st["ORACLE_FAIL"] += 1; fails.append((tag, list(u), "oracle"))
def in_kernel(rows, rng, scale):
    K = int_kernel(rows)
    if any(all(k[j] == 0 for k in K) for j in range(5)): return None
    for _ in range(100):
        c = [rng.randrange(-scale, scale + 1) for _ in K]
        if gcd(*c) != 1: continue
        u = [sum(ci * k[j] for ci, k in zip(c, K)) for j in range(5)]
        if all(u) and sum(x * x for x in u) >= 21609: return u
    return None
rng = random.Random(int(sys.argv[1])); N = int(sys.argv[2]); T0 = time.time()
vecs = {}
for v in __import__("itertools").product(range(-3, 4), repeat=5):
    vecs.setdefault(sum(x * x for x in v), []).append(v)
for i in range(N):                                     # middle: z1 of norm 6..13, z2 of norm <= 40
    Z = rng.randint(6, 13); z1 = rng.choice(vecs[Z]); z2 = rng.choice(vecs[rng.randint(Z, 27)])
    u = in_kernel([z1, z2], rng, rng.choice((30, 1000, 10**6, 10**15)))
    if u: run(u, "mid")
for i in range(N):                                     # planes: three small relations, small coefficients
    rows = [rng.choice(vecs[rng.randint(3, 12)]) for _ in range(3)]
    if len(int_kernel(rows)) != 2: continue
    u = in_kernel(rows, rng, rng.choice((3, 10, 40, 200)))
    if u: run(u, "plane")
cx = json.load(open("/home/claude/TF/R002/A47h/opus/cx_verified47.json"))
for r in cx: run(r["U"], "A47cx")
for k in range(1, 60): run([k * x for x in (1, 2, 3, 4, 5)], "tight")
print("done in %.0f s" % (time.time() - T0)); print("counts:", dict(sorted(st.items())))
print("max seconds:", {k: round(v, 2) for k, v in tmax.items()}); print("plane-middle max D by Z:", dict(sorted(Dmid.items())))
print("examples:", ex); print("failures:", fails)
