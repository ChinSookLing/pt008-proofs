# A49-T01 independent acceptance (Opus): stress the selector with an independent exact oracle.
# The selector is imported from ../sel (read, unmodified).  Oracle: Fraction arithmetic, distance to nearest integer.
import sys, time, random, json, traceback, itertools, signal
class TO(Exception): pass
def _alarm(*a): raise TO()
signal.signal(signal.SIGALRM, _alarm)
from fractions import Fraction as F
from math import gcd
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/TF/R002/A49/sel")
from selector import select
sys.path.insert(0, "/home/claude/TF/R002/A48/opus")
from wtable import int_kernel
def oracle(speeds, t):
    for v in speeds:
        x = v * t; d = x - (x.numerator // x.denominator)
        if min(d, 1 - d) < F(1, 6): return False
    return True
stats = Counter(); fails = []; tmax = defaultdict(float); ex = {}
def run(u, tag):
    t0 = time.time()
    try:
        signal.alarm(120); r = select(tuple(u)); signal.alarm(0)
    except Exception as e:
        signal.alarm(0)
        stats["EXC:" + tag + ":" + type(e).__name__] += 1
        if len(fails) < 30: fails.append((tag, list(u), type(e).__name__, str(e)[:200]))
        return
    dt = time.time() - t0
    ok = oracle(u, r.time); key = tag + ":" + r.branch
    stats[key] += 1; tmax[r.branch] = max(tmax[r.branch], dt); ex.setdefault(r.branch, (list(u), str(r.time), r.shortest_relation_squared, r.plane_determinant))
    if not ok:
        stats["ORACLE_FAIL"] += 1; fails.append((tag, list(u), "oracle", str(r.time)))
    if dt > 5: print("SLOW %.1f s" % dt, tag, r.branch, r.shortest_relation_squared, r.plane_determinant, [len(str(abs(x))) for x in u], flush=True)
    if sum(stats.values()) % 500 == 0: print("progress", sum(stats.values()), "%.0f s" % (time.time() - T0), dict(stats), flush=True)
def signed(u, rng): return [x * rng.choice((1, -1)) for x in u]
def prim_in(rows, rng, scale):
    """random primitive integer vector in the kernel of rows, with large coefficients"""
    K = int_kernel(rows)
    if any(all(k[j] == 0 for k in K) for j in range(5)): raise ValueError("forced zero speed")
    for _ in range(200):
        c = [rng.randrange(-scale, scale + 1) for _ in K]
        if gcd(*c) != 1: continue
        u = [sum(ci * k[j] for ci, k in zip(c, K)) for j in range(5)]
        if all(u) : return u
    raise ValueError("no sample")
seed = int(sys.argv[1]); N = int(sys.argv[2]); rng = random.Random(seed)
T0 = time.time()
# A: uniform at many scales
for i in range(N):
    cap = rng.choice((150, 400, 2000, 10**4, 10**6, 10**12, 10**30, 10**60))
    run(signed([rng.randrange(1, cap) for _ in range(5)], rng), "A")
# B: inputs forced onto low-dimensional rational subspaces with small relations
for i in range(N):
    k = rng.choice((1, 2, 3)); rows = []
    while len(rows) < k:
        z = [rng.randint(-3, 3) for _ in range(5)]
        if any(z): rows.append(z)
    if len(int_kernel(rows)) != 5 - k: continue
    scale = rng.choice((10, 100, 10**4, 10**9, 10**25))
    try: u = prim_in(rows, rng, scale)
    except Exception: continue
    run(u, "B%d" % k)
# C: duplicates, signs, common factors, tiny entries
for i in range(N // 4):
    base = [rng.randrange(1, rng.choice((20, 300, 10**8))) for _ in range(rng.randint(1, 5))]
    u = [rng.choice(base) for _ in range(5)]; g = rng.choice((1, 2, 6, 35, 10**10))
    run(signed([x * g for x in u], rng), "C")
print("seed %d done in %.0f s" % (seed, time.time() - T0))
print("counts:", dict(sorted(stats.items())))
print("max seconds per branch:", {k: round(v, 3) for k, v in tmax.items()})
print("failures:", fails)
json.dump({"stats": stats, "tmax": tmax, "examples": ex, "fails": fails}, open("stress_%d.json" % seed, "w"), default=str)
