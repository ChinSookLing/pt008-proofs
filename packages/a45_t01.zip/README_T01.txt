PT008-TF-R002-A45-T01 (Hesper) — Z=7 tail, z1=(2,1,1,1,0), TAIL 21609, range 729<=D<=4630. Status: TEST (awaiting chair).
Batches: S=|p|^2 of the reduced short basis vector (=lambda1^2, partitions planes), S=1..78 (S=78 empty).
Run:   for s in 1..78: python3 t01.py $s 729 4630 r_s$s fast
Validation (D<=728, default gen.py centre rule): for s in 1..31: python3 t01.py $s 1 728 v_s$s  -> validation_D728.log
       plane set = probe728.tsv (358,794, identical); spectral 305,938; poly 52,832; R3-R7 24; fail 0.
Steps per plane: SPEC spectral criterion at grid centre; POLY single uncut safe cell, all polar vertices f<=21609
  (polar vertices = +-d_i/W_i, d_i=(q_i,-p_i) for each edge strip i, W_i = width of l_i over the cell; f(d_i)=|q_i p - p_i q|^2);
  R37 = intersection of polar polygons of centre cell + positive-margin cells at the 58 R3-R7 points, all vertices f<=21609;
  FULL = primitive (a,b) in that intersection with |U|^2>=21609, exact orbit check at boundary times t=(6k+1)/(6|U_i|).
Centre rule 'fast': grid N=60; if its cell does not close, N=240 (gen.py comparison of rho^2). Floats decide only outside 1e-9 band; band cases go exact (0 occurred).
Files: batch_stats.tsv; exceptions.txt (R37/FULL planes with p,q,D and max f on intersection, FULL with residual count);
       exc_vertices.tsv.gz (exact polar vertices of the single polygon for those planes); certs r_s*_cert.tsv.gz (p q D N ix iy step).
