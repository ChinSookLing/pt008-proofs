# For every plane not closed by the single polygon (steps R37/FULL), list exact polar vertices of the single uncut polygon. Hesper.
import gzip,sys
from fractions import Fraction as F
sys.argv=[sys.argv[0],'1','1','1','x']  # t01 needs argv; we only import helpers
src=open('t01.py').read().replace('\nmain()\n','\n')
g={}; exec(compile(src,'t01.py','exec'),g)
out=gzip.open('exc_vertices.tsv.gz','wt'); n=0
for s in range(1,79):
    for l in gzip.open(f'r_s{s}_cert.tsv.gz','rt'):
        f=l.rstrip('\n').split('\t')
        if f[6] not in('R37','FULL'): continue
        p=list(map(int,f[0].split(',')));q=list(map(int,f[1].split(',')));N,ix,iy=int(f[3]),int(f[4]),int(f[5])
        c=g['cell_exact'](p,q,F(ix,N),F(iy,N))
        vs=[] if c is None else [(a,b,g['fval'](p,q,a,b)) for a,b in c[1]]
        out.write(f"{f[0]}\t{f[1]}\t{f[2]}\t{f[6]}\t{N},{ix},{iy}\t"+';'.join(f"({a},{b}):{v}" for a,b,v in vs)+"\n"); n+=1
out.close(); print('rows',n)
