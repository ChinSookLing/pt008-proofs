# A45-T01 (Hesper): Z=7 tail, z1=(2,1,1,1,0), TAIL=21609. Streaming plane certificate by batch s=|p|^2 (p = shortest vector).
# usage: python3 t01.py S DMIN DMAX OUTPREFIX
# Steps per plane: (1) spectral criterion at grid centre (gen.py centre rule: N=60, then N=240 if trace fails)
#                  (2) single uncut safe polygon (cell of centre): every polar vertex f<=TAIL
#                  (3) R3-R7 polygons: intersection of polar polygons, every vertex f<=TAIL
#                  (4) full: primitive (a,b) in open intersection with f>=TAIL, exact orbit check (A39 boundary times)
# Centre rule: default = gen.py (N=60, N=240 if trace fails). 'fast' = stop at N=60 when its cell already closes the plane.
# Floating decisions are used only outside a 1e-9 relative band; inside the band the exact Fraction path decides.
import sys, math, gzip, hashlib, numpy as np
from fractions import Fraction as F
from math import gcd
import numba as nb
Z1=(2,1,1,1,0); TAIL=21609
S=int(sys.argv[1]); DMIN=int(sys.argv[2]); DMAX=int(sys.argv[3]); OUT=sys.argv[4]; FAST=len(sys.argv)>5 and sys.argv[5]=='fast'

@nb.njit(cache=True)
def enum_vecs(M):
    r=int(math.sqrt(M))+1; cnt=0
    out=np.zeros((1,5),np.int16)
    for pass_ in range(2):
        if pass_==1: out=np.zeros((cnt,5),np.int16); cnt=0
        for v0 in range(-r,r+1):
            for v2 in range(-r,r+1):
                for v3 in range(-r,r+1):
                    v1=-2*v0-v2-v3
                    n3=v0*v0+v1*v1+v2*v2+v3*v3
                    if n3>M: continue
                    for v4 in range(-r,r+1):
                        n=n3+v4*v4
                        if n==0 or n>M: continue
                        # first nonzero positive
                        f=v0
                        if f==0: f=v1
                        if f==0: f=v2
                        if f==0: f=v3
                        if f==0: f=v4
                        if f<0: continue
                        if pass_==1:
                            out[cnt,0]=v0;out[cnt,1]=v1;out[cnt,2]=v2;out[cnt,3]=v3;out[cnt,4]=v4
                        cnt+=1
    return out

@nb.njit(cache=True)
def igcd(a,b):
    a=abs(a);b=abs(b)
    while b: a,b=b,a%b
    return a

@nb.njit(cache=True)
def pairs(P,Q,nq,s,dmin,dmax):
    cnt=0; outp=np.zeros((1,),np.int64); outq=np.zeros((1,),np.int64)
    for pass_ in range(2):
        if pass_==1: outp=np.zeros(cnt,np.int64); outq=np.zeros(cnt,np.int64); cnt=0
        for a in range(P.shape[0]):
            for b in range(Q.shape[0]):
                d=0
                for i in range(5): d+=P[a,i]*Q[b,i]
                if 2*abs(d)>s: continue
                D=s*nq[b]-d*d
                if D<dmin or D>dmax: continue
                g=0; ok=True
                for i in range(5):
                    if P[a,i]==0 and Q[b,i]==0: ok=False
                    for j in range(i+1,5):
                        m=P[a,i]*Q[b,j]-P[a,j]*Q[b,i]; g=igcd(g,m)
                        if (P[a,i]==P[a,j] and Q[b,i]==Q[b,j]) or (P[a,i]==-P[a,j] and Q[b,i]==-Q[b,j]): ok=False
                if g!=1 or not ok: continue
                if pass_==1: outp[cnt]=a; outq[cnt]=b
                cnt+=1
    return outp,outq

@nb.njit(cache=True)
def best_centre(p,q,N):
    best=-1e18; bi=0
    for k in range(N*N):
        X=(k//N)/N; Y=(k%N)/N; sv=0.0
        for i in range(5):
            f=(p[i]*X+q[i]*Y)%1.0
            dd=(min(f,1.0-f)-1.0/6.0)/math.hypot(p[i],q[i])
            if i==0 or dd<sv: sv=dd
        if sv>best: best=sv; bi=k
    return bi

@nb.njit(cache=True)
def exact_rr(p,q,ix,iy,N):
    # rr = A/(36 N^2 B); returns (A,B) or (-1,1) if not positive margin
    A=-1; B=1
    for i in range(5):
        m=(p[i]*ix+q[i]*iy)%N
        mm=min(m,N-m); dd=6*mm-N
        if dd<=0: return -1,1
        a=dd*dd; b=p[i]*p[i]+q[i]*q[i]
        if A<0 or a*B<A*b: A=a; B=b
    return A,B

@nb.njit(cache=True)
def cell_check(p,q,ix,iy,N,T):
    # cell of point (ix/N,iy/N). returns status: 1 closed, 0 fail, 2 ambiguous, -1 degenerate; and max polar f (float)
    k=np.zeros(5,np.int64)
    for i in range(5): k[i]=(p[i]*ix+q[i]*iy)//N
    VX=np.zeros(64,np.int64);VY=np.zeros(64,np.int64);VD=np.zeros(64,np.int64);nv=0
    for li in range(10):
        i=li//2; Ci=6*k[i]+(1 if li%2==0 else 5)
        for lj in range(li+1,10):
            j=lj//2
            if j==i: continue
            Cj=6*k[j]+(1 if lj%2==0 else 5)
            dl=p[i]*q[j]-p[j]*q[i]
            if dl==0: continue
            X=Ci*q[j]-Cj*q[i]; Y=p[i]*Cj-p[j]*Ci; Dn=6*dl
            if Dn<0: X=-X;Y=-Y;Dn=-Dn
            ok=True
            for m in range(5):
                L=6*(p[m]*X+q[m]*Y)
                if L<(6*k[m]+1)*Dn or L>(6*k[m]+5)*Dn: ok=False; break
            if not ok: continue
            dup=False
            for t in range(nv):
                if X*VD[t]==VX[t]*Dn and Y*VD[t]==VY[t]*Dn: dup=True; break
            if not dup: VX[nv]=X;VY[nv]=Y;VD[nv]=Dn;nv+=1
    if nv<3: return -1,0.0
    st=1; mx=0.0
    for i in range(5):
        # edge on strip i? count vertices on either boundary line
        on=0
        for side in range(2):
            C=6*k[i]+(1 if side==0 else 5); c=0
            for t in range(nv):
                if 6*(p[i]*VX[t]+q[i]*VY[t])==C*VD[t]: c+=1
            if c>=2: on=1
        if on==0: continue
        lo=1e18;hi=-1e18
        for t in range(nv):
            v=(p[i]*VX[t]+q[i]*VY[t])/VD[t]
            if v<lo: lo=v
            if v>hi: hi=v
        W=hi-lo; f=0
        for j in range(5):
            u=q[i]*p[j]-p[i]*q[j]; f+=u*u
        val=f/(W*W)
        if val>mx: mx=val
        if val>T*(1+1e-9): st=0
        elif val>T*(1-1e-9) and st==1: st=2
    return st,mx

@nb.njit(cache=True)
def run_planes(P,Q,ip,iq,T,FAST):
    n=ip.shape[0]
    out=np.zeros((n,8),np.int64)  # N ix iy spec(0/1/2) poly(-1/0/1/2) A B trace
    mxv=np.zeros(n,np.float64)
    p=np.zeros(5,np.int64);q=np.zeros(5,np.int64)
    for t in range(n):
        for i in range(5): p[i]=P[ip[t],i]; q[i]=Q[iq[t],i]
        pp=0;qq=0;pq=0
        for i in range(5): pp+=p[i]*p[i]; qq+=q[i]*q[i]; pq+=p[i]*q[i]
        tr=pp+qq
        bA=-1;bB=1;bN=0;bk=0
        for N in (60,240):
            k=best_centre(p,q,N); A,B=exact_rr(p,q,k//N,k%N,N)
            if A>=0:
                # compare A/(N^2 B) > bA/(bN^2 bB)
                if bA<0 or A*bN*bN*bB>bA*N*N*B: bA=A;bB=B;bN=N;bk=k
            if bA>=0 and 4*T*bA>=tr*36*bN*bN*bB: break
            if FAST and N==60 and bA>=0:
                st0,mx0=cell_check(p,q,bk//bN,bk%bN,bN,T)
                if st0==1: break
        if bA<0:
            out[t,0]=0; out[t,3]=0; out[t,4]=-2; continue
        out[t,0]=bN;out[t,1]=bk//bN;out[t,2]=bk%bN;out[t,5]=bA;out[t,6]=bB
        out[t,7]=1 if 4*T*bA>=tr*36*bN*bN*bB else 0
        c=4.0*T*bA/(36.0*bN*bN*bB)
        g1=c-pp; g2=c-qq; lhs=g1*g2; rhs=float(pq)*pq
        if g1<-1e-9*c or g2<-1e-9*c or lhs<rhs*(1-1e-9)-1e-9: sp=0
        elif g1>1e-9*c and g2>1e-9*c and lhs>rhs*(1+1e-9)+1e-9: sp=1
        else: sp=2
        out[t,3]=sp
        if sp==1: out[t,4]=1; continue
        st,mx=cell_check(p,q,bk//bN,bk%bN,bN,T); out[t,4]=st; mxv[t]=mx
    return out,mxv

# ---------------- exact Python paths ----------------
def spectral_exact(p,q,A,B,N):
    c=F(4*TAIL*A,36*N*N*B); pp=sum(x*x for x in p); qq=sum(x*x for x in q); pq=sum(x*y for x,y in zip(p,q))
    return c>=pp and c>=qq and (c-pp)*(c-qq)>=pq*pq

def cell_exact(p,q,x0,y0):
    """exact cell of point (x0,y0) (Fractions) if positive margin; returns (verts, polar verts list) or None"""
    for i in range(5):
        f=(p[i]*x0+q[i]*y0)%1
        if min(f,1-f)<=F(1,6): return None
    k=[math.floor(p[i]*x0+q[i]*y0) for i in range(5)]
    lines=[(i,k[i]+F(1,6)) for i in range(5)]+[(i,k[i]+F(5,6)) for i in range(5)]
    V=[]
    for a in range(10):
        for b in range(a+1,10):
            i,ci=lines[a]; j,cj=lines[b]
            dl=p[i]*q[j]-p[j]*q[i]
            if i==j or dl==0: continue
            x=(ci*q[j]-cj*q[i])/dl; y=(p[i]*cj-p[j]*ci)/dl
            if all(k[m]+F(1,6)<=p[m]*x+q[m]*y<=k[m]+F(5,6) for m in range(5)) and (x,y) not in V: V.append((x,y))
    if len(V)<3: return None
    polar=[]
    for i in range(5):
        vals=[p[i]*x+q[i]*y for x,y in V]
        edge=any(sum(1 for v in vals if v==c)>=2 for c in (k[i]+F(1,6),k[i]+F(5,6)))
        if not edge: continue
        W=max(vals)-min(vals); d=(q[i],-p[i])
        polar.append((F(d[0])/W,F(d[1])/W)); polar.append((-F(d[0])/W,-F(d[1])/W))
    return V,polar

def fval(p,q,a,b): return sum((a*x+b*y)**2 for x,y in zip(p,q))

def hull(pts):
    pts=sorted(set(pts))
    if len(pts)<3: return pts
    def cr(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lo=[];up=[]
    for pt in pts:
        while len(lo)>=2 and cr(lo[-2],lo[-1],pt)<=0: lo.pop()
        lo.append(pt)
    for pt in reversed(pts):
        while len(up)>=2 and cr(up[-2],up[-1],pt)<=0: up.pop()
        up.append(pt)
    return lo[:-1]+up[:-1]

def clip(poly,a,b,c):
    # keep a*x+b*y<=c
    out=[]; n=len(poly)
    for i in range(n):
        P1=poly[i];P2=poly[(i+1)%n]
        v1=a*P1[0]+b*P1[1]-c; v2=a*P2[0]+b*P2[1]-c
        if v1<=0: out.append(P1)
        if (v1<0<v2) or (v2<0<v1):
            t=v1/(v1-v2); out.append((P1[0]+t*(P2[0]-P1[0]),P1[1]+t*(P2[1]-P1[1])))
    return out

def polys_intersection(polars):
    cur=hull(polars[0])
    for pl in polars[1:]:
        h=hull(pl); n=len(h)
        for i in range(n):
            A=h[i];B=h[(i+1)%n]
            # inside is left of A->B (ccw hull): cross(B-A, X-A)>=0  ->  -(By-Ay)x+(Bx-Ax)y <= ... rewrite
            a=(B[1]-A[1]); b=-(B[0]-A[0]); c=a*A[0]+b*A[1]
            cur=clip(cur,a,b,c)
            if not cur: return []
    return cur

def orbit_hit(U):
    u=[abs(x) for x in U]
    for i in range(5):
        ui=u[i]
        if not ui: continue
        m=6*ui
        for k in range(ui):
            s=(6*k+1)%m; ok=True
            for j in range(5):
                r=(s*(u[j]%m))%m
                if min(r,m-r)<ui: ok=False;break
            if ok: return (i,k)
    return None

RPTS=[]
for kk in range(3,8):
    for i in range(kk):
        for j in range(kk):
            if (i,j)==(0,0): continue
            if math.gcd(math.gcd(i,j),kk)!=1: continue
            if ((-i)%kk,(-j)%kk) in [(a*kk,b*kk) for a,b in []]: pass
            RPTS.append((F(i,kk),F(j,kk)))
# keep one of each +-pair
_seen=set(); _R=[]
for x,y in RPTS:
    key=(x,y); neg=((-x)%1,(-y)%1)
    if neg in _seen: continue
    _seen.add(key); _R.append((x,y))
RPTS=_R
assert len(RPTS)==58, len(RPTS)

def slow_path(p,q,centre):
    """steps 3/4 exactly. centre=(x0,y0) Fractions or None. returns (step, info)"""
    polars=[]; vmax_info=None
    if centre is not None:
        c=cell_exact(p,q,*centre)
        if c: polars.append(c[1])
    for x,y in RPTS:
        c=cell_exact(p,q,x,y)
        if c: polars.append(c[1])
    if not polars: return 'NOCELL',None
    K=polys_intersection(polars)
    if not K: return 'R37',0
    mxf=max(fval(p,q,a,b) for a,b in K)
    if mxf<=TAIL: return 'R37',mxf
    # full: primitive lattice points in K (closed, superset of open) with f>=TAIL
    xs=[a for a,b in K]; ys=[b for a,b in K]
    bad=[]; nres=0
    def inside(a,b):
        n=len(K)
        for i in range(n):
            A=K[i];B=K[(i+1)%n]
            if (B[0]-A[0])*(b-A[1])-(B[1]-A[1])*(a-A[0])<0: return False
        return True
    Kc=hull(K)
    K=Kc
    for a in range(math.floor(min(xs)),math.ceil(max(xs))+1):
        for b in range(max(0,math.floor(min(ys))),math.ceil(max(ys))+1):
            if b==0 and a<=0: continue
            if math.gcd(a,b)!=1 or not inside(a,b): continue
            U=[a*x+b*y for x,y in zip(p,q)]
            if sum(u*u for u in U)<TAIL: continue
            nres+=1
            if orbit_hit(U) is None: bad.append((a,b,U))
    if bad: return 'FAIL',(mxf,bad)
    return 'FULL',(mxf,nres)

def main():
    T=TAIL
    Qmax=(4*DMAX+S*S)//(4*S)
    V=enum_vecs(Qmax)
    nrm=(V.astype(np.int64)**2).sum(1)
    P=V[nrm==S].astype(np.int64); m=(nrm>=S)&(nrm<=Qmax); Q=V[m].astype(np.int64); nq=nrm[m]
    ip,iq=pairs(P,Q,nq,S,DMIN,DMAX)
    pairs_n=len(ip)
    # dedup by canonical Pluecker coordinates
    Pm=P[ip];Qm=Q[iq]
    mins=np.stack([Pm[:,i]*Qm[:,j]-Pm[:,j]*Qm[:,i] for i in range(5) for j in range(i+1,5)],1)
    fn=mins[np.arange(len(mins)),(mins!=0).argmax(1)] if len(mins) else np.zeros(0,np.int64)
    mins=mins*np.sign(fn)[:,None]
    if len(mins):
        _,first=np.unique(mins,axis=0,return_index=True); first=np.sort(first)
    else: first=np.zeros(0,np.int64)
    ip=ip[first];iq=iq[first]; n=len(ip)
    res,mxv=run_planes(P,Q,ip,iq,T,FAST)
    st=dict(S=S,DMIN=DMIN,DMAX=DMAX,pairs=pairs_n,planes=n,spectral=0,poly=0,r37=0,full=0,fail=0,nocell=0,amb_exact=0,full_resid=0,max_poly_vertex_f=0.0)
    exc=[]
    cert=gzip.open(OUT+'_cert.tsv.gz','wt')
    for t in range(n):
        p=[int(x) for x in P[ip[t]]]; q=[int(x) for x in Q[iq[t]]]
        D=sum(x*x for x in p)*sum(x*x for x in q)-sum(x*y for x,y in zip(p,q))**2
        N,ix,iy,sp,po,A,B,tr=[int(x) for x in res[t]]
        step=None
        if sp==2:
            st['amb_exact']+=1; sp=1 if spectral_exact(p,q,A,B,N) else 0
            if sp==0:
                po2,_=cell_check(np.array(p),np.array(q),ix,iy,N,T); po=int(po2)
        if sp==1: step='SPEC'; st['spectral']+=1
        else:
            if po==2:
                st['amb_exact']+=1; c=cell_exact(p,q,F(ix,N),F(iy,N))
                po=1 if c and all(fval(p,q,a,b)<=T for a,b in c[1]) else 0
            if po==1:
                step='POLY'; st['poly']+=1; st['max_poly_vertex_f']=max(st['max_poly_vertex_f'],float(mxv[t]))
            else:
                centre=(F(ix,N),F(iy,N)) if N else None
                s2,info=slow_path(p,q,centre)
                if s2=='R37': step='R37'; st['r37']+=1
                elif s2=='FULL': step='FULL'; st['full']+=1; st['full_resid']+=info[1]
                elif s2=='NOCELL': step='NOCELL'; st['nocell']+=1; exc.append(('NOCELL',p,q,D,None))
                else: step='FAIL'; st['fail']+=1; exc.append(('FAIL',p,q,D,info))
                if step in ('R37','FULL'): exc.append((step,p,q,D,info if step=='FULL' else info))
        cert.write(f"{','.join(map(str,p))}\t{','.join(map(str,q))}\t{D}\t{N}\t{ix}\t{iy}\t{step}\n")
    cert.close()
    with open(OUT+'_exc.txt','w') as f:
        for e in exc: f.write(repr(e)+'\n')
    st['max_poly_vertex_f']=round(st['max_poly_vertex_f'],3)
    print(st)
main()
