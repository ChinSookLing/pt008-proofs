A44 Z=8 tail (|U|^2>=21609), wedge^2<=246, shape (2,1,1,1,1) only. Hesper, WEB OFF.
Replay: python3 bound.py 8; bash run.sh A 2,1,1,1,1 246; python3 neon_rules.py planes_A.tsv
Expect: planes 28152 closed 27204 resid planes 948 resid inputs 13848 max|U|^2 54335 ALL PASS
verify.py = A43 v2 (streamed part C).
Closed planes use Lean lemmaT_T6 (commit d2128613), rounding floor(s+1/2); cert does no rounding. Residual times explicit rationals.
