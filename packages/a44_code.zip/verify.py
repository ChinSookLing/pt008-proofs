# A37 certificate verifier. Independent re-enumeration (different parametrization) + exact checks.
import numpy as np, math, sys
from fractions import Fraction as F
from math import gcd
Z1=tuple(map(int,sys.argv[1].split(','))); DETMAX=int(sys.argv[2]); TAIL=int(sys.argv[3]); PL=sys.argv[4]; RT=sys.argv[5]
def canon(m):
    for x in m:
        if x: return m if x>0 else tuple(-y for y in m)
# (A) re-enumerate: v3 dependent
R=4*DETMAX//3; r=int(math.isqrt(R)); a=np.arange(-r,r+1)
J=max((i for i in range(5) if Z1[i]),key=lambda i:(abs(Z1[i]),i))  # different dependent coord from gen.py (largest |coef|)
fr=[i for i in range(5) if i!=J]
W=[x.ravel() for x in np.meshgrid(a,a,a,a,indexing='ij')]
S=sum(Z1[i]*W[t] for t,i in enumerate(fr)); keep=(S%Z1[J]==0)
V=np.zeros((int(keep.sum()),5),dtype=np.int64)
for t,i in enumerate(fr): V[:,i]=W[t][keep]
V[:,J]=-S[keep]//Z1[J]; n=(V*V).sum(1); k=(n>0)&(n<=R); V=V[k]; n=n[k]
print('A: dependent coord',J)
assert not (V@np.array(Z1)).any()
keys=set()
for idx in np.nonzero(n*n<=R)[0]:
    p=V[idx]; pp=int(n[idx]); m=(n>=pp)&(n*pp<=R); Q=V[m]; d=Q@p
    ok=(2*np.abs(d)<=pp)&(pp*n[m]-d*d<=DETMAX)&(pp*n[m]-d*d>0)
    for q in Q[ok]:
        pl=[int(x) for x in p]; ql=[int(x) for x in q]
        mins=tuple(pl[i]*ql[j]-pl[j]*ql[i] for i in range(5) for j in range(i+1,5))
        g=0
        for x in mins: g=gcd(g,x)
        if g!=1: continue
        rows=list(zip(pl,ql))
        if any(rr==(0,0) for rr in rows) or any(rows[i]==rows[j] or rows[i]==(-rows[j][0],-rows[j][1]) for i in range(5) for j in range(i+1,5)): continue
        keys.add(canon(mins))
print('A: independent planes',len(keys))
# (B) plane table exact checks
fk=set(); res_planes={}; closed=0; tot=0
for l in open(PL):
    f=l.rstrip('\n').split('\t'); tot+=1
    assert f[4]!='NEG'
    p=list(map(int,f[0].split(','))); q=list(map(int,f[1].split(',')))
    assert sum(x*y for x,y in zip(p,Z1))==0 and sum(x*y for x,y in zip(q,Z1))==0
    mins=tuple(p[i]*q[j]-p[j]*q[i] for i in range(5) for j in range(i+1,5))
    g=0
    for x in mins: g=gcd(g,x)
    assert g==1 and sum(x*x for x in mins)==int(f[2])<=DETMAX
    tr=sum(x*x for x in p)+sum(x*x for x in q); assert tr==int(f[3])
    x0,y0,rr=F(f[4]),F(f[5]),F(f[6]); rows=list(zip(p,q)); mn=None
    for (pi,qi) in rows:
        t=(pi*x0+qi*y0)%1; dd=min(t,1-t)-F(1,6); assert dd>0
        v=dd*dd/(pi*pi+qi*qi); mn=v if mn is None else min(mn,v)
    assert mn==rr
    c=int(4*TAIL*rr>=tr); assert c==int(f[7]); closed+=c
    key=canon(mins); assert key not in fk; fk.add(key)
    if not c: res_planes[(f[0],f[1])]=(p,q,rr)
assert fk==keys
print('B: table planes',tot,'closed',closed,'residual planes',len(res_planes),'set equal to A: True')
# (C) residual exact recompute + safe time check, streamed per plane (memory-bounded; same checks as v1)
import itertools
def expected(p,q,rr,s0,s1):
    e=set(); Rb=math.isqrt(math.floor(1/(4*rr)))+1
    for a_ in range(-Rb,Rb+1):
        for b_ in range(0,Rb+1):
            if (b_==0 and a_<=0) or gcd(a_,b_)!=1 or 4*rr*(a_*a_+b_*b_)>=1: continue
            U=[a_*x+b_*y for x,y in zip(p,q)]
            if sum(x*x for x in U)>=TAIL: e.add((a_,b_))
    return e
done=set(); maxU=0; ngot=0
def lines():
    for l in open(RT):
        w=l.split(); yield (w[0],w[1]),w
for key,grp in itertools.groupby(lines(),key=lambda t:t[0]):
    assert key not in done; done.add(key)
    p,q,rr=res_planes[key]; got=set()
    for _,w in grp:
        a_,b_=int(w[2]),int(w[3]); U=list(map(int,w[4:9])); i,kk=int(w[9]),int(w[10])
        assert U==[a_*x+b_*y for x,y in zip(p,q)]
        u=[abs(x) for x in U]; m=6*u[i]; s=6*kk+1; assert 0<=kk<u[i]
        for x in u:
            rm=(s*x)%m; assert min(rm,m-rm)>=u[i]
        assert (a_,b_) not in got; got.add((a_,b_)); maxU=max(maxU,sum(x*x for x in U))
    assert got==expected(p,q,rr,*key); ngot+=len(got)
for key,(p,q,rr) in res_planes.items():
    if key not in done: assert not expected(p,q,rr,*key)
print('C: residual inputs',ngot,'all safe; max |U|^2',maxU)
print('ALL PASS')
