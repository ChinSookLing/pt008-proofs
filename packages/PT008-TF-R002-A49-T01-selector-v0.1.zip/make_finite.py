"""Prepare the fixed finite-branch residue masks (offline)."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json

CAP = 21608
MAX_SPEED = isqrt(CAP)
times = sorted({F(6*k+1, 6*v) for v in range(1, MAX_SPEED+1) for k in range(v)
                if 2*(6*k+1) <= 6*v} |
               {1-F(6*k+1, 6*v) for v in range(1, MAX_SPEED+1) for k in range(v)
                if 2*(6*k+1) > 6*v})
masks = {}
for v in range(1, MAX_SPEED+1):
    flags = bytearray((len(times)+7)//8)
    for i,t in enumerate(times):
        r = (v*t.numerator)%t.denominator
        if 6*min(r,t.denominator-r)>=t.denominator:
            flags[i//8] |= 1<<(i%8)
    masks[v] = format(int.from_bytes(flags,'little'),'x')
Path(__file__).with_name('finite.json').write_text(json.dumps({
    'times': [[t.numerator,t.denominator] for t in times], 'masks': masks},
    separators=(',',':'))+'\n', encoding='utf-8')
