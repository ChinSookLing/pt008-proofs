"""PT-008 A49: exact rational six-runner selection."""
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import gcd
from pathlib import Path
import argparse
import json

from lattice import (affine_integer, bezout, combo, coordinates, dot, dual,
                     gso, hkz, identity, image_basis, kernel, lift_projection,
                     lll, nearest, project, sub)
from poly45 import rule

HALF = [F(1,2)]*5
TAIL = 21609
MIDDLE_BOUNDS = {6:647,7:4630,8:246,9:728,10:289,11:521,12:332,13:540}


@dataclass(frozen=True)
class Selection:
    time: F
    branch: str
    shortest_relation_squared: int | None
    plane_determinant: int | None = None


def safe(speeds,t):
    n,d = t.numerator,t.denominator
    for v in speeds:
        r = v*n%d
        if 6*min(r,d-r)<d:
            return False
    return True


@lru_cache(maxsize=1)
def finite_table():
    data=json.loads(Path(__file__).with_name('finite.json').read_text(encoding='utf-8'))
    return data['times'],{int(v):int(s,16) for v,s in data['masks'].items()}


def short_input(U):
    times,masks=finite_table()
    bits=masks[U[0]]
    for v in U[1:]:
        bits &= masks[v]
    if not bits:
        raise ArithmeticError('finite certificate did not provide a witness')
    i=(bits & -bits).bit_length()-1
    return F(*times[i])


def centred(c,normals):
    """Integer translate with c in the orthogonal space, where certified."""
    rhs=[dot(v,c) for v in normals]
    assert all(F(x).denominator==1 for x in rhs)
    point,_=affine_integer(normals,[int(x) for x in rhs])
    return sub(c,point)


def time_at(U,bez,centre,gamma,normals):
    orth,_,_=gso(normals+[list(U)])
    target=project(centre,orth)
    y=nearest(gamma,target)
    residual=sub(centre,lift_projection(y,U,bez))
    return F(dot(residual,U),dot(U,U))%1


def first_center(z,Z):
    if Z==4:
        return centred(HALF,[z])
    if Z==5 and max(map(abs,z))==1:
        return centred([F(2 if x>0 else -2,5) for x in z],[z])
    c=[F(1,3)]*5
    support=sorted((i for i in range(5) if z[i]),key=lambda i:-abs(z[i]))
    for i in support:
        c[i]=F(1 if z[i]>0 else -1,3)
    c[support[-1]]=-2*c[support[-1]]
    assert dot(z,c)==0
    return c


def centre_grid(base,denominators,start=None):
    """Read a strict centre from bounded lattice-coordinate grids, exactly."""
    best,c = (F(0),None) if start is None else start
    for d in denominators:
        if F(d//2,d)-F(1,6)<=best:
            continue
        cols = [tuple(x%d for x in col) for col in zip(*base)]
        for co in product(range(d),repeat=len(base)):
            min_residue=d//2
            for col in cols:
                x=dot(co,col)%d
                min_residue=min(min_residue,x,d-x)
                if 6*min_residue*best.denominator <= d*(6*best.numerator+best.denominator):
                    break
            else:
                best,c=F(min_residue,d)-F(1,6),[F(x,d) for x in combo(co,base)]
                if min_residue==d//2:
                    break
    return best,c


def plane_time(U,p,q):
    a,b=coordinates([p,q],U)
    assert a.denominator==b.denominator==1 and gcd(int(a),int(b))==1
    witness=rule(p,q,int(a),int(b))
    if witness is None:
        raise ArithmeticError('A45 phase region did not provide a witness')
    return witness[0]


def reduced_plane(rows):
    _,base=lll(rows,rows)
    p,q=base
    D=dot(p,p)*dot(q,q)-dot(p,q)**2
    return p,q,D


def low_relation(U,bez,relations,z,Z):
    c=first_center(z,Z)
    rows,lifts=image_basis(relations,[z])
    d,lifts=hkz(rows,lifts)
    first_margin=min(min(x%1,1-x%1) for x in c)-F(1,6)
    if dot(d[0],d[0])>=F(37,36)/first_margin**2:
        return Selection(time_at(U,bez,c,dual(d)[::-1],[z]),'rank3',Z)
    z2=sub(lifts[0],z,round(F(dot(lifts[0],z),Z)))
    assert dot(z2,z2)<={3:37,4:10,5:19 if max(map(abs,z))==1 else 37}[Z]
    # Saturating the normal rows is unnecessary for their homogeneous integer kernel.
    normals=[z,z2]
    W=kernel(normals)
    _,W=lll(W,W)
    m,c=centre_grid(W,(2,6,4,12,11,10,9,8,7,5,3))
    if c is None:
        raise ArithmeticError('missing certified rank-three centre')
    rows,lifts=image_basis(relations,normals)
    d,lifts=hkz(rows,lifts)
    if dot(d[0],d[0])>=F(7,12)/m**2:
        return Selection(time_at(U,bez,c,dual(d)[::-1],normals),'rank2',Z)
    normals=normals+[lifts[0]]
    p,q,D=reduced_plane(kernel(normals))
    m,c=centre_grid([p,q],(2,6,4,12,11,10,9,8,7,5,3))
    if c is None:
        m,c=centre_grid([p,q],range(13,25))
    if c is not None and 4*m*m*dot(U,U)>=D:
        d,_=image_basis(relations,normals)
        return Selection(time_at(U,bez,c,dual(d),normals),'rank1',Z,D)
    return Selection(plane_time(U,p,q),'plane-low',Z,D)


def geometric(U):
    relations=kernel([U])
    _,bez=bezout(U)
    d,_=hkz(relations,relations)
    z=d[0]
    Z=dot(z,z)
    if Z>=15:
        return Selection(time_at(U,bez,HALF,dual(d)[::-1],[]),'rank4',Z)
    if Z<=5:
        return low_relation(U,bez,relations,z,Z)
    if Z==14:
        rows,lifts=image_basis(relations,[z])
        d,_=hkz(rows,lifts)
        assert 4*dot(d[0],d[0])>=37
        return Selection(time_at(U,bez,centred(HALF,[z]),dual(d)[::-1],[z]),'rank3-Z14',Z)
    (shift,_)=affine_integer([z],[round(dot(HALF,z))])
    c=sub(HALF,shift)
    rows,lifts=image_basis(relations,[z])
    d,_=lll(rows,lifts)
    gamma=dual(d)[::-1]
    _,sizes,_=gso(gamma)
    if sum(sizes)*Z<=F(4*Z,9)-Z%2:
        return Selection(time_at(U,bez,c,gamma,[z]),'middle-babai',Z)
    v=lift_projection(gamma[0],U,bez)
    p,q,D=reduced_plane([list(U),v])
    assert D<=MIDDLE_BOUNDS[Z],(Z,D,U)
    return Selection(plane_time(U,p,q),'plane-middle',Z,D)


def select(speeds):
    speeds=tuple(speeds)
    if len(speeds)!=5 or any(type(v) is not int or v==0 for v in speeds):
        raise ValueError('five nonzero integer relative speeds are required')
    common=gcd(*speeds)
    values={abs(v)//common for v in speeds}
    fill=1
    while len(values)<5:
        values.add(fill)
        fill+=1
    U=tuple(sorted(values))
    result=(Selection(short_input(U),'finite',None) if dot(U,U)<TAIL else geometric(U))
    t=result.time/common
    if not safe(speeds,t):
        raise ArithmeticError('final exact distance verification failed')
    return Selection(t,result.branch,result.shortest_relation_squared,result.plane_determinant)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('speeds',nargs=5,type=int)
    args=parser.parse_args()
    try:
        r=select(args.speeds)
    except (ValueError,ArithmeticError) as exc:
        parser.error(str(exc))
    print(json.dumps({'time':str(r.time),'numerator':r.time.numerator,'denominator':r.time.denominator,
                      'branch':r.branch,'Z':r.shortest_relation_squared,'D':r.plane_determinant,
                      'verified':True}))


if __name__=='__main__':
    main()
