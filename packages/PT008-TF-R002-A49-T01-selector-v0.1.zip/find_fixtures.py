from concurrent.futures import ProcessPoolExecutor
from random import Random
from collections import Counter
from selector import select

def run(seed):
    rnd=Random(seed)
    seen={}
    counts=Counter()
    for i in range(180):
        cap=(145,210,350,1100,10**20)[i%5]
        u=rnd.sample(range(1,cap),5) if cap<10**10 else [rnd.randrange(1,cap) for _ in range(5)]
        if i%7==0:
            a,b=u[:2]
            u[2]=a+b
        r=select(u)
        key=(r.branch,r.shortest_relation_squared if r.branch=='plane-middle' else None)
        counts[key]+=1
        seen.setdefault(key,u)
    return counts,seen
if __name__=='__main__':
    out={}
    c=Counter()
    with ProcessPoolExecutor(max_workers=8) as p:
        for a,b in p.map(run,range(880,888)):
            c.update(a)
            for k,v in b.items():out.setdefault(k,v)
    for k,n in sorted(c.items()):
        print(k,n,out[k],select(out[k]),flush=True)
