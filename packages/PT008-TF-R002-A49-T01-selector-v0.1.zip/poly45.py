# A45 (Opus, independent): exact implementation of the safe-polygon time rule, as used by the selector.
# Everything is exact (fractions.Fraction); no floating point anywhere in a decision.
from fractions import Fraction as F
from math import gcd, floor, ceil
SIX = F(1, 6); FIVE6 = F(5, 6)
def egcd(a, b):
    if b == 0: return (abs(a), 1 if a >= 0 else -1, 0)
    g, x, y = egcd(b, a % b); return g, y, x - (a // b) * y
def clip(poly, A, B, C):
    """closed half-plane A x + B y + C >= 0 applied to a convex polygon given as a vertex list (degenerate lists allowed)."""
    out = []; n = len(poly)
    if n == 0: return out
    f = [A * x + B * y + C for (x, y) in poly]
    for i in range(n):
        S, E = poly[i - 1], poly[i]; fs, fe = f[i - 1], f[i]
        if fe >= 0:
            if fs < 0: c = fs / (fs - fe); out.append((S[0] + c * (E[0] - S[0]), S[1] + c * (E[1] - S[1])))
            out.append(E)
        elif fs >= 0:
            c = fs / (fs - fe); out.append((S[0] + c * (E[0] - S[0]), S[1] + c * (E[1] - S[1])))
    ded = []
    for v in out:
        if not ded or ded[-1] != v: ded.append(v)
    if len(ded) > 1 and ded[0] == ded[-1]: ded.pop()
    return ded
def polygons(p, q):
    """all nonempty P_k = [0,1]^2 ∩ ∩_i {k_i + 1/6 <= p_i x + q_i y <= k_i + 5/6}; returns list of (k, vertices). Feasible k_i range:
       ceil(min l_i - 5/6) .. floor(max l_i - 1/6) over the square (min/max at the corners)."""
    sq = [(F(0), F(0)), (F(1), F(0)), (F(1), F(1)), (F(0), F(1))]
    res = [((), sq)]
    for pi, qi in zip(p, q):
        vals = [pi * x + qi * y for x, y in sq]; lo = ceil(min(vals) - FIVE6); hi = floor(max(vals) - SIX)
        new = []
        for k, P in res:
            for ki in range(lo, hi + 1):
                Q = clip(P, F(pi), F(qi), -(ki + SIX))
                if Q: Q = clip(Q, F(-pi), F(-qi), ki + FIVE6)
                if Q: new.append((k + (ki,), Q))
        res = new
    return res
def rule(p, q, a, b, polys=None):
    """the A45 rule: returns (t, k, X, kind) for the first polygon hit, or None."""
    g, al, be = egcd(a, b); assert g == 1 and al * a + be * b == 1
    for k, P in (polys if polys is not None else polygons(p, q)):
        hs = [b * x - a * y for x, y in P]; m = min(hs); M = max(hs); j = ceil(m)
        if j <= M:
            Xm = P[hs.index(m)]; Xp = P[hs.index(M)]
            if m < M:
                c = (j - m) / (M - m); X = (Xm[0] + c * (Xp[0] - Xm[0]), Xm[1] + c * (Xp[1] - Xm[1])); kind = "interp"
            else:
                X = Xm; kind = "m=M"
            t = (al * X[0] + be * X[1]) % 1
            deg = "point" if len(set(P)) == 1 else ("segment" if len(set(P)) == 2 or area2(P) == 0 else "2d")
            return t, k, X, kind, deg
    return None
def area2(P):
    return abs(sum(P[i][0] * P[(i + 1) % len(P)][1] - P[(i + 1) % len(P)][0] * P[i][1] for i in range(len(P))))
