"""Deterministic interface and branch fixtures for the A49 selector."""
from fractions import Fraction
from itertools import product
from random import Random
from selector import select,finite_table
from lattice import combo,dot,hkz


def verify_independent(u,t):
    assert all(abs(v*t-round(v*t))>=Fraction(1,6) for v in u)


def main():
    cases = [
        ((1,2,3,4,5),'finite',None),
        ((1,2,5,53,137),'finite',None),
        ((1,2,6,72,128),'rank1',5),
        ((1,2,4,58,135),'rank2',5),
        ((98,71,154,11,21),'middle-babai',9),
        ((62,94,156,77,37),'rank1',3),
        ((50,154,204,274,332),'rank2',3),
        ((9,27,190,226,713),'rank2',4),
        ((5,11,107,158,281),'rank2',5),
        ((92171460289564589366,86094982621559553365,178266442911124142731,
          97854857070214286288,97629092665930607896),'rank3',3),
        ((326,158,43,288,203),'rank3-Z14',14),
        ((803,161,672,579,601),'rank4',19),
        ((3,6,9,48,139),'plane-low',3),
        ((14,-67,-87,112,-70),'plane-middle',7),
    ]
    for u, branch, Z in cases:
        out=select(u)
        assert (out.branch,out.shortest_relation_squared)==(branch,Z),(u,out)
        verify_independent(u,out.time)
        scaled=tuple(v*(-1 if i%2 else 1)*17 for i,v in enumerate(reversed(u)))
        assert select(scaled).time==out.time/17
        verify_independent(scaled,out.time/17)
        print(u,out)
    assert select((1,2,3,4,5)).time==Fraction(1,6)
    for u in [(-8,8,-8,16,16), (1,1,2,3,10**30)]:
        verify_independent(u,select(u).time)
    for u in [(0,1,2,3,4), (1,2,3,4), (True,2,3,4,5)]:
        try:
            select(u)
        except ValueError:
            continue
        raise AssertionError(u)
    print('interface, boundary and scale fixtures passed')

    times,masks=finite_table()
    for v,mask in masks.items():
        for i,pair in enumerate(times):
            phase=v*Fraction(*pair)
            assert bool((mask>>i)&1)==(abs(phase-round(phase))>=Fraction(1,6))
    print('finite certificate mask bits checked:',len(times)*len(masks))

    rng=Random(86271)
    for _ in range(100):
        rows=[[rng.randint(1,12),0,0],[rng.randint(-6,6),rng.randint(1,12),0],
              [rng.randint(-6,6),rng.randint(-6,6),rng.randint(1,12)]]
        base,lifts=hkz(rows,rows)
        assert base==lifts
        for k in product(range(-6,7),repeat=3):
            if any(k):
                v=combo(k,rows)
                assert dot(base[0],base[0])<=dot(v,v)
    print('exact HKZ shortest-vector cross-checks passed: 100')


if __name__=='__main__':
    main()
