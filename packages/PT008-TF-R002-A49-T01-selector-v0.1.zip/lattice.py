"""Exact integer lattices and nearest-plane arithmetic for the T6 selector."""
from fractions import Fraction as F
from math import gcd, isqrt, lcm


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def sub(a, b, c=1):
    return [x-c*y for x, y in zip(a, b)]


def combo(c, rows):
    return [dot(c, col) for col in zip(*rows)]


def identity(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]


def egcd(a, b):
    p, q, r, s = 1, 0, 0, 1
    while b:
        d, rem = divmod(a, b)
        a, b = b, rem
        p, q, r, s = r, s, p-d*r, q-d*s
    sign = 1 if a >= 0 else -1
    return sign*a, sign*p, sign*q


def bezout(v):
    coeff = []
    g = 0
    for x in v:
        g, a, b = egcd(g, x)
        coeff = [a*c for c in coeff] + [b]
    return g, coeff


def affine_integer(rows, rhs, n=5):
    """Return a particular solution and an integral basis of the homogeneous kernel."""
    base = identity(n)
    point = [0]*n
    for row, value in zip(rows, rhs):
        weights = [dot(row, v) for v in base]
        want = value-dot(row, point)
        g, co = bezout(weights)
        if not g:
            if want:
                raise ValueError('inconsistent integer equations')
            continue
        if want % g:
            raise ValueError('integer lift does not exist')
        step = combo(co, base)
        point = sub(point, step, -int(want//g))
        # Unimodular column operations isolate the image of this row.
        first = next(i for i,w in enumerate(weights) if w)
        base[0],base[first] = base[first],base[0]
        weights[0],weights[first] = weights[first],weights[0]
        for j,w in enumerate(weights[1:],1):
            if w:
                x = weights[0]
                d,a,b = egcd(x,w)
                old,cur = base[0],base[j]
                base[0],base[j] = combo([a,b],[old,cur]), combo([-w//d,x//d],[old,cur])
                weights[0] = d
        base = base[1:]
    return point, base


def kernel(rows,n=5):
    return affine_integer(rows,[0]*len(rows),n)[1]


def gso(rows):
    basis, sizes = [], []
    mu = [[F(0)]*len(rows) for _ in rows]
    for i, row in enumerate(rows):
        v = list(row)
        for j,b in enumerate(basis):
            mu[i][j] = F(dot(row,b),sizes[j])
            v = sub(v,b,mu[i][j])
        basis.append(v)
        sizes.append(dot(v,v))
    return basis, sizes, mu


def project(v, orthogonal):
    for b in orthogonal:
        v = sub(v,b,F(dot(v,b),dot(b,b)))
    return v


def image_basis(rows, normals):
    """Get a basis of the projected lattice while retaining integer lifts."""
    orth,_,_ = gso(normals)
    pts = [project(r,orth) for r in rows]
    factor = lcm(*(F(x).denominator for row in pts for x in row))
    pts = [[int(x*factor) for x in row] for row in pts]
    lifts = [list(v) for v in rows]
    rank = 0
    for j in range(len(pts[0])):
        p = next((i for i in range(rank,len(pts)) if pts[i][j]),None)
        if p is None:
            continue
        pts[p],pts[rank] = pts[rank],pts[p]
        lifts[p],lifts[rank] = lifts[rank],lifts[p]
        for i in range(rank+1,len(pts)):
            while pts[i][j]:
                k = pts[rank][j]//pts[i][j]
                pts[rank],pts[i] = pts[i],sub(pts[rank],pts[i],k)
                lifts[rank],lifts[i] = lifts[i],sub(lifts[rank],lifts[i],k)
        rank += 1
    return [[F(x,factor) for x in v] for v in pts[:rank]],lifts[:rank]


def lll(rows, lifts, delta=F(3,4)):
    rows,lifts = list(rows),list(lifts)
    if len(rows)<2:
        return rows,lifts
    _,sizes,mu = gso(rows)
    k = 1
    while k<len(rows):
        for j in range(k-1,-1,-1):
            c = round(mu[k][j])
            if c:
                rows[k],lifts[k] = sub(rows[k],rows[j],c),sub(lifts[k],lifts[j],c)
                _,sizes,mu = gso(rows)
        if sizes[k] >= (delta-mu[k][k-1]**2)*sizes[k-1]:
            k += 1
        else:
            rows[k-1],rows[k] = rows[k],rows[k-1]
            lifts[k-1],lifts[k] = lifts[k],lifts[k-1]
            _,sizes,mu = gso(rows)
            k = max(1,k-1)
    return rows,lifts


def shortest_coeff(rows):
    """Exact fixed-rank shortest vector search with a Gram–Schmidt bound."""
    _,sizes,mu = gso(rows)
    count = len(rows)
    best, bound = [1]+[0]*(count-1),sizes[0]
    c = [0]*count

    def visit(i,spent):
        nonlocal best,bound
        if spent>bound:
            return
        if i<0:
            if any(c) and spent<bound:
                best,bound = c[:],spent
            return
        radius_sq = (bound-spent)/sizes[i]
        center = -sum(mu[j][i]*c[j] for j in range(i+1,count))
        center = F(center)
        spread = isqrt((radius_sq*center.denominator**2).__floor__())
        low = -(-(center.numerator-spread)//center.denominator)
        high = (center.numerator+spread)//center.denominator
        for value in range(low,high+1):
            c[i] = value
            visit(i-1,spent+sizes[i]*(value-center)**2)

    visit(count-1,F(0))
    return best


def hkz(rows,lifts):
    rows,lifts = lll(rows,lifts)
    if len(rows)<2:
        return rows,lifts
    c = shortest_coeff(rows)
    g,w = bezout(c)
    assert g == 1
    change = [c]+kernel([w],len(c))
    rows = [combo(v,rows) for v in change]
    lifts = [combo(v,lifts) for v in change]
    rest, rest_change = hkz([project(r,[rows[0]]) for r in rows[1:]],identity(len(rows)-1))
    assert len(rest) == len(rows)-1
    aligned_rows,aligned_lifts = [rows[0]],[lifts[0]]
    for v in rest_change:
        original = combo(v,rows[1:])
        lift = combo(v,lifts[1:])
        n = round(F(dot(original,rows[0]),dot(rows[0],rows[0])))
        aligned_rows.append(sub(original,rows[0],n))
        aligned_lifts.append(sub(lift,lifts[0],n))
    return aligned_rows,aligned_lifts


def coordinates(rows,v):
    return [dot(v,b) for b in dual(rows)]


def dual(rows):
    n=len(rows)
    augmented = [[F(dot(a,b)) for b in rows]+e for a,e in zip(rows,identity(n))]
    for i in range(n):
        j=next(j for j in range(i,n) if augmented[j][i])
        augmented[i],augmented[j] = augmented[j],augmented[i]
        augmented[i] = [x/augmented[i][i] for x in augmented[i]]
        for j in range(n):
            if j!=i:
                augmented[j]=sub(augmented[j],augmented[i],augmented[j][i])
    return [combo(row[n:],rows) for row in augmented]


def nearest(rows,target):
    orth,sizes,_ = gso(rows)
    residual = list(target)
    for b,g,d in reversed(list(zip(rows,orth,sizes))):
        residual = sub(residual,b,round(F(dot(residual,g),d)))
    return sub(target,residual)


def lift_projection(point,U,bez):
    """A projection lift fixed by the integral linear form bez · U = 1."""
    lift = sub(point,U,dot(bez,point))
    assert all(F(x).denominator == 1 for x in lift)
    return [int(x) for x in lift]
