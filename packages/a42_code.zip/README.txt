A42 Z=10 tail (|U|^2>=21609), wedge^2<=289, shapes A=(3,1,0,0,0), B=(2,2,1,1,0). Hesper, WEB OFF.
Replay: python3 bound.py 10; bash run.sh A 3,1,0,0,0 289; bash run.sh B 2,2,1,1,0 289; python3 neon_rules.py planes_A.tsv; python3 neon_rules.py planes_B.tsv
Expect A: planes 32688 closed 25968 resid planes 6720 resid inputs 1755912 max|U|^2 547969 ALL PASS
Expect B: planes 31412 closed 29252 resid planes 2160 resid inputs 380240 max|U|^2 453886 ALL PASS
Closed planes use Lean lemmaT_T6 (commit d2128613), rounding floor(s+1/2); cert does no rounding. Residual times explicit rationals.
