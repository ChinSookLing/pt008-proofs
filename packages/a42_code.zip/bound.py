from fractions import Fraction as F
import sys
Z=int(sys.argv[1]); S=F(4*Z,9) if Z%2==0 else F(4*Z-9,9)
from itertools import combinations
# vars b1,b2,b3; constraints a.x >= c
H=[((1,0,0),F(1,2)),((-1,2,0),0),((0,-1,2),0),((0,0,-1),-2),((1,1,1),S),((0,0,1),0),((0,1,0),0)]
def solve(A,c):
    import copy
    M=[list(map(F,a))+[F(ci)] for a,ci in zip(A,c)]
    for i in range(3):
        p=next((r for r in range(i,3) if M[r][i]!=0),None)
        if p is None: return None
        M[i],M[p]=M[p],M[i]
        for r in range(3):
            if r!=i and M[r][i]!=0:
                f=M[r][i]/M[i][i]; M[r]=[x-f*y for x,y in zip(M[r],M[i])]
    return [M[i][3]/M[i][i] for i in range(3)]
V=[]
for tri in combinations(H,3):
    x=solve([t[0] for t in tri],[t[1] for t in tri])
    if x and all(sum(a*b for a,b in zip(h[0],x))>=h[1] for h in H): V.append(tuple(x))
V=set(V)
best=min(V,key=lambda v:v[0]*v[1]*v[2])
print(sorted(V)); print('min',best,best[0]*best[1]*best[2], F(Z**4,21609), best[0]*best[1]*best[2]>F(Z**4,21609))
s=S-F(1,2); print('b2b3 min', min(2*s*s/9, 2*(s-2)), F(Z**3)/min(2*s*s/9, 2*(s-2)))
