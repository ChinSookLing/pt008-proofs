set -e
tag=$1; z=$2; det=${3:-521}; tail=${4:-21609}
python3 gen.py $z $det $tail planes_$tag.tsv > gen_$tag.log
python3 resid.py planes_$tag.tsv $tail > resid_$tag.txt
node times.js resid_$tag.txt rt_$tag.txt 2>> gen_$tag.log
python3 verify.py $z $det $tail planes_$tag.tsv rt_$tag.txt > ver_$tag.log 2>&1
