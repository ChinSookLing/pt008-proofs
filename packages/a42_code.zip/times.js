// streaming: for each residual line "p q a b u1..u5" append i k with t=(6k+1)/(6|u_i|) safe
const fs=require('fs');const readline=require('readline');
const out=fs.createWriteStream(process.argv[3]);let n=0,bad=0;
const rl=readline.createInterface({input:fs.createReadStream(process.argv[2])});
rl.on('line',l=>{if(!l)return;n++;const w=l.split(' ');const u=w.slice(4).map(x=>Math.abs(+x));let res=null;
 for(let i=0;i<5&&!res;i++){const ui=u[i];if(!ui)continue;const m=6*ui;
  for(let k=0;k<ui&&!res;k++){const s=(6*k+1)%m;let ok=true;
   for(let j=0;j<5;j++){const r=(s*(u[j]%m))%m;if(Math.min(r,m-r)<ui){ok=false;break;}} if(ok)res=[i,k];}}
 if(!res){bad++;out.write(l+' NOSAFE\n');} else out.write(l+' '+res[0]+' '+res[1]+'\n');});
rl.on('close',()=>{out.end();console.error('lines',n,'nosafe',bad);});
