# exact residual: closed==0 planes, coprime (a,b) up to sign, 4*rr*(a^2+b^2)<1, |U|^2>=21609
import math,sys
TAIL=int(sys.argv[2])
from fractions import Fraction as F
from math import gcd
for l in open(sys.argv[1]):
    f=l.rstrip('\n').split('\t')
    if f[-1]!='0': continue
    p=list(map(int,f[0].split(','))); q=list(map(int,f[1].split(','))); rr=F(f[6])
    B=1/(4*rr); R=math.isqrt(math.floor(B))+1
    for a in range(-R,R+1):
        for b in range(0,R+1):
            if (b==0 and a<=0) or gcd(a,b)!=1 or 4*rr*(a*a+b*b)>=1: continue
            U=[a*x+b*y for x,y in zip(p,q)]
            if sum(x*x for x in U)<TAIL: continue
            print(f[0],f[1],a,b,*U)
