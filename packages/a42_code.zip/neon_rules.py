# A40 overlay (Hesper): Neon R2/R3/R4 explicit points on the A40 plane list, exact rationals.
import sys
from fractions import Fraction as F
H=F(1,2);T=F(1,3);Q=F(1,4)
RULES=[('R2',[(H,0),(0,H),(H,H)]),('R3',[(T,0),(0,T),(T,T),(T,2*T)]),
       ('R4',[(Q,0),(0,Q),(Q,Q),(Q,3*Q),(Q,H),(H,Q)])]
def rr(rows,x,y):
    r=None
    for p,q in rows:
        f=(p*x+q*y)%1; d=min(f,1-f)-F(1,6)
        if d<=0: return None
        v=d*d/(p*p+q*q); r=v if r is None else min(r,v)
    return r
cnt={'R2':0,'R3':0,'R4':0,'none':0}; nopos=0; early=0; cross={}
for l in open(sys.argv[1]):
    f=l.split('\t'); p=list(map(int,f[0].split(','))); q=list(map(int,f[1].split(','))); tr=int(f[3])
    closed=int(f[7]); rows=list(zip(p,q)); first=None; anypos=False; firstpos_full=None
    for name,pts in RULES:
        for x,y in pts:
            r=rr(rows,x,y)
            if r is None: continue
            if not anypos: anypos=True; firstpos_full=(4*21609*r>=tr)
            if first is None and 4*21609*r>=tr: first=name
    k=first or 'none'; cnt[k]+=1
    if not anypos: nopos+=1
    if first and firstpos_full is False: early+=1
    cross[(k,closed)]=cross.get((k,closed),0)+1
print(cnt,'no-positive',nopos,'missed-if-stop-at-first-positive',early)
print('cross (rule, Hesper closed):',sorted(cross.items()))
