# A37 certificate generator (Hesper). Z=15 tail, z1=(3,2,1,1,0).
# Output planes.tsv: p q det2 tr x0 y0 rr(=rho^2 exact, Fraction) closed
import numpy as np, math
from fractions import Fraction as F
from math import gcd
import sys
Z1=tuple(map(int,sys.argv[1].split(','))); DET=int(sys.argv[2]); TAIL=int(sys.argv[3]); OUT=sys.argv[4]
R=4*DET//3; r=int(math.isqrt(R)); a=np.arange(-r,r+1)
J=min((i for i in range(5) if Z1[i]),key=lambda i:(abs(Z1[i]),i))  # dependent coord: smallest |coef|
fr=[i for i in range(5) if i!=J]
W=[x.ravel() for x in np.meshgrid(a,a,a,a,indexing='ij')]
S=sum(Z1[i]*W[t] for t,i in enumerate(fr)); keep=(S%Z1[J]==0)
V=np.zeros((int(keep.sum()),5),dtype=np.int64)
for t,i in enumerate(fr): V[:,i]=W[t][keep]
V[:,J]=-S[keep]//Z1[J]; n=(V*V).sum(1)
k=(n>0)&(n<=R); V=V[k]; n=n[k]
assert not (V@np.array(Z1)).any()
fnz=V[np.arange(len(V)),(V!=0).argmax(1)]; V=V[fnz>0]; n=n[fnz>0]
P=V[n*n<=R]
def grid(N):
    g=np.arange(N)/N; X,Y=np.meshgrid(g,g,indexing='ij'); return X.ravel(),Y.ravel()
G={60:grid(60),240:grid(240)}
def best(rows,N):
    X,Y=G[N]; s=None
    for (pi,qi) in rows:
        f=(pi*X+qi*Y)%1.0; d=(np.minimum(f,1-f)-1/6)/math.hypot(pi,qi)
        s=d if s is None else np.minimum(s,d)
    i=int(s.argmax()); return F(i//N,N),F(i%N,N)
def exact_rr(rows,x0,y0):
    rr=None
    for (pi,qi) in rows:
        f=(pi*x0+qi*y0)%1; dd=min(f,1-f)-F(1,6)
        if dd<=0: return None
        v=dd*dd/(pi*pi+qi*qi); rr=v if rr is None else min(rr,v)
    return rr
seen=set(); out=open(OUT,'w'); st=dict(pairs=0,unsat=0,degen=0,planes=0,closed=0,neg=0)
for p in P:
    pp=int(p@p); m=(n>=pp)&(n<=R//pp); Q=V[m]; nq=n[m]; d=Q@p
    ok=(2*np.abs(d)<=pp)&(pp*nq-d*d<=DET)
    for q in Q[ok]:
        st['pairs']+=1; q=[int(x) for x in q]; pl=[int(x) for x in p]
        mins=tuple(pl[i]*q[j]-pl[j]*q[i] for i in range(5) for j in range(i+1,5))
        g=0
        for x in mins: g=gcd(g,x)
        if g!=1: st['unsat']+=1; continue
        if mins in seen or tuple(-x for x in mins) in seen: continue
        seen.add(mins); rows=list(zip(pl,q))
        if any(r==(0,0) for r in rows) or any(rows[i]==rows[j] or rows[i]==(-rows[j][0],-rows[j][1]) for i in range(5) for j in range(i+1,5)):
            st['degen']+=1; continue
        st['planes']+=1
        det=sum(x*x for x in mins); tr=pp+sum(x*x for x in q)
        best_rr=None; bx=None
        for N in (60,240):
            x0,y0=best(rows,N); rr=exact_rr(rows,x0,y0)
            if rr is not None and (best_rr is None or rr>best_rr): best_rr,bx=rr,(x0,y0)
            if best_rr is not None and 4*TAIL*best_rr>=tr: break
        if best_rr is None: st['neg']+=1; out.write(f"{','.join(map(str,pl))}\t{','.join(map(str,q))}\t{det}\t{tr}\tNEG\n"); continue
        closed=int(4*TAIL*best_rr>=tr); st['closed']+=closed
        out.write(f"{','.join(map(str,pl))}\t{','.join(map(str,q))}\t{det}\t{tr}\t{bx[0]}\t{bx[1]}\t{best_rr}\t{closed}\n")
print(Z1,DET,TAIL,st)
