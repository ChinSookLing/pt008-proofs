# A45 r2 runner: apply the uncut polar-polygon certificate (polar46.certify) to every plane of a list.
# Input: text/TSV, one plane per line; the tokens that are pure integers (separators: blanks , ; | [ ] ( )) are read in order, the first SKIP are ignored (e.g. an id),
#        the next 10 are p1..p5 q1..q5.  Lines with fewer integers (headers, comments) are skipped and counted.
# Output: <out>.tsv (one line per plane: line no, p, q, Gram, status, cells, Qmax, residual, misses) and a summary with the input sha256.
# Usage: python3 run46.py planes.tsv OUTPREFIX [SKIP] [WORKERS]
import sys, re, hashlib, json, time
from multiprocessing import Pool
from polar46 import certify
src, outp = sys.argv[1], sys.argv[2]; SKIP = int(sys.argv[3]) if len(sys.argv) > 3 else 0; WK = int(sys.argv[4]) if len(sys.argv) > 4 else 2
raw = open(src, "rb").read(); sha = hashlib.sha256(raw).hexdigest()
jobs = []; skipped = 0
for no, line in enumerate(raw.decode().splitlines(), 1):
    ints = [int(x) for x in re.split(r"[\s,;|\[\]()]+", line) if re.fullmatch(r"-?\d+", x)]
    if line.lstrip().startswith("#") or len(ints) < SKIP + 10: skipped += 1; continue
    v = ints[SKIP:SKIP + 10]; jobs.append((no, v[:5], v[5:]))
def work(j):
    no, p, q = j; c = certify(p, q)
    return (no, p, q, c.get("G"), c["status"], c.get("cells"), str(c.get("Qmax")), c.get("residual", 0), c.get("misses", []), c.get("residual_list", []))
if __name__ == "__main__":
    t0 = time.time()
    with Pool(WK) as pool: res = pool.map(work, jobs, chunksize=64)
    stat = {}; resid = 0; misses = []
    with open(outp + ".tsv", "w") as f:
        f.write("line\tp\tq\tGram\tstatus\tcells\tQmax\tresidual\tmisses\n")
        for no, p, q, G, st, cells, qm, r, ms, rl in res:
            stat[st] = stat.get(st, 0) + 1; resid += r; misses += [(no, m) for m in ms]
            f.write("%d\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\n" % (no, p, q, G, st, cells, qm, r, json.dumps(ms)))
    summ = {"input": src, "input_sha256": sha, "planes": len(jobs), "skipped_lines": skipped, "status": stat,
            "residual_points": resid, "misses": len(misses), "miss_witnesses": misses[:20], "seconds": round(time.time() - t0)}
    json.dump(summ, open(outp + ".summary.json", "w"), indent=1); print(json.dumps(summ))
