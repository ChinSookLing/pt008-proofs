# A45 r2 (independent check, not using the vertex argument): for sampled open planes, regenerate Hesper's residual points
# (primitive (a,b) up to sign, 4 rho^2 (a^2+b^2) < 1, |ap+bq|^2 >= 21609), compare the count with resid_count, and for EVERY point
# verify (i) some uncut safe cell has h-range >= 1 (width test) and (ii) the exact rule hits and the returned t is safe (Fraction).
import sys, random, time
from fractions import Fraction as F
from math import gcd, isqrt
from polar46 import uncut_cell, dot
from poly45 import polygons, rule, is_safe
rows = [l.rstrip("\n").split("\t") for l in open("../in/open728.tsv")]
if sys.argv[1] == "all":                     # full run, shard k of K
    k, K = int(sys.argv[2]), int(sys.argv[3]); pick = [i for i in range(len(rows)) if i % K == k]; NTOP = NRAND = 0
else:
    rng = random.Random(int(sys.argv[1])); NTOP, NRAND = int(sys.argv[2]), int(sys.argv[3])
    order = sorted(range(len(rows)), key=lambda i: -int(rows[i][7]))
    pick = order[:NTOP] + rng.sample(order[NTOP:], NRAND)
t0 = time.time(); pts = 0; cnt_bad = 0; width_fail = 0; rule_fail = 0
for i in pick:
    r = rows[i]; p = [int(x) for x in r[0].split(",")]; q = [int(x) for x in r[1].split(",")]; rr = F(r[6]); rc = int(r[7])
    pp, pq, qq = dot(p, p), dot(p, q), dot(q, q)
    polys = polygons(p, q); cells = [C for C in (uncut_cell(p, q, k) for k in sorted({k for k, P in polys})) if C]
    R = isqrt(int(1 / (4 * rr))) + 1; mine = 0
    for a in range(0, R + 1):
        for b in range(-R, R + 1):
            if (a == 0 and b <= 0) or gcd(a, b) != 1: continue
            if not 4 * rr * (a * a + b * b) < 1: continue
            if a * a * pp + 2 * a * b * pq + b * b * qq < 21609: continue
            mine += 1; pts += 1
            if not any(max(b * x - a * y for x, y in C) - min(b * x - a * y for x, y in C) >= 1 for C in cells): width_fail += 1
            res = rule(p, q, a, b, polys); U = [a * x + b * y for x, y in zip(p, q)]
            if res is None or not is_safe(U, res[0]): rule_fail += 1
    cnt_bad += mine != rc
print("planes checked %d (top %d by resid_count + %d random) ; residual points regenerated %d ; count != resid_count: %d planes ; "
      "points without an uncut cell of h-range >= 1: %d ; points where the exact rule fails: %d ; %.0f s"
      % (len(pick), NTOP, NRAND, pts, cnt_bad, width_fail, rule_fail, time.time() - t0))
