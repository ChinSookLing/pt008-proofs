# A45 r2 (TEST, adversarial sampling): planes with a SHORT p and a LONG q (thin bands), Gram <= 4630, inside (2,1,1,1,0)^perp,
# to look for planes whose K_W vertices exceed the tail threshold 21609.
import sys, random, time
from fractions import Fraction as F
from math import gcd, isqrt
from polar46 import certify, dot, minors_gcd
from sr28 import kernel_rows
z1 = [2, 1, 1, 1, 0]; K4 = kernel_rows([z1])
rng = random.Random(int(sys.argv[2])); NP = int(sys.argv[1]); t0 = time.time()
short = []
for c in __import__("itertools").product(range(-3, 4), repeat=4):
    v = [sum(c[j] * K4[j][i] for j in range(4)) for i in range(5)]
    if any(v) and dot(v, v) <= 12: short.append(v)
stat = {}; top = []; planes = 0; resid_tot = 0; misses = []
while planes < NP:
    p = rng.choice(short)
    R = rng.choice([6, 10, 16, 24, 32])
    c2 = [rng.randint(-R, R) for _ in range(4)]; q = [sum(c2[j] * K4[j][i] for j in range(4)) for i in range(5)]
    G = dot(p, p) * dot(q, q) - dot(p, q) ** 2
    if G == 0 or G > 4630 or minors_gcd(p, q) != 1: continue
    # Gauss-reduce q against p (same plane)
    k = round(F(dot(p, q), dot(p, p))); q = [b - k * a for a, b in zip(p, q)]
    planes += 1; c = certify(p, q); stat[c["status"]] = stat.get(c["status"], 0) + 1
    if "Qmax" in c: top.append((c["Qmax"], p, q)); top.sort(key=lambda r: r[0], reverse=True); top = top[:5]
    if c["status"] == "RESIDUAL": resid_tot += c["residual"]; misses += c["misses"]
print("adversarial planes %d ; statuses %s ; residual lattice points %d ; misses %d %s ; top vertex Q: %s ; %.0f s"
      % (planes, stat, resid_tot, len(misses), misses[:3], [(round(float(x[0]), 1), x[1], x[2]) for x in top], time.time() - t0))
