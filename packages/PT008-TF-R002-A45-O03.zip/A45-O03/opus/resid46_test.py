# A45 r2 (TEST of the residual branch): lower the tail threshold so that K_W vertices exceed it, then compare with brute force:
# every primitive (a,b) with Q >= T in a box is either (i) outside open K_W and has an uncut cell with h-range >= 1, or (ii) in the residual list;
# the exact rule must hit every residual point with all u_i != 0 (else it is reported as a miss).
import random
from fractions import Fraction as F
from math import gcd
import polar46
from polar46 import certify, uncut_cell, dot
from poly45 import polygons
from sr28 import kernel_rows
z1 = [2, 1, 1, 1, 0]; K4 = kernel_rows([z1]); rng = random.Random(46)
bad = 0; n_out = 0; n_in = 0; planes = 0; misses = 0
for T in (200, 600, 1500):
    polar46.TAIL = T; done = 0
    while done < 25:
        c1 = [rng.randint(-4, 4) for _ in range(4)]; c2 = [rng.randint(-4, 4) for _ in range(4)]
        p = [sum(c1[j] * K4[j][i] for j in range(4)) for i in range(5)]; q = [sum(c2[j] * K4[j][i] for j in range(4)) for i in range(5)]
        if dot(p, p) * dot(q, q) - dot(p, q) ** 2 == 0 or polar46.minors_gcd(p, q) != 1: continue
        c = certify(p, q)
        if c["status"] not in ("RESIDUAL", "CLOSED_BY_VERTICES"): continue
        done += 1; planes += 1; misses += len(c.get("misses", []))
        resid = set(c.get("residual_list", []))
        cells = [uncut_cell(p, q, k) for k in sorted({k for k, P in polygons(p, q)})]
        pp, pq, qq = dot(p, p), dot(p, q), dot(q, q)
        for a in range(0, 31):
            for b in range(-30, 31):
                if (a == 0 and b <= 0) or gcd(a, b) != 1 or a * a * pp + 2 * a * b * pq + b * b * qq < T: continue
                U = [a * x + b * y for x, y in zip(p, q)]
                if any(u == 0 for u in U): continue
                wide = any(max(b * x - a * y for x, y in C) - min(b * x - a * y for x, y in C) >= 1 for C in cells if C)
                if (a, b) in resid: n_in += 1
                else:
                    n_out += 1
                    if not wide: bad += 1
polar46.TAIL = 21609
print("planes %d (thresholds 200, 600, 1500) ; points outside open K_W %d, of which without an uncut cell of h-range >= 1: %d ; residual points %d ; rule misses on residual points %d" % (planes, n_out, bad, n_in, misses))
