# A45 r2 (TEST): validate polar46 — (i) the uncut K_W is inside the cut K_W of cert45 on the same plane, (ii) brute force on sample planes:
# every primitive (a,b) with |U|^2 >= 21609 in a big box is either outside open K_W (then some uncut cell has width >= 1 and the rule hits)
# or listed in the residual; (iii) closure statuses on sampled planes.
import sys, random, time
from fractions import Fraction as F
from math import gcd
from polar46 import certify, uncut_cell, dot
from poly45 import polygons, rule, is_safe
from sr28 import kernel_rows
z1 = [2, 1, 1, 1, 0]; K4 = kernel_rows([z1])
def reduce2(p, q):
    while True:
        if dot(p, p) > dot(q, q): p, q = q, p
        k = round(F(dot(p, q), dot(p, p)))
        if k == 0: return p, q
        q = [b - k * a for a, b in zip(p, q)]
rng = random.Random(int(sys.argv[2])); NP = int(sys.argv[1]); BRUTE = int(sys.argv[3]) if len(sys.argv) > 3 else 0
t0 = time.time(); stat = {}; planes = 0; Qmaxes = []; brute_bad = 0; brute_n = 0
while planes < NP:
    R = rng.choice([2, 3, 4, 6, 8, 12])
    c1 = [rng.randint(-R, R) for _ in range(4)]; c2 = [rng.randint(-R, R) for _ in range(4)]
    v1 = [sum(c1[j] * K4[j][c] for j in range(4)) for c in range(5)]; v2 = [sum(c2[j] * K4[j][c] for j in range(4)) for c in range(5)]
    if dot(v1, v1) * dot(v2, v2) - dot(v1, v2) ** 2 == 0: continue
    p, q = kernel_rows(kernel_rows([v1, v2])); p, q = reduce2(list(p), list(q))
    if dot(p, p) * dot(q, q) - dot(p, q) ** 2 > 4630: continue
    planes += 1; c = certify(p, q); stat[c["status"]] = stat.get(c["status"], 0) + 1
    if "Qmax" in c: Qmaxes.append((c["Qmax"], p, q))
    if BRUTE and planes <= BRUTE and c["status"] in ("CLOSED_BY_VERTICES", "RESIDUAL"):
        # brute: all primitive (a,b) with |a|,|b| <= 40, |U|^2 >= 21609, u_i != 0: rule must hit; those inside open K_W must be in the residual
        resid = set(c.get("residual_list", []))
        pp, pq, qq = dot(p, p), dot(p, q), dot(q, q)
        for a in range(0, 41):
            for b in range(-40, 41):
                if (a == 0 and b <= 0) or gcd(a, b) != 1: continue
                if a * a * pp + 2 * a * b * pq + b * b * qq < 21609: continue
                U = [a * x + b * y for x, y in zip(p, q)]
                if any(u == 0 for u in U): continue
                brute_n += 1; r = rule(p, q, a, b)
                if r is None or not is_safe(U, r[0]): brute_bad += 1
Qmaxes.sort(key=lambda r: r[0], reverse=True)
print("planes %d ; statuses %s ; largest vertex Q over K_W: %s ; brute check (first %d planes, |a|,|b| <= 40): %d inputs, failures %d ; %.0f s"
      % (planes, stat, [(str(round(float(x[0]), 1)), x[1], x[2]) for x in Qmaxes[:3]], BRUTE, brute_n, brute_bad, time.time() - t0))
