# A45 probe: trace vs spectral closure criterion on Hesper plane table (exact rationals). Hesper.
import sys
from fractions import Fraction as F
TAIL=21609
tot=tr_c=sp_c=0; byD={}
for l in open(sys.argv[1]):
    f=l.rstrip('\n').split('\t'); p=list(map(int,f[0].split(','))); q=list(map(int,f[1].split(',')))
    D=int(f[2]); rr=F(f[6]); c=4*TAIL*rr
    pp=sum(x*x for x in p); qq=sum(x*x for x in q); pq=sum(x*y for x,y in zip(p,q))
    t=int(c>=pp+qq); s=int(c>=pp and c>=qq and (c-pp)*(c-qq)>=pq*pq)
    assert t<=s; assert t==int(f[7])
    tot+=1; tr_c+=t; sp_c+=s
    for cut in (182,364,546,728):
        if D<=cut:
            b=byD.setdefault(cut,[0,0,0]); b[0]+=1; b[1]+=t; b[2]+=s
for cut,(n,t,s) in sorted(byD.items()): print(cut,'planes',n,'trace closed',t,'spectral closed',s,'gain',s-t,'open',n-s)
