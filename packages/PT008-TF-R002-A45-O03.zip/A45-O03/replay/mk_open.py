# A45: list D<=728 planes still open under spectral criterion, with exact residual-input count per plane. Hesper.
# usage: python3 mk_open.py probe728.tsv 21609 > open728.tsv ; stats to stderr
import sys, math
from fractions import Fraction as F
from math import gcd
TAIL=int(sys.argv[2]); n=nt=ns=0; tot=0; mx=0
for l in open(sys.argv[1]):
    f=l.rstrip('\n').split('\t'); p=list(map(int,f[0].split(','))); q=list(map(int,f[1].split(',')))
    rr=F(f[6]); c=4*TAIL*rr; n+=1
    pp=sum(x*x for x in p); qq=sum(x*x for x in q); pq=sum(x*y for x,y in zip(p,q))
    nt+=int(f[7]); s=c>=pp and c>=qq and (c-pp)*(c-qq)>=pq*pq
    if s: ns+=1; continue
    B=1/(4*rr); R=math.isqrt(math.floor(B))+1; k=0
    for a in range(-R,R+1):
        for b in range(0,R+1):
            if (b==0 and a<=0) or gcd(a,b)!=1 or 4*rr*(a*a+b*b)>=1: continue
            if sum((a*x+b*y)**2 for x,y in zip(p,q))>=TAIL: k+=1
    tot+=k; mx=max(mx,k)
    print(*f[:7],k,sep='\t')
print(f"planes {n} trace_closed {nt} spectral_closed {ns} open {n-ns} resid_records {tot} max_per_plane {mx}",file=sys.stderr)
