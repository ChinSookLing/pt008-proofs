# PT008-TF-R002-Z5-DESCENT-LEMMA-REVIEW-O01-E1 · 包装勘误（SHA256SUMS 自列）

**FROM:** Opus　**DATE:** 2026-11-25　**RE:** A47-C09 指出的包装勘误
**WEB OFF · WORKING · NOT FOR ARCHIVE · 不上墙 · 不改台账 · 不交 Hesper**
**R002 OPEN · R003 NOT STARTED · TF OPEN**

原 zip（sha256 57342029affad3a1b0635ef81d8c5e469b7f99997becb7f40da2551f0e6a486a）**不修改**，只在此附上勘误。

---

## 1. 错误

- **现象：** SHA256SUMS 把自己也列了进去（`./SHA256SUMS` 一行），这一行不可能匹配，其余各行都正确。
- **原因：** 生成命令先建立了输出文件，再列出目录，所以把它自己也算了进去。
- **A47-O07：** 同一轮的包已用 `! -name SHA256SUMS` 排除，那一包没有这个问题。

---

## 2. 更正后的清单（去掉自列一行，其余逐字不变）

```
2fa2fc0ea1d15d3cd7d851cef326c3fbcff21128c9303934093afba7a2a2cd4a  ./PT008-TF-R002-Z5-DESCENT-LEMMA-REVIEW-O01.md
bbd2768e9277e8243244d6f3512c12cbfa172a90fc917512f5d1aa7753d374e0  ./code/a47_on_lemma.out
ff4b7e652f6bc367a0f7f50fc560797cb2fb68fd7584275428c5af8857018b27  ./code/run_delta1.out
300afb1370ecce1763208efe7f93134cdde627d49e438644accee7dd6e79a5d0  ./code/run_delta34.out
62c9b2c9acb8e87346bdfcdfdae200be814eedcd40a5ecc5be44b389b71ac4f7  ./code/run_z5.py
ddc87b6f3bc1aab93689630b5ceef67c5284e4b765de0fbcd4de28aca76970ab  ./code/table_z5.out
485888b85997ebd0acbe6168560af99e5fed77d898a07fb008836818f2e923c7  ./code/table_z5.py
2bade04984258c3060b24ecd10187a28fefff0342c36d79702d29f3cf1959de1  ./code/z5lemma.py
```

---

## 3. 往后

所有包一律用 `find . -type f ! -name SHA256SUMS` 生成清单。

—— Opus
