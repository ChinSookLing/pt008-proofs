# per-W: (1) the chair's centre test vs saturation (unsaturated pairs); (2) best margin over denominators q <= 12;
# (3) third-relation bound  |z3|^2 < 7/(12 m^2) + N_W  with three choices of the normal term N_W:
#     chair: (5 + 37)/4 ;  Babai with saturation basis (z1, s2): (5 + area(S)^2/5)/4 ;  exact covering radius^2 of S.
import json, itertools
from fractions import Fraction as F
from math import gcd, floor
from wtable import SHAPES, naive_centres
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def margin_best(Sb, qmax=12):
    best = (F(0), None)
    for q in range(3, qmax + 1):
        good = [r for r in range(1, q) if 6 * min(r, q - r) > q]
        m_q = min(F(min(r, q - r), q) for r in good) - F(1, 6) if good else 0
        # only worth trying if the best possible margin at q could beat current
        gm = max(F(min(r, q - r), q) for r in good) - F(1, 6)
        if gm <= best[0]: continue
        # search centres maximising the minimum distance
        for r in itertools.product(good, repeat=5):
            if all(dot(s, r) % q == 0 for s in Sb):
                m = min(F(min(x, q - x), q) for x in r) - F(1, 6)
                if m > best[0]: best = (m, (q, r))
    return best
def lagrange(b1, b2):
    while True:
        if dot(b2, b2) < dot(b1, b1): b1, b2 = b2, b1
        mu = F(dot(b1, b2), dot(b1, b1)); k = round(mu)
        if k == 0: return b1, b2
        b2 = [x - k * y for x, y in zip(b2, b1)]
def covering_radius2(b1, b2):
    """exact squared covering radius of the 2D lattice: circumradius^2 of the non-obtuse Delaunay triangle"""
    b1, b2 = lagrange(b1, b2)
    if dot(b1, b2) < 0: b2 = [-x for x in b2]
    # triangle 0, b1, b2 with reduced basis and <b1,b2> >= 0 is non-obtuse
    a2 = dot(b1, b1); c2 = dot(b2, b2); d = [x - y for x, y in zip(b2, b1)]; e2 = dot(d, d)
    G = a2 * c2 - dot(b1, b2) ** 2                      # (2*area)^2
    return F(a2 * c2 * e2, 4 * G)                       # R^2 = (abc)^2 / (16 Area^2) = a^2 b^2 c^2 / (4 * (2A)^2)
out = {}
for name, z1 in SHAPES.items():
    rows = json.load(open("wtable_%s.json" % name))
    st = {"kept": len(rows), "unsat": 0, "unsat_naive_first_centre_invalid": 0, "margin_hist": {}, "max_z3_chair": 0,
          "max_z3_babaiS": 0, "max_z3_cover": 0}
    per = []
    for r in rows:
        Sb = r["S_basis"]; z2 = r["z2"]
        if r["pair_index"] != 1:
            st["unsat"] += 1
            for q in (3, 4, 5):
                nv = naive_centres(z1, z2, q)
                if nv:
                    if not all(dot(s, nv[0]) % q == 0 for s in Sb): st["unsat_naive_first_centre_invalid"] += 1
                    break
        m, cen = margin_best(Sb)
        st["margin_hist"][str(m)] = st["margin_hist"].get(str(m), 0) + 1
        T = F(7, 12) / (m * m)
        # basis (z1, s2) of S: s2 any vector completing z1
        s1, s2 = Sb
        G = dot(s1, s1) * dot(s2, s2) - dot(s1, s2) ** 2      # area(S)^2
        nB = (5 + F(G, 5)) / 4; nC = covering_radius2(s1, s2)
        b_chair = T + F(42, 4); b_S = T + nB; b_C = T + nC
        z3_chair = (b_chair - 1) // 1 + (1 if b_chair != int(b_chair) else 0)  # largest integer < bound
        def lt(b): return int(b) if b != int(b) else int(b) - 1
        rec = {"z2": z2, "m": str(m), "centre": cen, "T": str(T), "z3max_chair": lt(b_chair), "z3max_S": lt(b_S), "z3max_cover": lt(b_C), "areaS2": G}
        per.append(rec)
        st["max_z3_chair"] = max(st["max_z3_chair"], rec["z3max_chair"]); st["max_z3_babaiS"] = max(st["max_z3_babaiS"], rec["z3max_S"])
        st["max_z3_cover"] = max(st["max_z3_cover"], rec["z3max_cover"])
    # per-batch maxima
    for key in ("z3max_chair", "z3max_S", "z3max_cover"):
        bm = {}
        for rec in per: bm[rec["m"]] = max(bm.get(rec["m"], 0), rec[key])
        st["by_margin_" + key] = bm
    out[name] = st; print(name, json.dumps(st), flush=True)
    json.dump(per, open("wbounds_%s.json" % name, "w"))
