# A47-T10 pilot (Opus): for sample W (margin 1/6 batch), enumerate third relations z3 with |z3|^2 <= B, dedupe the planes
# P = {z1, z2, z3}^perp, take a saturated basis (p, q) of Z^5 cap P, drop planes with a zero or |equal| coordinate,
# and run the A45 exact polygon certificate (polar46.certify, TAIL = 0 = all primitive (a,b)).
import sys, json, time, itertools, random
from math import gcd
import polar46
from wtable import int_kernel
polar46.TAIL = 0
def canon_plane(Pb):
    p, q = Pb
    m = [p[i] * q[j] - p[j] * q[i] for i in range(5) for j in range(i + 1, 5)]
    g = 0
    for x in m: g = gcd(g, x)
    m = [x // g for x in m]; s = next(x for x in m if x)
    return tuple(x if s > 0 else -x for x in m)
def bad_coords(Pb):
    cols = [tuple(b[i] for b in Pb) for i in range(5)]
    if any(all(x == 0 for x in c) for c in cols): return True
    return any(cols[i] == cols[j] or cols[i] == tuple(-x for x in cols[j]) for i in range(5) for j in range(i + 1, 5))
def planes_of(z1, z2, B):
    R = int(B ** 0.5) + 1; seen = {}
    for z3 in itertools.product(range(-R, R + 1), repeat=5):
        if sum(x * x for x in z3) > B: continue
        Pb = int_kernel([z1, z2, z3])
        if len(Pb) != 2: continue                      # z3 in span(z1, z2)
        key = canon_plane(Pb)
        if key in seen: continue
        seen[key] = (Pb, list(z3))
    return seen
if __name__ == "__main__":
    shape = sys.argv[1]; z1 = (2, -1, 0, 0, 0) if shape == "double" else (1, 1, 1, 1, 1)
    B = int(sys.argv[2]); NW = int(sys.argv[3]); random.seed(int(sys.argv[4])); TL = float(sys.argv[5])
    rows = [r for r in json.load(open("wbounds_%s.json" % shape)) if r["m"] == "1/6"]
    sample = random.sample(rows, NW); stats = {}; t0 = time.time(); allp = {}; misses = []
    for r in sample:
        P = planes_of(z1, r["z2"], B)
        for k, v in P.items(): allp.setdefault(k, v)
    print("W sampled %d ; distinct planes (|z3|^2 <= %d) %d ; %.0f s" % (NW, B, len(allp), time.time() - t0), flush=True)
    done = 0
    for k, (Pb, z3) in allp.items():
        if time.time() - t0 > TL: break
        done += 1
        if bad_coords(Pb): stats["excluded(zero/equal coord)"] = stats.get("excluded(zero/equal coord)", 0) + 1; continue
        o = polar46.certify(Pb[0], Pb[1])
        s = o["status"]
        if s == "RESIDUAL": s = "RESIDUAL(no miss)" if not o["misses"] else "RESIDUAL(MISS)"
        stats[s] = stats.get(s, 0) + 1
        if o.get("misses"): misses.append((Pb, o["misses"][:3]))
    print("planes certified %d / %d in %.0f s : %s ; misses %s" % (done, len(allp), time.time() - t0, stats, misses[:5]))
