# global count of exact admissible planes (best per-W margin, T_W = 7/(12 m_W^2)), deduplicated across all W of a shape
import json, sys, time
from fractions import Fraction as F
from exactplanes import planes_exact
from wtable import int_kernel, SHAPES
name = sys.argv[1]; z1 = SHAPES[name]; t0 = time.time()
allp = set(); perW = []
for i, r in enumerate(json.load(open("wbounds_%s.json" % name))):
    P = planes_exact(int_kernel([z1, r["z2"]]), F(r["T"])); perW.append(len(P)); allp.update(P.keys())
    if i % 1000 == 0: print(i, len(allp), "%.0f s" % (time.time() - t0), flush=True)
print("%s: W %d ; planes per W: min %d, mean %.0f, max %d ; distinct planes %d ; %.0f s" % (name, len(perW), min(perW), sum(perW) / len(perW), max(perW), len(allp), time.time() - t0))
