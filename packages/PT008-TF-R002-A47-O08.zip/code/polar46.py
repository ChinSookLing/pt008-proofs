# A45 round 2 (Opus): polar-polygon closure certificate on UNCUT safe cells (Neon's vertex criterion), exact rational arithmetic.
#   Plane (p, q) saturated in Z^5.  Uncut safe cell C_k = { (x,y) in R^2 : k_i + 1/6 <= p_i x + q_i y <= k_i + 5/6, i = 1..5 }.
#   Width test (Lemma W, valid for uncut cells; safety via PolyT45.poly_time_safe, which never uses the unit square):
#        f_C(a,b) = max_{v,w in C} [ b (v_x - w_x) - a (v_y - w_y) ] >= 1  ⇒  the orbit of (a,b) hits C.
#   K_W = { (a,b) : (a,b)·w < 1 for every w = (-dy, dx), d = v - w a vertex difference of one cell } (open, convex, symmetric).
#   Closure (Neon):  K_W bounded and Q(v) = |v_a p + v_b q|^2 <= 21609 at every vertex v of closed K_W
#        ⇒ no (a,b) in open K_W has |U|^2 >= 21609 (scaling argument)  ⇒ the whole tail of the plane is covered by width.
#   Otherwise: list the primitive lattice points of open K_W with |U|^2 >= 21609 and run the exact (complete) rule on each.
import sys
from fractions import Fraction as F
from math import gcd, floor, ceil
from poly45 import polygons, clip, rule, is_safe, safe_set
SIX = F(1, 6); FIVE6 = F(5, 6); TAIL = 21609
def dot(u, v): return sum(a * b for a, b in zip(u, v))
def minors_gcd(p, q):
    g = 0
    for i in range(5):
        for j in range(i + 1, 5): g = gcd(g, p[i] * q[j] - p[j] * q[i])
    return g
def uncut_cell(p, q, k):
    """exact vertices of C_k (bounded because the plane has rank 2): start from the parallelogram of two independent bands."""
    i, j = next((i, j) for i in range(5) for j in range(i + 1, 5) if p[i] * q[j] - p[j] * q[i] != 0)
    De = p[i] * q[j] - p[j] * q[i]
    P = []
    for li in (k[i] + SIX, k[i] + FIVE6, k[i] + FIVE6, k[i] + SIX):
        pass
    corners = [(k[i] + SIX, k[j] + SIX), (k[i] + FIVE6, k[j] + SIX), (k[i] + FIVE6, k[j] + FIVE6), (k[i] + SIX, k[j] + FIVE6)]
    P = [(F(q[j] * li - q[i] * lj, De), F(-p[j] * li + p[i] * lj, De)) for li, lj in corners]
    if De < 0: P = P[::-1]
    for r in range(5):
        if r in (i, j) or (p[r] == 0 and q[r] == 0): continue
        P = clip(P, F(p[r]), F(q[r]), -(k[r] + SIX))
        if P: P = clip(P, F(-p[r]), F(-q[r]), k[r] + FIVE6)
        if not P: return []
    return P
def hull(points):
    pts = sorted(set(points))
    if len(pts) <= 2: return pts
    def cr(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for pt in pts:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], pt) <= 0: lo.pop()
        lo.append(pt)
    for pt in reversed(pts):
        while len(up) >= 2 and cr(up[-2], up[-1], pt) <= 0: up.pop()
        up.append(pt)
    return lo[:-1] + up[:-1]                                   # counter-clockwise, no collinear points
def certify(p, q, want_rule=True):
    p = list(p); q = list(q); out = {"p": p, "q": q, "G": dot(p, p) * dot(q, q) - dot(p, q) ** 2}
    if minors_gcd(p, q) != 1: out["status"] = "NOT_SATURATED"; return out
    if any(a == 0 and b == 0 for a, b in zip(p, q)): out["status"] = "VOID(zero coordinate)"; return out
    ks = sorted({k for k, P in polygons(p, q)})
    cells = []; shapes = set()
    for k in ks:
        C = uncut_cell(p, q, k)
        if not C: continue
        x0 = min(C); key = tuple((v[0] - x0[0], v[1] - x0[1]) for v in C)
        if key in shapes: continue
        shapes.add(key); cells.append(C)
    out["cells"] = len(cells)
    W = set()
    for C in cells:
        for v in C:
            for w in C:
                if v != w: W.add((-(v[1] - w[1]), v[0] - w[0]))    # (a,b)·W = b dx - a dy
    H = hull(list(W))
    if len(H) < 3: out["status"] = "UNBOUNDED"; return out
    # vertices of closed K_W = polar of conv(W): one per hull edge, solving v·w1 = v·w2 = 1
    V = []
    for t in range(len(H)):
        (x1, y1), (x2, y2) = H[t], H[(t + 1) % len(H)]; det = x1 * y2 - y1 * x2
        V.append(((y2 - y1) / det, (x1 - x2) / det))
    pp, pq, qq = dot(p, p), dot(p, q), dot(q, q)
    Q = lambda a, b: a * a * pp + 2 * a * b * pq + b * b * qq
    qmax = max(Q(a, b) for a, b in V); out["Kw_vertices"] = len(V); out["Qmax"] = qmax
    if qmax <= TAIL: out["status"] = "CLOSED_BY_VERTICES"; return out
    # residual: primitive (a,b) (one of ±) in OPEN K_W with Q >= TAIL
    amax = max(abs(a) for a, b in V); bmax = max(abs(b) for a, b in V)
    res = []; misses = []; zero = 0
    for a in range(0, floor(amax) + 1):
        for b in range(-floor(bmax), floor(bmax) + 1):
            if a == 0 and b <= 0: continue
            if gcd(a, b) != 1 or Q(a, b) < TAIL: continue
            if not all(a * w[0] + b * w[1] < 1 for w in H): continue
            U = [a * x + b * y for x, y in zip(p, q)]
            if any(u == 0 for u in U): zero += 1; continue
            r = rule(p, q, a, b) if want_rule else None
            res.append((a, b))
            if want_rule:
                if r is None: misses.append((a, b, U, bool(safe_set(U))))
                else: assert is_safe(U, r[0])
    out.update({"status": "RESIDUAL", "residual": len(res), "residual_list": res, "zero_coord": zero, "misses": misses})
    return out
