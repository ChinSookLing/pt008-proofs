# explicit check of every best centre: find an integer lambda with c - lambda in W EXACTLY (<z1,.> = <z2,.> = 0),
# then the five distances of c - lambda to Z; margin = min distance - 1/6.
import json
from fractions import Fraction as F
from wtable import SHAPES, int_kernel
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)
def solve_int(rows, rhs):
    """integer x with <rows_k, x> = rhs_k (rows saturated): unimodular column reduction"""
    n = 5; B = [[int(i == j) for j in range(n)] for i in range(n)]; A = [list(r) for r in rows]
    # reduce to lower-triangular form via column operations tracked in B (columns = basis vectors)
    cols = [list(b) for b in B]
    x = [F(0)] * n; rem = list(rhs); used = []
    for k, a in enumerate(rows):
        vals = [dot(a, c) for c in cols]
        idx = [i for i in range(n) if i not in used]
        while sum(1 for i in idx if vals[i]) > 1:
            nz = [i for i in idx if vals[i]]; p = min(nz, key=lambda i: abs(vals[i]))
            for i in nz:
                if i != p:
                    t = vals[i] // vals[p]; vals[i] -= t * vals[p]; cols[i] = [u - t * v for u, v in zip(cols[i], cols[p])]
        p = next(i for i in idx if vals[i]); used.append(p)
        need = rem[k] - dot(a, x)
        assert need.denominator == 1 and need % vals[p] == 0 if vals[p] != 1 and vals[p] != -1 else True
        coef = need / vals[p]; assert coef.denominator == 1
        x = [xi + coef * ci for xi, ci in zip(x, cols[p])]
    return x
tot = bad = 0; mins = {}
for name, z1 in SHAPES.items():
    W = {tuple(r["z2"]): r for r in json.load(open("wtable_%s.json" % name))}
    for rec in json.load(open("wbounds_%s.json" % name)):
        q, r = rec["centre"]; c = [F(x, q) for x in r]; Sb = W[tuple(rec["z2"])]["S_basis"]
        lam = solve_int(Sb, [dot(s, c) for s in Sb])
        assert all(v.denominator == 1 for v in lam)
        cw = [a - b for a, b in zip(c, lam)]
        ok = dot(z1, cw) == 0 and dot(rec["z2"], cw) == 0
        m = min(dist(v) for v in cw) - F(1, 6)
        tot += 1; bad += (not ok) or (str(m) != rec["m"]) or m <= 0
        mins[name] = min(mins.get(name, F(1)), m)
print("centres checked", tot, "failures", bad, "min margin per shape", {k: str(v) for k, v in mins.items()})
