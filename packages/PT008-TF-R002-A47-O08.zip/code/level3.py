# Level-3 descent test (Opus proposal): in a plane P (U in P), take a strict safe centre c_P in P + Z^5 with margin m_P;
# Lambda_P^* = pi_P(Z^5) (rank 2).  1-D Babai: error <= 1/(2|b''|) where b'' generates Gamma_P^* = pi_P(R) (rank 1).
# So |b''|^2 >= 1/(4 m_P^2) => safe time; otherwise U is orthogonal (inside P) to a vector v of Lambda_P^* with
# |v|^2 < 1/(4 m_P^2): U is then the primitive vector of the line P cap v^perp -- finitely many explicit U per plane.
import numpy as np, itertools, json, random, sys, time
from fractions import Fraction as F
from math import gcd
from wtable import int_kernel
from exactplanes import planes_exact
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)
def best_centre(Sb, qmax=12):
    S = np.array(Sb, dtype=np.int64); best = (F(0), None)
    for q in range(3, qmax + 1):
        good = [r for r in range(1, q) if 6 * min(r, q - r) > q]
        if not good or F(max(min(r, q - r) for r in good), q) - F(1, 6) <= best[0]: continue
        R = np.array(list(itertools.product(good, repeat=5)), dtype=np.int64)
        ok = ((R @ S.T) % q == 0).all(axis=1)
        if not ok.any(): continue
        md = np.minimum(R[ok], q - R[ok]).min(axis=1); j = int(md.argmax())
        m = F(int(md[j]), q) - F(1, 6)
        if m > best[0]: best = (m, (q, R[ok][j].tolist()))
    return best
def lines_of_plane(p, q, m):
    """explicit U's: for v in Lambda_P^* with 0 < |v|^2 < 1/(4 m^2), U = primitive vector of P orthogonal to v"""
    T = F(1, 4) / (m * m); G = [[dot(p, p), dot(p, q)], [dot(p, q), dot(q, q)]]; det = G[0][0] * G[1][1] - G[0][1] ** 2
    Gi = [[F(G[1][1], det), F(-G[0][1], det)], [F(-G[0][1], det), F(G[0][0], det)]]   # Gram of dual basis
    Us = set(); K = int((T * max(G[0][0], G[1][1])) ** 0.5) + 2
    for k1 in range(0, K + 1):
        for k2 in range(-K, K + 1):
            if (k1, k2) <= (0, 0) and k1 == 0 and k2 <= 0: continue
            if gcd(k1, k2) != 1: continue
            n = k1 * k1 * Gi[0][0] + 2 * k1 * k2 * Gi[0][1] + k2 * k2 * Gi[1][1]
            if n >= T: continue
            # U = a p + b q with <U, v> = a k1 + b k2 = 0  ->  (a, b) = (k2, -k1)
            U = tuple(k2 * x - k1 * y for x, y in zip(p, q))
            if any(u == 0 for u in U): continue
            Us.add(U)
    return Us
def safe_exists(U):
    from fractions import Fraction as F
    # exact: candidate times are endpoints (k +- 1/6)/|u_i|
    S = [abs(u) for u in U]; L = max(S)
    for s in S:
        for k in range(0, s):
            for e in (F(1, 6), F(5, 6)):
                t = (k + e) / s
                if all(dist(x * t) >= F(1, 6) for x in S): return t
    return None
if __name__ == "__main__":
    random.seed(int(sys.argv[1])); NP = int(sys.argv[2]); z1 = (2, -1, 0, 0, 0)
    rows = [r for r in json.load(open("wbounds_double.json")) if r["m"] == "1/6"]
    W = random.sample(rows, 3); planes = []
    for r in W: planes += list(planes_exact(int_kernel([z1, r["z2"]]), F(r["T"])).values())
    sample = random.sample(planes, NP); st = {"planes": 0, "excluded": 0, "no_centre": 0, "margins": {}, "U_total": 0, "U_unsafe": 0}
    t0 = time.time()
    for p, q in sample:
        cols = [(p[i], q[i]) for i in range(5)]
        if any(c == (0, 0) for c in cols) or any(cols[i] == cols[j] or cols[i] == (-cols[j][0], -cols[j][1]) for i in range(5) for j in range(i + 1, 5)):
            st["excluded"] += 1; continue
        st["planes"] += 1
        Pperp = int_kernel([p, q])                          # saturated basis of P^perp (3 vectors)
        m, c = best_centre(Pperp)
        if m <= 0: st["no_centre"] += 1; continue
        st["margins"][str(m)] = st["margins"].get(str(m), 0) + 1
        Us = lines_of_plane(p, q, m); st["U_total"] += len(Us)
        for U in Us:
            if safe_exists(U) is None: st["U_unsafe"] += 1
    print("level-3 test on %d sampled planes (%.0f s): %s" % (NP, time.time() - t0, st))
