PT008-TF-R002-A46-T01 (Hesper) - Z=6 tail, z1=(2,1,1,0,0) (only shape of |z1|^2=6), TAIL 21609, range 1<=D<=744. Status: TEST.
Bound: bound6.py -> bound_6.txt (min b2*b3 = 128/441 over vertices; with b1>=1/2 added same; D<11907/16=744.1875 -> D<=744).
Batches: S=|p|^2 of reduced short basis vector, S=1..31 (3S^2/4<=D<=744).
Code: t46.py = A45 t01.py with Z1=(2,1,1,0,0), complement v1=-2v0-v2, candidate points R2..R7 (61 points, +-pairs merged; R2 added).
Run:    for s in 1..31: python3 t46.py $s 1 744 r_s$s fast      (numpy, numba)
Exact:  python3 exact46.py  -> exact46.log  (every cert row re-checked in integers/Fractions: SPEC spectral at recorded centre,
        POLY exact cell polar vertices f<=21609, R37(=R2-R7) exact intersection). Result: bad 0.
Cert columns: p q D N ix iy step.  'R37' label = R2-R7 intersection branch.
