# A46 exact re-check of every cert row (Fractions / integers only): SPEC rows by spectral criterion at the recorded centre,
# POLY rows by exact cell polygon (all polar vertices f<=TAIL), R37 rows by exact R2-R7 intersection (slow_path).
import sys,gzip,glob,math
from fractions import Fraction as F
sys.argv=['x','1','1','1','/dev/null']
src=open('t46.py').read().replace('\nmain()','\n')
src=src.replace('cache=True','cache=False'); exec(compile(src,'/workspace/work/pt008/a46/t46.py','exec'))
def rr(p,q,ix,iy,N):
    A=-1;B=1
    for i in range(5):
        m=(p[i]*ix+q[i]*iy)%N; mm=min(m,N-m); dd=6*mm-N
        if dd<=0: return None
        a=dd*dd;b=p[i]**2+q[i]**2
        if A<0 or a*B<A*b: A,B=a,b
    return A,B
tot={};bad=[]
for fn in sorted(glob.glob('r_s*_cert.tsv.gz'),key=lambda f:int(f[3:-12])):
    for l in gzip.open(fn,'rt'):
        ps,qs,D,N,ix,iy,st=l.split()
        p=list(map(int,ps.split(',')));q=list(map(int,qs.split(',')));N,ix,iy=int(N),int(ix),int(iy)
        assert sum(x*y for x,y in zip(Z1,p))==0 and sum(x*y for x,y in zip(Z1,q))==0
        assert int(D)==sum(x*x for x in p)*sum(x*x for x in q)-sum(x*y for x,y in zip(p,q))**2<=744
        ok=False
        if st=='SPEC':
            r=rr(p,q,ix,iy,N); ok=r is not None and spectral_exact(p,q,r[0],r[1],N)
        elif st=='POLY':
            c=cell_exact(p,q,F(ix,N),F(iy,N)); ok=bool(c) and all(fval(p,q,a,b)<=TAIL for a,b in c[1])
        elif st=='R37':
            s2,_=slow_path(p,q,(F(ix,N),F(iy,N)) if N else None); ok=s2 in('R37','FULL')
        tot[st]=tot.get(st,0)+1
        if not ok: bad.append(l)
print(tot,'bad',len(bad)); print(bad[:5])
