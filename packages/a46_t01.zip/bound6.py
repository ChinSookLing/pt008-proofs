# A46: independent check of D<=744 for Z=6. beta2*beta3 is quasi-concave on the positive orthant, so its min over a polytope is at a vertex.
from fractions import Fraction as F
from itertools import combinations
Z=6; S=F(4*Z,9)
def verts(H,dim):
    V=set()
    for tri in combinations(H,dim):
        A=[list(map(F,t[0]))+[F(t[1])] for t in tri]
        ok=True
        for i in range(dim):
            p=next((r for r in range(i,dim) if A[r][i]!=0),None)
            if p is None: ok=False;break
            A[i],A[p]=A[p],A[i]
            for r in range(dim):
                if r!=i and A[r][i]!=0:
                    f=A[r][i]/A[i][i]; A[r]=[x-f*y for x,y in zip(A[r],A[i])]
        if not ok: continue
        x=tuple(A[i][dim]/A[i][i] for i in range(dim))
        if all(sum(a*b for a,b in zip(h[0],x))>=h[1] for h in H): V.add(x)
    return V
# chair's 2D relaxation (b2,b3): 3b2+b3>=S, 2b3-b2>=0, b3<=2, b2,b3>=0
H2=[((3,1),S),((-1,2),0),((0,-1),-2),((1,0),0),((0,1),0)]
V2=verts(H2,2); m2=min(a*b for a,b in V2)
print('2D vertices',sorted(V2)); print('min b2b3 =',m2,' D<',F(Z**3)/m2,'=',float(F(Z**3)/m2))
# full 3D with b1>=1/2, b1<=2b2, b2<=2b3, b3<=2, sum>=S
H3=[((1,0,0),F(1,2)),((-1,2,0),0),((0,-1,2),0),((0,0,-1),-2),((1,1,1),S),((0,0,1),0),((0,1,0),0)]
V3=verts(H3,3); m3=min(v[1]*v[2] for v in V3)
print('3D vertices',sorted(V3)); print('min b2b3 (with b1>=1/2) =',m3,' D<',F(Z**3)/m3,'=',float(F(Z**3)/m3))
import math; Dmax=math.ceil(F(Z**3)/m2)-1; print('Dmax',Dmax)
# shapes of |z1|^2=6 up to signed permutation
sh=set()
r=range(-3,4)
import itertools
for v in itertools.product(r,repeat=5):
    if sum(x*x for x in v)==6: sh.add(tuple(sorted(map(abs,v),reverse=True)))
print('shapes',sh)
