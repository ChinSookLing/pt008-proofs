# A26: second bound crossed.  For the 456 cone-admissible z1 with |z1|^2 <= 12: number of second relations with 12 < |z2|^2 <= cap2 = 7 mu4^2/(4 eta4^2)
# (DESC') passing the cone test, i.e. the level-2 prefixes a removal of the second bound would add (each still followed by its own z3 range).
import sys
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "count"]
import class25 as C
from fractions import Fraction as F
from collections import Counter
Z1 = [z for z in C.prim_np(5, F(12)).tolist() if C.suffix_mixed(z)]; tot = 0; totc = 0; h = Counter()
for z1 in Z1:
    Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = C.coinc(M4); c2 = F(7 * m4) / (4 * e4 * e4)
    Z2 = C.prim_np(4, c2); Z2 = Z2[(Z2 * Z2).sum(1) > 12]
    if len(Z2) == 0: continue
    ok = C.cone_ok(Z2, C.rays(C.diffrows(M4))); tot += len(Z2); totc += int(ok.sum())
    for n2 in (Z2[ok] * Z2[ok]).sum(1).tolist(): h[min(n2 // 20 * 20, 300)] += 1
print("z1 with |z1|^2 <= 12 (456 prefixes): second relations 12 < |z2|^2 <= cap2: %d ; cone-admissible: %d ; |z2|^2 histogram (bucket 20): %s" % (tot, totc, dict(sorted(h.items()))))
Z1all = [z for z in C.prim_np(5, F(135, 4)).tolist() if C.suffix_mixed(z)]
print("first bound crossed: cone-admissible z1 with 12 < |z1|^2 <= 135/4: %d (of %d)" % (len([z for z in Z1all if sum(x * x for x in z) > 12]), len(Z1all)))
