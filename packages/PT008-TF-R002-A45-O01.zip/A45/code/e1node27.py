# A27 e1node27 (TEST, sampling of nodes; the tests themselves are exact): rates of the node-level Lemma SR exclusions E1N and E2N.
# Original header of outside27.py follows.
# A27 (TEST, sampling): search for TOP-RANK1 inputs (and double failures) at rank-2 nodes OUTSIDE C(12,12,80).
# Region R1: 12 < |z1|^2 <= 135/4, then z2, z3 uniformly among the cone-admissible relations inside DESC'.
# Region R2: |z1|^2 <= 12, 12 < |z2|^2 <= cap2, z3 inside DESC'.
# Region R3: |z1|^2, |z2|^2 <= 12, 80 < |z3|^2 <= cap3, prefixes outside the saturated set S of A26 (weighted by their beyond-80 node counts).
# At each sampled node every primitive in-sector w with K1 failure and exact rank-2 failure is replayed with the original BD-v19;
# TOP-RANK1 runs are recorded with their TRUE chain norms and the H6 readout (none = double failure witness).
import sys, random, json, time
region = sys.argv[1]; secs = float(sys.argv[2]); seed = int(sys.argv[3]) if len(sys.argv) > 3 else 27
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "cert"]
import class25 as C
import numpy as np
from fractions import Fraction as F
from collections import Counter
from bd19 import F19, dot
from explore27_lib import rank2_fail_leaves, h6first
rng = random.Random(seed)
Z1all = [z for z in C.prim_np(5, F(135, 4)).tolist() if C.suffix_mixed(z)]
Z1in = [z for z in Z1all if dot(z, z) <= 12]; Z1out = [z for z in Z1all if dot(z, z) > 12]
PREF = json.load(open("caps26_prefixes.json")); srt = sorted(PREF, key=lambda p: p[3]); S = set(); cum = 0
for p in srt:
    if cum + p[3] > 2000000: break
    cum += p[3]; S.add((tuple(p[0]), tuple(p[1])))
OPEN3 = [p for p in PREF if (tuple(p[0]), tuple(p[1])) not in S and p[3] > 0]; W3 = [p[3] for p in OPEN3]
def pick(arr): return arr[rng.randrange(len(arr))].tolist()
def node():
    if region == "R3":
        z1, z2, c3s, nb = rng.choices(OPEN3, weights=W3)[0]
        Lb4 = C.sub(C.I, z1); Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3); y3, e3, m3 = C.coinc(M3)
        Z3 = C.prim_np(3, F(3 * m3) / (4 * e3 * e3)); Z3 = Z3[(Z3 * Z3).sum(1) > 80]; Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
        return z1, z2, pick(Z3), Lb3
    z1 = rng.choice(Z1out if region == "R1" else Z1in)
    Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): return None
    y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, F(7 * m4) / (4 * e4 * e4))
    if region == "R2": Z2 = Z2[(Z2 * Z2).sum(1) > 12]
    Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    if not len(Z2): return None
    z2 = pick(Z2); Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3)
    if any(not any(r) for r in M3): return None
    y3, e3, m3 = C.coinc(M3); Z3 = C.prim_np(3, F(3 * m3) / (4 * e3 * e3)); Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
    if not len(Z3): return None
    return z1, z2, pick(Z3), Lb3
from sr27 import kernel_rows, lambda1_sq
t0 = time.time(); nodes = 0; e1 = 0; e2 = 0; either = 0
while time.time() - t0 < secs:
    r = node()
    if r is None: continue
    z1, z2, z3, Lb3 = r; Lb2 = C.sub(Lb3, z3); M2 = C.forms(Lb2)
    if any(not any(x) for x in M2): continue
    nodes += 1
    a = dot(z1, z1) > 8 * lambda1_sq(kernel_rows(Lb2))
    K2 = C.relation_kernel(tuple(z2)); K3 = C.relation_kernel(tuple(z3)); W = [[sum(K3[i][j] * K2[j][c] for j in range(3)) for c in range(4)] for i in range(2)]
    b = dot(z2, z2) > 4 * lambda1_sq(kernel_rows(W))
    e1 += a; e2 += b; either += a or b
print("region %s seed %d: sampled rank-2 nodes %d ; excluded by E1N %d (%.2f%%), by E2N %d (%.2f%%), by either %d (%.2f%%)" % (region, seed, nodes, e1, 100*e1/max(nodes,1), e2, 100*e2/max(nodes,1), either, 100*either/max(nodes,1)))
