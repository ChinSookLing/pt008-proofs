# A26: DESC' caps beyond the C(12,12,80) bounds.  For every cone-admissible chain prefix, the next relation is bounded by DESC':
#   |z1|^2 <= 135/4 (level 1, absolute),  |z2|^2 <= 7 mu4^2/(4 eta4^2),  |z3|^2 <= 3 mu3^2/(4 eta3^2).
# Report the caps (exact Fractions) over the prefixes with |z1|^2 <= 12 (level 2) and |z1|^2, |z2|^2 <= 12 (level 3), and count the level-3 relations
# beyond 80 that pass the cone test (the nodes a C(12,12,infinity) certificate would still need).
import sys, time
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "count"]
import class25 as C
from fractions import Fraction as F
import numpy as np
from collections import Counter
t0 = time.time()
Z1 = [z for z in C.prim_np(5, F(12)).tolist() if C.suffix_mixed(z)]
cap2 = []; cap3 = []; beyond = 0; beyond_rel = 0; hist = Counter(); worst = None
for z1 in Z1:
    Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = C.coinc(M4); c2 = F(7 * m4) / (4 * e4 * e4); cap2.append((c2, z1))
    Z2 = C.prim_np(4, min(F(12), c2)); Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    for z2 in Z2.tolist():
        Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3)
        if any(not any(r) for r in M3): continue
        y3, e3, m3 = C.coinc(M3); c3 = F(3 * m3) / (4 * e3 * e3); cap3.append(c3)
        if c3 > 80:
            Z3 = C.prim_np(3, c3); Z3 = Z3[(Z3 * Z3).sum(1) > 80]
            if len(Z3):
                ok = C.cone_ok(Z3, C.rays(C.diffrows(M3))); beyond_rel += len(Z3); beyond += int(ok.sum())
                for n2 in (Z3[ok] * Z3[ok]).sum(1).tolist(): hist[min(n2 // 40 * 40, 400)] += 1
        if worst is None or c3 > worst[0]: worst = (c3, z1, z2)
cap2.sort(reverse=True); cap3.sort(reverse=True)
print("level-2 caps 7mu^2/(4eta^2) over %d prefixes |z1|^2<=12: max %s (%.1f) at z1=%s ; median %.1f" % (len(cap2), cap2[0][0], float(cap2[0][0]), cap2[0][1], float(cap2[len(cap2) // 2][0])))
print("level-3 caps 3mu^2/(4eta^2) over %d prefixes |z1|^2,|z2|^2<=12: max %s (%.1f) at %s ; median %.1f ; prefixes with cap > 80: %d" % (len(cap3), worst[0], float(worst[0]), worst[1:], float(cap3[len(cap3) // 2]), sum(1 for c in cap3 if c > 80)))
print("level-3 relations with 80 < |z3|^2 <= cap: %d ; cone-admissible (= rank-2 nodes still needed for C(12,12,inf)): %d ; |z3|^2 histogram (bucket 40, 400 = >=400): %s  (%.0fs)" % (beyond_rel, beyond, dict(sorted(hist.items())), time.time() - t0))
