# A45: per-plane family certificate ("width polar body").  For a fixed saturated plane (p, q) with safe polygons {P_k}:
#   f_P(a,b) := M_P - m_P = max over vertex pairs v, w of P of  b (v_x - w_x) - a (v_y - w_y).
#   Lemma W: f_P(a,b) >= 1 for some P  ⇒  ⌈m_P⌉ <= M_P  ⇒  the rule returns a safe time for (a, b).
#   So every primitive (a,b) OUTSIDE the open, convex, centrally symmetric polygon
#        K_W = { (a,b) : |b dx - a dy| < 1 for every difference d = v - w of vertices of a common P }
#   is covered at once (a whole family: all directions, all D).  Only the finitely many lattice points inside K_W need the exact rule.
# Usage: python3 cert45.py NPLANES SEED   (same plane sampler as planes45.py)
import sys, random, time
from fractions import Fraction as F
from math import gcd, ceil, floor
from sr28 import kernel_rows
from poly45 import polygons, is_safe, rule
from bd19 import dot
z1 = [2, 1, 1, 1, 0]; K4 = kernel_rows([z1])
def gram2(p, q): return dot(p, p) * dot(q, q) - dot(p, q) ** 2
def reduce2(p, q):
    while True:
        if dot(p, p) > dot(q, q): p, q = q, p
        k = round(F(dot(p, q), dot(p, p)))
        if k == 0: return p, q
        q = [b - k * a for a, b in zip(p, q)]
def kw_points(polys):
    """lattice points (a,b) != 0 strictly inside K_W (exact)."""
    D = set()
    for k, P in polys:
        for v in P:
            for w in P:
                if v != w: D.add((v[0] - w[0], v[1] - w[1]))
    D = list(D)
    if not D: return None                                   # no 2-point polygon at all: K_W is the whole plane (no family cover)
    # bounding parallelogram from the pair with the largest |det|
    best = max(((d1, d2) for d1 in D[:200] for d2 in D[:200]), key=lambda t: abs(t[0][0] * t[1][1] - t[0][1] * t[1][0]))
    (x1, y1), (x2, y2) = best; det = x1 * y2 - y1 * x2
    if det == 0: return None                                # all differences parallel: K_W is an unbounded strip
    # L1 = b x1 - a y1, L2 = b x2 - a y2 ; solve for (a, b):  [ -y1 x1 ; -y2 x2 ] (a,b)^T = (L1, L2)^T
    # a = (x2 L1 - x1 L2)/(-y1 x2 + x1 y2)... use Cramer with M = [[-y1, x1], [-y2, x2]], detM = -y1 x2 + x1 y2 = det
    amax = (abs(x2) + abs(x1)) / abs(det); bmax = (abs(y2) + abs(y1)) / abs(det)
    pts = []
    for a in range(-floor(amax), floor(amax) + 1):
        for b in range(-floor(bmax), floor(bmax) + 1):
            if (a, b) == (0, 0): continue
            if all(abs(b * dx - a * dy) < 1 for dx, dy in D): pts.append((a, b))
    return pts
rng = random.Random(int(sys.argv[2])); NP = int(sys.argv[1]); t0 = time.time()
planes = 0; maxUU = (0, None); closed = 0; unbounded = 0; inside_tot = 0; checked = 0; maxpts = 0; ex = None
while planes < NP:
    R = rng.choice([2, 3, 4, 6, 8, 12])
    c1 = [rng.randint(-R, R) for _ in range(4)]; c2 = [rng.randint(-R, R) for _ in range(4)]
    v1 = [sum(c1[j] * K4[j][c] for j in range(4)) for c in range(5)]; v2 = [sum(c2[j] * K4[j][c] for j in range(4)) for c in range(5)]
    if gram2(v1, v2) == 0: continue
    p, q = kernel_rows(kernel_rows([v1, v2])); p, q = reduce2(list(p), list(q))
    if gram2(p, q) > 4630 or any(x == 0 and y == 0 for x, y in zip(p, q)): continue   # a zero coordinate on the whole plane: no valid U
    polys = polygons(p, q); planes += 1
    pts = kw_points(polys)
    if pts is None: unbounded += 1; continue
    inside_tot += len(pts); maxpts = max(maxpts, len(pts)); ok = True
    for a, b in pts:
        if gcd(a, b) != 1: continue
        U = [a * x + b * y for x, y in zip(p, q)]
        if all(u != 0 for u in U) and dot(U, U) > maxUU[0]: maxUU = (dot(U, U), (p, q, a, b, U))
        if dot(U, U) < 21609 or any(u == 0 for u in U): continue
        checked += 1; r = rule(p, q, a, b, polys)
        if r is None or not is_safe(U, r[0]): ok = False; print("NOT CLOSED", p, q, a, b, U)
    closed += ok
    if ex is None and pts: ex = (p, q, len(pts), pts[:6])
print("planes %d ; K_W bounded: %d (unbounded/degenerate: %d) ; planes closed for EVERY primitive (a,b) with |U|^2 >= 21609 and all u_i != 0: %d ;"
      " lattice points inside K_W: total %d, max per plane %d ; of these needing the exact rule (primitive, |U|^2 >= 21609): %d ; %.0f s"
      % (planes, planes - unbounded, unbounded, closed, inside_tot, maxpts, checked, time.time() - t0))
print("example plane:", ex)
print("largest |U|^2 among primitive lattice points inside K_W with all u_i != 0 (the margin to 21609):", maxUU)
