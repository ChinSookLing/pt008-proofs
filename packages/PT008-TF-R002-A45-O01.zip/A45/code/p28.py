# A28 (TEST): distribution of the level-1 LLL profile P = sum_{j<4}|b*_j|^2 / |b*_4|^2 over random normalized inputs (failing or not).
# Failure at level 1 forces |z1|^2 < 9(1+P)/4 (Lemma RP with Cauchy); a proof of P < 4s/9 - 1 at failures would exclude s.
import random, sys
from fractions import Fraction as F
from collections import Counter
from row28 import level_data
from math import gcd
from functools import reduce
rng = random.Random(int(sys.argv[2])); NS = int(sys.argv[1])
I = [[int(i == j) for j in range(5)] for i in range(5)]; Y = [F(1, 2)] * 5
hist = Counter(); best = []
for H in (20, 40, 80, 160, 320, 640, 1280, 5000, 20000):
    for _ in range(NS):
        U = sorted(rng.sample(range(1, H), 5))
        if reduce(gcd, U) != 1: continue
        D = level_data(I, Y, U, 6)
        if "z" not in D: continue
        P = D["P"]; hist[int(P)] += 1; best.append((float(P), D["zz"], D["fail"], U))
best.sort(reverse=True)
print("inputs %d ; histogram of floor(P): %s" % (sum(hist.values()), dict(sorted(hist.items()))))
print("largest P (P, |z|^2, level-1 fails?, U):", best[:6])
# inputs with G1 failing, |z1|^2 >= 13 and P above the level 4s/9 - 1 that a profile-only lemma would need to forbid
import bd19
cand = [(P - (4 * s / 9 - 1), P, s, f, U) for P, s, f, U in best if s >= 13 and bd19.farey_gate(U, 6) is None and P > 4 * s / 9 - 1]
cand.sort(reverse=True)
print("G1-failing inputs with |z1|^2 >= 13 and P > 4|z1|^2/9 - 1: %d ; level-1 failures among them: %d ; top (excess, P, |z1|^2, fails?, U): %s"
      % (len(cand), sum(1 for c in cand if c[3]), [(round(c[0], 3), round(c[1], 3), c[2], c[3], c[4]) for c in cand[:4]]))
