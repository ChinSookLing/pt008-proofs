# A20 Lemma BR (bad-residue exclusion) and the direct selection it gives.
# Threshold 1/N, denominator q >= 2, k(q) = ceil(q/N) - 1, bad residues B_q = { r mod q : |r|_q <= k(q) }  (i.e. |r|_q < q/N).
# For a unit a mod q:  a/q is safe for U  <=>  u a mod q not in B_q for every u  <=>  a not in Forb_q(U) = U_u { a : u a in B_q }.
from math import gcd
from fractions import Fraction as F
def kq(q, N): return -(-q // N) - 1
def bad(q, N): k = kq(q, N); return [r % q for r in range(-k, k + 1)]
def forb(U, q, N):
    """the forbidden numerators (units mod q), built residue by residue: u a = r has solutions iff gcd(u,q) | r; then a = (r/g)(u/g)^{-1} mod q/g, lifted."""
    units = {a for a in range(1, q) if gcd(a, q) == 1}; Fb = set()
    for u in U:
        u %= q
        if u == 0: return units                                   # u a = 0 in B_q for every a
        g = gcd(u, q); qg = q // g; ui = pow(u // g, -1, qg) if qg > 1 else 0
        for r in bad(q, N):
            if r % g: continue
            a0 = (r // g) * ui % qg if qg > 1 else 0
            for t in range(g):
                a = (a0 + t * qg) % q
                if a in units: Fb.add(a)
    return Fb
def br_select(U, q, N):
    """direct selection: the least unit a not forbidden, or None.  Returns the time a/q (for the normalised U)."""
    Fb = forb(U, q, N)
    for a in range(1, q):
        if gcd(a, q) == 1 and a not in Fb: return F(a, q)
    return None
def mc_select(U, q, N):
    """band k(q) = 1 (N < q <= 2N): missing-unit-class rule.  B_q = {0, +-1}: unit u forbids +-u^{-1}; a non-unit nonzero u forbids nothing.
    Safe a exists iff q divides no u and the folded unit classes of U miss some class c; then a = c^{-1} (C34's q = 9 rule is the case q = 9, N = 6)."""
    assert kq(q, N) == 1
    S = set()
    for u in U:
        r = u % q
        if r == 0: return None
        if gcd(r, q) == 1: S.add(min(r, q - r))
    for c in sorted({min(x, q - x) for x in range(1, q) if gcd(x, q) == 1}):
        if c not in S:
            a = pow(c, -1, q); return F(min(a, q - a), q)
    return None
def scan_select(U, q, N):
    from a02_lib import dist
    for a in range(1, q):
        if gcd(a, q) == 1 and all(dist(F(u * a, q)) >= F(1, N) for u in U): return F(a, q)
    return None
if __name__ == "__main__":
    # TEST: br_select == scan_select (least safe numerator) and mc_select gives a safe time exactly when one exists, for many U, N, q
    import random
    from a02_lib import dist
    rng = random.Random(20); bad_ = 0; n = 0; mcbad = 0
    for _ in range(30000):
        N = rng.randint(3, 9); q = rng.randint(2, 3 * N); m = rng.randint(1, N - 1)
        U = [rng.randint(1, 10 ** rng.randint(1, 6)) for _ in range(m)]
        a = br_select(U, q, N); b = scan_select(U, q, N); n += 1; bad_ += (a != b)
        if kq(q, N) == 1:
            c = mc_select(U, q, N)
            mcbad += not ((c is None) == (b is None) and (c is None or all(dist(u * c) >= F(1, N) for u in U)))
    print("BR selection vs fixed scan: %d cases, %d differences ; MC rule (k = 1 band): existence agrees and output safe in all cases: %s" % (n, bad_, mcbad == 0))
