# A29: the exact counterexample to "the double-even condition can be read off the chain (z1, z2)".
# U = (3,5,6,9,12): G1 fails, original BD-v19 = TOP-RANK1 (known A20 exception).  Everything below is exact.
from fractions import Fraction as F
import bd19
from bd19 import dot
from dual29 import level1_dual, preimage
for U in ([3, 5, 6, 9, 12], [1, 5, 6, 7, 8], [3, 5, 8, 9, 12]):
    st, t, tr = bd19.F19(6, U); L = tr["levels"]; D = level1_dual(U)
    z1 = D["z"]; q = D["q"]; Lb4 = L[1]["basis"]; z2 = L[1]["z"]; x2 = preimage(Lb4, z1, z2); Lq = [dot(r, q) for r in Lb4]; s = dot(z1, z1)
    print("U = %s : G1 %s ; BD-v19 %s (%s) ; true chain |z|^2 = %s" % (U, bd19.farey_gate(U, 6), st, tr["end"], [dot(lv["z"], lv["z"]) for lv in L if "z" in lv]))
    print("   level 1: z1 = %s (sum %d), q = %s (sum %d), mu = %s, delta = c_4 = %s, c_3 = %s ; Babai GS coefficients = (%s)" %
          (z1, sum(z1), q, sum(q), D["mu"], D["delta"], D["c3"], ", ".join(str(v) for v in D["gsc"])))
    print("   chain: Lb4 = %s ; z2 = %s ; x2 = %s (sum %d) ; Lb4.q = %s ; link Lb4.q = +-z2: %s" % (Lb4, z2, x2, sum(x2), Lq, Lq == z2 or Lq == [-v for v in z2]))
    # the two quadratic forms on Rel(U)/Z z1 = Rel(w2): level 1 uses the quotient norm |y|^2 - (y.z1)^2/|z1|^2 ; level 2 uses |Lb4 y|^2
    qn = lambda y: F(dot(y, y)) - F(dot(y, z1)) ** 2 / s
    print("   level-1 (quotient) norms: q %s, x2 %s   |   level-2 (coordinate) norms: Lb4.q %d, z2 %d" % (qn(q), qn(x2), dot(Lq, Lq), dot(z2, z2)))
# the same prefix (z1, z2) = ((-1,0,0,-1,1), (1,-1,-1,1)) carries two different level-1 dual classes: (1,5,6,7,8) has Lb4.q = +-(0,-1,2,-1) != +-z2, (3,5,8,9,12) has Lb4.q = +-z2.
