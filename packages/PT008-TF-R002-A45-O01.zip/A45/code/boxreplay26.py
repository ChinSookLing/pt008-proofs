# A26: replay every box survivor (K1 fails, H6 misses, DESC' top relation exists) with the original BD-v19 at N = 6; a TOP-RANK1 run is a double failure.
import sys, time, json
from collections import Counter
from multiprocessing import Pool
from bd19 import F19
from a02_lib import safe
def job(line):
    U = [int(x) for x in line.split()[1:]]
    st, t, tr = F19(6, U)
    ok = safe(U, 6, t) if st == "SAFE" else None
    return U, st, tr["end"][:20], tr.get("kind"), str(t), ok, [lv.get("z") for lv in tr["levels"]]
if __name__ == "__main__":
    lines = [l for l in open(sys.argv[1]) if l.startswith("S")]; t0 = time.time(); out = []
    with Pool(2) as p: out = list(p.imap_unordered(job, lines, chunksize=200))
    c = Counter((st, end) for U, st, end, k, t, ok, zs in out)
    dbl = [(U, k, zs) for U, st, end, k, t, ok, zs in out if st != "SAFE"]
    print("%s: survivors %d ; outcomes %s ; all SAFE outputs exact-safe: %s ; DOUBLE FAILURES (not SAFE): %d %s  (%.0fs)"
          % (sys.argv[1], len(out), dict(c), all(ok for U, st, end, k, t, ok, zs in out if st == "SAFE"), len(dbl), dbl[:5], time.time() - t0))
    json.dump(sorted(out), open(sys.argv[1].replace(".txt", "_replay.json"), "w"))
