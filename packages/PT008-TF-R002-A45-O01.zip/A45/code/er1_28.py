# A28: Lemma RP at level 1 as an exact test on z1 alone (Theorem B1).
# Level 1: M = I, y* = (1/2,...), eta_i = 1/3, n = 4, delta = 0 if |z1|^2 even, |delta| = 1/2 if odd (Lemma P), |pi_w e_i|^2 = 1 - u_i^2/|U|^2 <= 1.
# A level-1 Babai failure with relation z1 (s = |z1|^2) needs a row i with
#    lhs_i = 1/3 - |delta| |z_i| / s  <  (1/2) sqrt( (14/s) (1 - z_i^2/s) )          (the u-term only lowers the right side, so dropping it keeps this necessary)
# ER1(z1) := no row satisfies it  =>  z1 is never the first relation of BD-v19, for any input.   (exact rational arithmetic)
import sys, json, time
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "count"]
import class25 as C
import numpy as np
from fractions import Fraction as F
from collections import Counter
from bd19 import dot
def row_ok(z, i):
    s = dot(z, z); dl = F(1, 2) if s % 2 else F(0); lhs = F(1, 3) - dl * abs(z[i]) / s
    return lhs < 0 or 4 * lhs * lhs < F(14, s) * (1 - F(z[i] * z[i], s))
def er1(z): return not any(row_ok(z, i) for i in range(len(z)))
t0 = time.time()
Z1all = [z for z in C.prim_np(5, F(135, 4)).tolist() if C.suffix_mixed(z)]
byS = Counter(); exS = Counter(); EX = []
for z in Z1all:
    s = dot(z, z); byS[s] += 1
    if er1(z): exS[s] += 1; EX.append(z)
print("cone-admissible z1 with |z1|^2 <= 135/4: %d ; excluded by ER1: %d" % (len(Z1all), len(EX)))
print("  by |z1|^2 (excluded/all): " + "  ".join("%d:%d/%d" % (s, exS[s], byS[s]) for s in sorted(byS)))
# prefix counts under the excluded z1 (same prefix definition as e1pref27: z2 cone-admissible inside DESC')
pre = Counter(); preAll = Counter()
for z1 in EX:
    Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, F(7 * m4) / (4 * e4 * e4)); Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    pre[dot(z1, z1)] += len(Z2)
print("  prefixes (z1, z2) removed with them: %d ; by |z1|^2: %s ; %.0f s" % (sum(pre.values()), dict(sorted(pre.items())), time.time() - t0))
# sanity: which rows survive at s = 33 and s = 31 (pattern of |z_i| allowed to be the failing row)
for s in (29, 30, 31, 33):
    allowed = sorted({abs(z[i]) for z in Z1all if dot(z, z) == s for i in range(5) if row_ok(z, i)})
    print("  s = %d: |z_i| values that can be a failing row: %s" % (s, allowed))
json.dump(EX, open("er1_28_excluded.json", "w"))
