# A29 (TEST, exhaustive): same enumeration as exh28 (normalized, gcd 1, G1 failing, Hlo < u5 <= Hhi) but RECORDS every input whose level 1 fails.
import sys, json, time
from itertools import combinations
from math import gcd
from functools import reduce
from fractions import Fraction as F
from row28 import level_data
Hlo, Hhi, k, K = map(int, sys.argv[1:5])
I = [[int(i == j) for j in range(5)] for i in range(5)]; Y = [F(1, 2)] * 5
t0 = time.process_time(); tot = 0; out = []
for u5 in range(Hlo + 1, Hhi + 1):
    if u5 % K != k: continue
    for c in combinations(range(1, u5), 4):
        U = list(c) + [u5]
        if reduce(gcd, U) != 1 or not all(any(u % q == 0 for u in U) for q in range(2, 7)): continue
        tot += 1
        if level_data(I, Y, U, 6)["fail"]: out.append(U)
json.dump({"tot": tot, "fail": out}, open("exhlist29_%d_%d_%d.json" % (Hlo, Hhi, k), "w"))
print("H in (%d,%d] shard %d/%d: G1-failing %d ; level-1 failures %d ; cpu %.0f s" % (Hlo, Hhi, k, K, tot, len(out), time.process_time() - t0))
