# A19 exact LLL with incremental Gram-Schmidt updates.  SAME algorithm as lll.lll (A17/A18): for k = 1..: size-reduce row k against
# rows k-1, ..., 0 with q = round(mu[k][j]) (Python round on Fraction: nearest, ties to even), then the Lovasz test with delta = 3/4,
# swap and k <- max(k-1, 1) on failure.  Only the bookkeeping differs (mu and |b*|^2 are updated by the textbook exact formulas instead of
# recomputing the whole GSO), so every comparison and every rounding sees identical exact rationals and the output is identical.
from fractions import Fraction as F
def lll(B, delta=F(3, 4)):
    B = [list(r) for r in B]; n = len(B)
    if n == 0: return B
    def dot(a, b): return sum(x * y for x, y in zip(a, b))
    Bs = []; mu = [[F(0)] * n for _ in range(n)]; bb = [F(0)] * n
    for i in range(n):
        v = [F(x) for x in B[i]]
        for j in range(i):
            mu[i][j] = F(dot(B[i], Bs[j])) / bb[j]; v = [a - mu[i][j] * b for a, b in zip(v, Bs[j])]
        Bs.append(v); bb[i] = dot(v, v)
    k = 1
    while k < n:
        for j in range(k - 1, -1, -1):
            q = round(mu[k][j])
            if q:
                B[k] = [a - q * b for a, b in zip(B[k], B[j])]
                for i in range(j): mu[k][i] -= q * mu[j][i]
                mu[k][j] -= q
        if bb[k] >= (delta - mu[k][k - 1] ** 2) * bb[k - 1]:
            k += 1
        else:
            m_ = mu[k][k - 1]; Bk = bb[k] + m_ * m_ * bb[k - 1]
            B[k], B[k - 1] = B[k - 1], B[k]
            Bs_km1_old, Bs_k_old = Bs[k - 1], Bs[k]
            newbkm1 = [a + m_ * b for a, b in zip(Bs_k_old, Bs_km1_old)]
            mu_new = m_ * bb[k - 1] / Bk
            newbk = [a - mu_new * b for a, b in zip(Bs_km1_old, newbkm1)]
            bb_k = bb[k - 1] * bb[k] / Bk
            Bs[k - 1], Bs[k] = newbkm1, newbk; bb[k - 1], bb[k] = Bk, bb_k
            for j in range(k - 1): mu[k - 1][j], mu[k][j] = mu[k][j], mu[k - 1][j]
            for i in range(k + 1, n):
                t = mu[i][k]; mu[i][k] = mu[i][k - 1] - m_ * t; mu[i][k - 1] = t + mu_new * mu[i][k]
            mu[k][k - 1] = mu_new
            k = max(k - 1, 1)
    return B
