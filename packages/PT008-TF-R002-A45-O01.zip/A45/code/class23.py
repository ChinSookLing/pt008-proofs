# A23: class22 + C40 kernel cache in sub() (NOCACHE=1 restores the original sub) + third-level lower bound c3lo + timing split.
# Usage: class23.py c1lo c1 c2lo c2 c3lo c3 [cert|count]
# A22 branch certificate (A21 class21.py + C36 guards/masks + branch ranges + count mode).
# Usage: class22.py c1lo c1 c2lo c2 c3 [cert|count]   chains with c1lo < |z1|^2 <= c1, c2lo < |z2|^2 <= c2, |z3|^2 <= c3 (and the DESC' bounds).
# A21 closure certificate for a CLASS of N = 6 nodes (m = 5), or a counterexample.
# Class C(c1, c2, c3): BD-v19 chains z1 -> z2 -> z3 (levels d = 5, 4, 3) with |z_i|^2 <= c_i, inside the DESC' bounds, passing the cone tests
# (CN1 in R^5; CN2 in R^4 and R^3: the next kernel must meet the open cone of strictly increasing positive inputs).
# For every rank-2 node of the class, every primitive w in the open sector with the exact rank-2 failure (C32: implies D <= mu^2/(4 eta^2)) and K1 failure
# is checked against H6 (q = 7..18, Lemma BR).  An H6 miss is replayed with the full rule: a TOP-RANK1 run would be a counterexample.
# Claim certified when the run ends with 0 counterexamples: every input whose BD-v19 run is TOP-RANK1 with chain in C(c1,c2,c3) gets a time from H6.
import sys, time, itertools, json
import numpy as np
from fractions import Fraction as F
from math import gcd, isqrt
from multiprocessing import Pool
from bd19 import F18, F19, relations18, dot
import dclose
from a02_lib import dist
from cone19 import suffix_mixed, diffrows
from util21 import prim_np, rays, cone_ok
from br20 import mc_select, br_select, kq
N = 6; m = 5
c1lo, c1, c2lo, c2, c3lo, c3 = (F(x) for x in sys.argv[1:7]); MODE = sys.argv[7] if len(sys.argv) > 7 else "cert"
I = [[int(i == j) for j in range(m)] for i in range(m)]
KNOWN = {tuple(r[0]) for r in json.load(open('union20.json'))}
import os
from functools import cache
def sub_orig(Lb, z):
    K = relations18(z); d = len(Lb); return [[sum(c[j] * Lb[j][i] for j in range(d)) for i in range(m)] for c in K]
@cache
def relation_kernel(z):                  # C40: the original relations18 kernel, keyed by the full ordered integer vector z (dimension included)
    return tuple(map(tuple, relations18(list(z))))
def sub_cached(Lb, z):
    return [[sum(cj * bj for cj, bj in zip(c, column)) for column in zip(*Lb)] for c in relation_kernel(tuple(z))]
sub = sub_orig if os.environ.get("NOCACHE") else sub_cached
def forms(Lb): d = len(Lb); return [[Lb[j][i] for j in range(d)] for i in range(m)]
def coinc(M):
    u, s, _ = dclose.coincidence_line(M); sd = sorted({abs(x) for x in s}); st, ts, _ = F18(len(sd) + 1, sd); assert st == "SAFE"
    ys = [ts * c for c in u]; eta = min(dist(dot(Mi, ys)) for Mi in M) - F(1, N); assert eta > 0
    return ys, eta, max(dot(r, r) for r in M)
def h6(U):
    for q in range(N + 1, 3 * N + 1):
        t = mc_select(U, q, N) if kq(q, N) == 1 else br_select(U, q, N)
        if t is not None: return q
    return None
MASKS = {}
for mod in range(7, 19):
    units = [a for a in range(1, (mod//2)+1) if gcd(a, mod) == 1]
    MASKS[mod] = np.array([
        sum(1 << j for j,a in enumerate(units) if 6*min(a*u % mod, -a*u % mod) >= mod)
        for u in range(mod)], dtype=np.int64)

def leaves(M2, ys, eta, mu2, st):
    """rank-2 node: all primitive w in the open sector, exact rank-2 failure, K1 failure; H6 on the survivors; replay of H6 misses."""
    from math import lcm
    H = lcm(ys[0].denominator, ys[1].denominator); Y = [int(y * H) for y in ys]
    Dmax = mu2 / (4 * eta * eta); R = isqrt(int(Dmax))
    lim = (1 << 63) - 1
    M = max(abs(x) for row in M2 for x in row)
    E, G = eta.numerator, eta.denominator
    assert all(abs(x) <= lim for x in (H, *Y, 2*R*R, 8*R*R*E*E, mu2*G*G, 4*M*R, 2*M))
    Z = R * (abs(Y[0]) + abs(Y[1]))
    assert max(Z + H, 2*H, Z+2*H, 6*H*2*R*R, 2*R*R*M*(abs(Y[0])+abs(Y[1])) + H*M*R) <= lim
    ax = np.arange(-R, R + 1, dtype=np.int64); P, Q = np.meshgrid(ax, ax, indexing="ij"); P = P.ravel(); Q = Q.ravel()
    D = P * P + Q * Q; keep = (D > 0) & (D * 4 * eta.numerator ** 2 <= mu2 * eta.denominator ** 2)
    A = np.array(diffrows(M2), dtype=np.int64); Mn = np.array(M2, dtype=np.int64)
    W = np.stack([P, Q], 1)
    keep &= np.all(W @ A.T > 0, axis=1); keep &= np.gcd(P, Q) == 1
    P, Q, D = P[keep], Q[keep], D[keep]; st["in_sector"] += len(P)
    if len(P) == 0: st["node_closed_sector"] += 1; return []
    U = (Mn @ np.stack([P, Q])).T
    k1 = np.any(U % 4 == 0, 1) & np.any(U % 5 == 0, 1) & np.any(U % 6 == 0, 1)
    P, Q, D, U = P[k1], Q[k1], D[k1], U[k1]; st["K1_miss"] += len(P)
    if len(P) == 0: st["node_closed_K1"] += 1; return []
    Zn = -Q * Y[0] + P * Y[1]; r0 = np.floor_divide(Zn, H); rem = Zn - H * r0
    r = r0 + (2 * rem > H) + ((2 * rem == H) & (r0 % 2 != 0)); dH = Zn - H * r
    nz = dH != 0; P, Q, D, U, dH = P[nz], Q[nz], D[nz], U[nz], dH[nz]
    fail = np.zeros(len(P), dtype=bool)
    for i in range(m):
        c = -Mn[i, 0] * Q + Mn[i, 1] * P; MY = int(Mn[i, 0]) * Y[0] + int(Mn[i, 1]) * Y[1]
        num = D * MY - dH * c; den = H * D; s = np.mod(num, den); dd = np.minimum(s, den - s)
        fail |= 6 * dd < den
    st["rank2_fails"] += int(fail.sum()); out = []
    if not fail.any(): st["node_closed_rank2"] += 1; return []
    miss0 = st["H6_miss"]
    UV = U[fail]
    # Independent H6 check by intersecting masks for all five original residues.
    h6_miss = np.ones(len(UV), dtype=bool)
    for modulus, mask in MASKS.items():
        live = np.flatnonzero(h6_miss)
        if not len(live):
            break
        h6_miss[live] = np.bitwise_and.reduce(mask[UV[live] % modulus],axis=1) == 0
    for u, missing in zip(UV.tolist(), h6_miss.tolist()):
        if tuple(u) in KNOWN: st["known_hit"] += 1; st.setdefault("_known", set()).add(tuple(u))
        if missing:
            assert h6(u) is None
            st["H6_miss"] += 1
            s_, t_, tr = F19(N, u); st.setdefault("_miss", {})[tuple(u)] = (s_, tr["end"][:20], str(t_))
            if s_ != "SAFE": out.append((u, tr.get("kind",s_)))
            assert s_ != "SAFE" or (t_ is not None and all(dist(a*t_) >= F(1,6) for a in u))
    if st["H6_miss"] == miss0: st["node_closed_H6"] += 1
    else: st["node_closed_replay"] += 1
    return out
def job(z1):
    st = {k: 0 for k in ("L2_rel", "L2_cone", "L3_rel", "L3_cone", "nodes", "in_sector", "K1_miss", "rank2_fails", "H6_miss", "known_hit", "t_nodeprep_ms", "t_leaves_ms", "node_closed_sector", "node_closed_K1", "node_closed_rank2", "node_closed_H6", "node_closed_replay")}; cex = []
    Lb4 = sub(I, z1); M4 = forms(Lb4)
    if any(not any(r) for r in M4): return st, cex
    y4, e4, m4 = coinc(M4); b2 = min(c2, F(7 * m4) / (4 * e4 * e4))
    Z2 = prim_np(4, b2); Z2 = Z2[(Z2 * Z2).sum(1) > c2lo]
    if len(Z2) == 0: return st, cex
    ok = cone_ok(Z2, rays(diffrows(M4))); st["L2_rel"] += len(Z2); st["L2_cone"] += int(ok.sum())
    for z2 in Z2[ok].tolist():
        Lb3 = sub(Lb4, z2); M3 = forms(Lb3)
        if any(not any(r) for r in M3): continue
        y3, e3, m3 = coinc(M3); b3 = min(c3, F(3 * m3) / (4 * e3 * e3))
        Z3 = prim_np(3, b3); Z3 = Z3[(Z3 * Z3).sum(1) > c3lo]
        if len(Z3) == 0: continue
        ok3 = cone_ok(Z3, rays(diffrows(M3))); st["L3_rel"] += len(Z3); st["L3_cone"] += int(ok3.sum())
        if MODE == "count": continue
        for z3 in Z3[ok3].tolist():
            _t = time.time(); Lb2 = sub(Lb3, z3); M2 = forms(Lb2)
            if any(not any(r) for r in M2): continue
            ys, eta, mu2 = coinc(M2); st["nodes"] += 1; _u = time.time(); st["t_nodeprep_ms"] += (_u - _t) * 1000
            cex += [(u, k, z1, z2, z3) for u, k in leaves(M2, ys, eta, mu2, st)]; st["t_leaves_ms"] += (time.time() - _u) * 1000
    return st, cex
if __name__ == "__main__":
    t0 = time.time()
    R1 = min(c1, F(15) / (4 * (F(1, 2) - F(1, N)) ** 2))
    Z1 = [z for z in prim_np(5, R1).tolist() if sum(x * x for x in z) > c1lo]; Z1c = [z for z in Z1 if suffix_mixed(z)]
    import os
    if os.environ.get("BATCH"):                                   # batch k of K: every K-th admissible z1 starting at k (sorted order)
        k_, K_ = map(int, os.environ["BATCH"].split("/")); Z1c = Z1c[k_::K_]
    tot = {"L1_rel": len(Z1), "L1_cone": len(Z1c)}; cex = []; KH = set(); MISS = {}
    with Pool(2) as p:
        for st, cx in p.imap_unordered(job, Z1c):
            for k, v in st.items():
                if k == "_known": KH.update(v)
                elif k == "_miss": MISS.update(v)
                else: tot[k] = tot.get(k, 0) + v
            cex += cx
    tot["known_distinct_hit"] = len(KH); tot["H6_miss_distinct"] = len(MISS)
    from collections import Counter
    tot["H6_miss_outcomes"] = dict(Counter(v[1] for v in MISS.values()))
    tot["t_nodeprep_ms"] = round(tot["t_nodeprep_ms"]); tot["t_leaves_ms"] = round(tot["t_leaves_ms"])
    tag = "%s-%s_%s-%s_%s-%s_%s%s%s" % (c1lo, c1, c2lo, c2, c3lo, c3, MODE, "_nocache" if os.environ.get("NOCACHE") else "", ("_b" + os.environ["BATCH"].replace("/", "of")) if os.environ.get("BATCH") else "")
    json.dump(sorted([list(k), v] for k, v in MISS.items()), open("class23_%s_H6miss.json" % tag, "w"))
    print("branch (%s,%s]x(%s,%s]x(%s,%s] %s%s: %s ; counterexamples (TOP-RANK1 with H6 miss): %d %s  (%.0fs)" % (c1lo, c1, c2lo, c2, c3lo, c3, MODE, (" batch " + os.environ["BATCH"]) if os.environ.get("BATCH") else "", tot, len(cex), cex[:5], time.time() - t0))
    json.dump({"branch": [str(x) for x in (c1lo, c1, c2lo, c2, c3lo, c3)], "mode": MODE, "counts": tot, "counterexamples": cex}, open("class23_%s.json" % tag, "w"))
