# A45 (TEST, sampling — not a certificate): saturated planes inside z1^perp, z1 = (2,1,1,1,0) (every other signed arrangement of the
# shape is mapped to this one by a signed coordinate permutation, which preserves the rule and safety), Gram det |p∧q|^2 <= 4630.
# For each sampled plane: all primitive (a,b) (up to sign) with a^2+b^2 <= 728, |U|^2 >= 21609, every u_i != 0.
# Records: rule hit / miss (miss would be an LRC(6) counterexample), returned t safe (exact), and how many are covered by the
# width test M_P - m_P >= 1 alone (the linear-in-(a,b) family part).
import sys, random, time
from fractions import Fraction as F
from math import gcd, ceil, isqrt
from sr28 import kernel_rows
from poly45 import polygons, safe_set, is_safe, egcd
from bd19 import dot
z1 = [2, 1, 1, 1, 0]
K4 = kernel_rows([z1])
def gram2(p, q): return dot(p, p) * dot(q, q) - dot(p, q) ** 2
def reduce2(p, q):
    while True:
        if dot(p, p) > dot(q, q): p, q = q, p
        k = round(F(dot(p, q), dot(p, p)))
        if k == 0: return p, q
        q = [b - k * a for a, b in zip(p, q)]
rng = random.Random(int(sys.argv[2])); NP = int(sys.argv[1]); t0 = time.time()
tot = hit = miss = width_only = 0; worst = []; planes = 0; npoly = []; dets = []
while planes < NP:
    R = rng.choice([2, 3, 4, 6, 8, 12])
    c1 = [rng.randint(-R, R) for _ in range(4)]; c2 = [rng.randint(-R, R) for _ in range(4)]
    v1 = [sum(c1[j] * K4[j][c] for j in range(4)) for c in range(5)]
    v2 = [sum(c2[j] * K4[j][c] for j in range(4)) for c in range(5)]
    if gram2(v1, v2) == 0: continue
    p, q = kernel_rows(kernel_rows([v1, v2]))           # saturated plane = (span ∩ Z^5)
    p, q = reduce2(list(p), list(q)); G = gram2(p, q)
    assert dot(p, z1) == 0 and dot(q, z1) == 0
    if G > 4630: continue
    if (dot(p, p) + dot(q, q)) * 728 < 21609: continue   # no (a,b) with D <= 728 can reach |U|^2 >= 21609
    polys = polygons(p, q); planes += 1; npoly.append(len(polys)); dets.append(G)
    for a in range(0, 27):
        for b in range(-26, 27):
            if a == 0 and b <= 0: continue
            if a * a + b * b > 728 or gcd(a, b) != 1: continue
            U = [a * x + b * y for x, y in zip(p, q)]
            if dot(U, U) < 21609 or any(u == 0 for u in U): continue
            tot += 1; g, al, be = egcd(a, b); found = None; wide = False; bw = F(-1)
            for k, P in polys:
                hs = [b * x - a * y for x, y in P]; m = min(hs); M = max(hs); bw = max(bw, M - m)
                if M - m >= 1: wide = True
                if found is None and ceil(m) <= M:
                    Xm = P[hs.index(m)]; Xp = P[hs.index(M)]
                    X = Xm if m == M else tuple(Xm[i] + (ceil(m) - m) / (M - m) * (Xp[i] - Xm[i]) for i in range(2))
                    found = (al * X[0] + be * X[1]) % 1
            if found is None:
                miss += 1; print("MISS", p, q, a, b, U, "safe set nonempty:", bool(safe_set(U)))
            else:
                assert is_safe(U, found); hit += 1; width_only += wide
            worst.append((bw, U, p, q, a, b)); worst.sort(key=lambda r: r[0]); worst = worst[:5]
print("smallest best-polygon h-range (max_P (M_P - m_P)) over all inputs:", [(str(w[0]), w[1], w[4], w[5]) for w in worst])
print("planes %d (Gram det %d..%d, polygons per plane %d..%d) ; inputs (a,b) %d ; rule hits %d, misses %d ; all returned t exactly safe ; covered by the width test alone %d (%.1f%%) ; %.0f s"
      % (planes, min(dets), max(dets), min(npoly), max(npoly), tot, hit, miss, width_only, 100 * width_only / max(tot, 1), time.time() - t0))
