# A20: direct readout of the N = 6 rank-1 exceptions by the bad-residue rules (TEST of coverage; each output time is proved safe by Lemma BR).
import json, sys
from fractions import Fraction as F
from math import gcd
from br20 import br_select, mc_select, kq
from a02_lib import safe
N = 6
rows = json.load(open(sys.argv[1])); Us = [r[0] for r in rows if len(r[2]) == 1]
print("%s: %d top-level rank-1 exceptions" % (sys.argv[1], len(Us)))
# (1) C34's denominator-9 rule
c9 = [U for U in Us if mc_select(U, 9, N) is not None]
print("(1) C34 q = 9 rule (missing class in {1,2,4}, no multiple of 9): covers %d" % len(c9))
# (2) each q in 7..18 alone
for q in range(N + 1, 3 * N + 1):
    cov = [U for U in Us if br_select(U, q, N) is not None]
    print("    q = %2d (k = %d): covers %2d / %d" % (q, kq(q, N), len(cov), len(Us)))
# (3) first q in increasing order (band k = 1 by the missing-class rule, band k = 2 by the forbidden set)
first = {}; unc = []; outs = []
for U in Us:
    hit = None
    for q in range(N + 1, 3 * N + 1):
        t = mc_select(U, q, N) if kq(q, N) == 1 else br_select(U, q, N)
        if t is not None: hit = (q, t); break
    if hit is None: unc.append(U)
    else:
        first[hit[0]] = first.get(hit[0], 0) + 1; assert safe(U, N, hit[1]); outs.append((U, hit[1]))
print("(3) increasing q = 7..18: covered %d / %d ; first q histogram %s ; uncovered: %s" % (len(Us) - len(unc), len(Us), dict(sorted(first.items())), unc))
band1 = [U for U in Us if any(mc_select(U, q, N) for q in range(N + 1, 2 * N + 1))]
print("(4) band k = 1 only (q = 7..12, missing-class rule): covers %d / %d ; not covered by band 1: %s" % (len(band1), len(Us), [U for U in Us if U not in band1]))
for U, t in outs: print("      %-22s -> t = %s" % (tuple(U), t))
