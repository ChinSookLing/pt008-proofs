# A20: union of all N = 6 rank-1 exceptions found (box [1,48] + rank-2 family searches) and the residue-rule readout of each.
import json
from br20 import mc_select, br_select, kq
from bd19 import F19
from a02_lib import safe
N = 6; S = set()
for U, st, src in json.load(open("scan20_N6_X48_FAREY.json")): S.add(tuple(U))
for f in ("family20_R25.json", "family20_R60.json", "family20_r2_R30.json"):
    for U in json.load(open(f)): S.add(tuple(U))
S = sorted(S); hist = {}; band2 = []; q9 = 0; rows = []
for U in S:
    st, t, tr = F19(N, list(U)); assert st == "UNFINISHED" and tr["kind"] == "TOP-RANK1"
    q9 += mc_select(U, 9, N) is not None
    hit = None
    for q in range(N + 1, 3 * N + 1):
        tt = mc_select(U, q, N) if kq(q, N) == 1 else br_select(U, q, N)
        if tt is not None: hit = (q, tt); break
    assert hit and safe(list(U), N, hit[1]); hist[hit[0]] = hist.get(hit[0], 0) + 1
    if hit[0] > 2 * N: band2.append((U, hit[1]))
    rows.append((U, str(hit[1])))
print("distinct N=6 rank-1 exceptions found: %d (all TOP-RANK1, rechecked) ; max entry %d" % (len(S), max(max(U) for U in S)))
print("C34 q=9 rule covers %d ; H6 (q = 7..12 missing-class, then q = 13..18 forbidden set) covers %d ; first-q histogram %s" % (q9, len(rows), dict(sorted(hist.items()))))
print("needing band k = 2 (q > 12): %s" % band2)
json.dump(rows, open("union20.json", "w"))
