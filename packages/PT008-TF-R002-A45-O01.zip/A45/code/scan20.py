# A18 scan (TEST): all primitive sets U of distinct positive integers, m = 1..N-1 elements, max <= X, run the FIXED rule BD-v18.
# Report: outcome counts, which gate/level finished, every UNFINISHED input (with source of the exception).
import sys, itertools, time, json
from math import gcd
from multiprocessing import Pool
import bd19 as bd18
from bd19 import F18
from a02_lib import safe
N = int(sys.argv[1]); X = int(sys.argv[2]); mode = sys.argv[3] if len(sys.argv) > 3 else "FAREY"
bd18.FAREY = (mode == "FAREY"); bd18.TIGHT_ONLY = (mode == "TIGHT")
def job(U):
    st, t, tr = F18(N, list(U))
    if st == "SAFE": assert safe(list(U), N, t)
    end = tr["end"]; key = end.split(" (")[0] if end.startswith("ACCEPT") else end.split(" ")[0] + " " + end.split(" ")[1] if end.startswith("G1") else end[:10]
    src = None
    if st == "UNFINISHED":
        # walk to the innermost exception
        cur = tr; path = []
        while True:
            path.append((cur["N"], tuple(cur["U"]), len(cur["levels"])))
            if "exception" in cur: break
            cur = cur["levels"][-1]["inner"]
        src = path
    return U, st, key, src
def gen():
    for m in range(1, N):
        for U in itertools.combinations(range(1, X + 1), m):
            g = 0
            for u in U: g = gcd(g, u)
            if g == 1: yield U
if __name__ == "__main__":
    t0 = time.time(); cnt = {}; unf = []
    with Pool(2) as p:
        for U, st, key, src in p.imap_unordered(job, gen(), chunksize=200):
            cnt[(st, key)] = cnt.get((st, key), 0) + 1
            if st != "SAFE": unf.append((U, st, src))
    tot = sum(cnt.values())
    print("N=%d X=%d mode=%s: %d primitive sets (m=1..%d); %.0fs" % (N, X, mode, tot, N - 1, time.time() - t0))
    for k in sorted(cnt): print("   %-12s %-28s %d" % (k[0], k[1], cnt[k]))
    unf.sort()
    print("   UNFINISHED / NOSOL inputs: %d" % len(unf))
    for U, st, src in unf: print("     %s %s  source chain (N, U, levels done): %s" % (U, st, src))
    json.dump([[list(U), st, [[a, list(b), c] for a, b, c in src] if src else None] for U, st, src in unf], open("scan20_N%d_X%d_%s.json" % (N, X, mode), "w"))
