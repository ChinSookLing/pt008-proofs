# A28: union of the A27 prefix exclusion E1P and the A28 z1 exclusion ER1 over region R1 (12 < |z1|^2 <= 135/4), exact counts.
import sys, time
sys.argv = ["e1pref27.py", "NONE"]
exec(open("e1pref27.py").read().split("t0 = time.time()")[0])          # class25 import, right_inverse, lag_min (unchanged A27 code)
src = open("er1_28.py").read(); exec(src[src.index("def row_ok"):src.index("t0 = time.time()")])   # row_ok, er1 (unchanged A28 code)
t0 = time.time(); tot = a = b = ab = 0
Z1 = [z for z in C.prim_np(5, F(135, 4)).tolist() if C.suffix_mixed(z) and dot(z, z) > 12]
for z1 in Z1:
    Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, F(7 * m4) / (4 * e4 * e4)); Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    if not len(Z2): continue
    K, R = right_inverse(z1); bad = dot(z1, z1) > 8 * lag_min(z1, Z2 @ R.T); n = len(Z2); ne = int(bad.sum())
    tot += n; a += ne
    if er1(z1): b += n; ab += ne
print("R1 prefixes %d ; E1P %d ; ER1 %d ; both %d ; union %d (%.3f%%) ; %.0f s" % (tot, a, b, ab, a + b - ab, 100 * (a + b - ab) / tot, time.time() - t0))
