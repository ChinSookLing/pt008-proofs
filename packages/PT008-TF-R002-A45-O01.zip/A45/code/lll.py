from fractions import Fraction as F
def lll(B, delta=F(3, 4)):
    B = [list(r) for r in B]; n = len(B)
    def dot(a, b): return sum(x * y for x, y in zip(a, b))
    def gso():
        Bs, mu = [], [[F(0)] * n for _ in range(n)]
        for i in range(n):
            v = [F(x) for x in B[i]]
            for j in range(i):
                mu[i][j] = dot(B[i], Bs[j]) / dot(Bs[j], Bs[j]); v = [a - mu[i][j] * b for a, b in zip(v, Bs[j])]
            Bs.append(v)
        return Bs, mu
    Bs, mu = gso(); k = 1
    while k < n:
        for j in range(k - 1, -1, -1):
            q = round(mu[k][j])
            if q: B[k] = [a - q * b for a, b in zip(B[k], B[j])]; Bs, mu = gso()
        if dot(Bs[k], Bs[k]) >= (delta - mu[k][k - 1] ** 2) * dot(Bs[k - 1], Bs[k - 1]): k += 1
        else: B[k], B[k - 1] = B[k - 1], B[k]; Bs, mu = gso(); k = max(k - 1, 1)
    return B
def relations(V):
    """LLL-reduced basis of Rel(V) = {h in Z^m : h.V = 0} (rank m-1)."""
    m = len(V); C = 10 ** 6 * (1 + max(abs(v) for v in V)) ** 2
    rows = lll([[int(i == j) for j in range(m)] + [C * V[i]] for i in range(m)])
    return [r[:m] for r in rows if r[m] == 0]
