# A06 Tasks 2-3 (exact).  Explicit multi-constraint mechanisms.
#  next_safe(w,t): least x >= t with ||w x|| >= 1/N.   Chase: t <- max_w next_safe(w,t) until fixed  => min S(V) intersect [t0,1).
#  REC(order): I=[0,1]; for each speed choose the w-safe arc with longest intersection with I (tie: leftmost); output left endpoint.
import sys, itertools
from fractions import Fraction as F
from math import floor, gcd
from a02_lib import safe, classify
from anchors import prep, components
def next_safe(w, t, N):
    x = w * t; fl = floor(x); fr = x - fl
    if F(1, N) <= fr <= 1 - F(1, N): return t
    if fr < F(1, N): return (fl + F(1, N)) / w
    return (fl + 1 + F(1, N)) / w
def chase(V, N, t0=F(0), cap=10 ** 6):
    t = t0; it = 0
    while it < cap:
        nt = max(next_safe(w, t, N) for w in V)
        if nt == t: return t, it
        t = nt; it += 1
        if t >= 1: return None, it
    return None, it
def rec(order, N):
    A, B = F(0), F(1)
    for w in order:
        a = (1 - F(2, N)) / w; best = None
        k0 = floor(w * A)
        for k in range(k0 - 1, k0 + 3):                      # arcs near A
            lo, hi = (k + F(1, N)) / w, (k + 1 - F(1, N)) / w
            L, H = max(lo, A), min(hi, B)
            if L <= H and (best is None or H - L > best[1] - best[0]): best = (L, H)
        if B - A >= 2 / F(w):                                # interval contains a full safe arc of w: take the leftmost full one
            k = floor(w * A - F(1, N)) + 1
            lo, hi = (k + F(1, N)) / w, (k + 1 - F(1, N)) / w
            if lo >= A and hi <= B and (best is None or hi - lo >= best[1] - best[0]): best = (lo, hi)
        if best is None: return None
        A, B = best
    return A
if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "stress":
        import e6_theorem as E6
        rows = [("A1", 6, (1, 2, 3, 4, 5)), ("A2", 6, (1, 3, 4, 5, 9)), ("E1", 6, (1, 2, 4, 5, 6)), ("E2", 6, (1, 15, 16, 17, 18)), ("E3 Q0=8", 5, (840, 1, 2, 7)),
                ("E4 K=3", 6, (1, 2, 5, 17051051017003, 10030030010004))]
        mins = [(5, (1, 3, 4, 5)), (5, (2, 3, 4, 5)), (6, (1, 2, 4, 5, 6)), (6, (1, 3, 4, 5, 6)), (6, (2, 3, 4, 5, 6)), (7, (1, 2, 4, 5, 6, 7)), (7, (1, 3, 4, 5, 6, 7)),
                (7, (2, 3, 4, 5, 6, 7)), (8, (1, 2, 3, 5, 6, 7, 8)), (8, (1, 2, 4, 5, 6, 7, 8)), (8, (1, 3, 4, 5, 6, 7, 8)), (8, (2, 3, 4, 5, 6, 7, 8))]
        rows += [("min", N, V) for N, V in mins]
        for c, P, l in ((1, [2, 3, 5], 7), (3, [2, 3, 5, 7], 11), (6, [2, 3, 5], 7)):
            V, K, Q, PP = E6.build(c, P, l); rows.append(("E6' c=%d" % c, 6, tuple(V)))
        for nm, N, V in rows:
            V = prep(V); t, it = chase(V, N)
            ra = rec(V, N); rd = rec(V[::-1], N)
            ok_any = None
            if len(V) <= 7:
                ok_any = sum(1 for o in itertools.permutations(V) if rec(o, N) is not None)
            print("%-9s N=%d %s | chase: t_min=%s (%d iterations, safe=%s) | REC ascending: %s | REC descending: %s | REC orders succeeding: %s/%s"
                  % (nm, N, classify(V, N)[0], t, it, t is not None and safe(V, N, t), ra, rd, ok_any, (len(list(itertools.permutations(V))) if len(V) <= 7 else "-")), flush=True)
    if mode == "box":
        for N, X in ((5, 30), (6, 20), (7, 13)):
            tot = asc = anyo = 0; maxit = (0, None); hist = {}; fails = []
            for U in itertools.combinations(range(1, X + 1), N - 1):
                g = 0
                for u in U: g = gcd(g, u)
                if g != 1 or classify(U, N)[0] not in ("K3A", "K3B"): continue
                tot += 1; V = list(U)
                t, it = chase(V, N); assert t is not None and safe(V, N, t)
                hist[it] = hist.get(it, 0) + 1
                if it > maxit[0]: maxit = (it, U)
                a = rec(V, N) is not None; asc += a
                o = a or any(rec(p, N) is not None for p in itertools.permutations(V))
                anyo += o
                if not o and len(fails) < 3: fails.append(U)
            print("box N=%d X=%d: K3 %d | chase from 0 always reaches min S: yes; iteration histogram %s; max %s | REC ascending succeeds %d | REC some order %d | REC fails for every order e.g. %s"
                  % (N, X, tot, dict(sorted(hist.items())), maxit, asc, anyo, fails), flush=True)
