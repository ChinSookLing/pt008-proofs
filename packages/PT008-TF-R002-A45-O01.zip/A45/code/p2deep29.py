# A29 (TEST): Lemmas P and P2 (C52 formula for the penultimate Babai coefficient) on every level of real BD-v19 runs, exact.
import json, random, sys
from fractions import Fraction as F
import bd19
from dual29 import level1_dual
rng = random.Random(29); Us = [list(r[0]) for r in json.load(open("union20.json"))]
for H in (30, 60, 120, 250, 500, 1000): Us += [sorted(rng.sample(range(1, H), 5)) for _ in range(int(sys.argv[1]))]
bd19.TOPGATE = False; nlev = 0; nP2 = 0; byd = {}
for U in Us:
    st, t, tr = bd19.F19(6, U); m = len(tr["U"])
    for lv in tr["levels"]:
        if "eta" not in lv: break
        Lb = lv["basis"]; d = lv["d"]; M = [[Lb[j][i] for j in range(d)] for i in range(m)]
        ys = [F(1, 2)] * d if lv["target"] == "1/2" else [lv["target"]["t*"] * c for c in lv["target"]["u"]]
        D = level1_dual(lv["w"], 6, ys, M); nlev += 1; assert D["fail"] == ("z" in lv)
        if "z" in lv: assert D["z"] == lv["z"]
        if "q" in D: nP2 += 1; byd[d] = byd.get(d, 0) + 1
bd19.TOPGATE = True
print("runs %d ; levels replayed %d (fail flag and z identical to the trace) ; levels with n >= 2 where Lemmas P and P2 were asserted: %d, by d: %s ; violations 0" % (len(Us), nlev, nP2, byd))
