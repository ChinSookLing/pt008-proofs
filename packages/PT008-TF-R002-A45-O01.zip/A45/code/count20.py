# A20 N = 6, m = 5: chain counts for a BD-v19 certificate.  Exact counts at levels 1 and 2 (DESC' bounds + cone pruning CN1/CN2 generalised to R^4);
# level 3 and the rank-2 leaves are ESTIMATED by uniform sampling of the level-2 survivors (reservoir sampling, so each survivor is equally likely).
import itertools, random, time, sys
import numpy as np
from fractions import Fraction as F
from math import gcd, isqrt
from bd19 import F18, relations18, dot
import dclose
from a02_lib import dist
from cone19 import suffix_mixed, diffrows
N = 6; m = 5
def coinc(M):
    u, s, _ = dclose.coincidence_line(M); sd = sorted({abs(x) for x in s}); st, ts, _ = F18(len(sd) + 1, sd); assert st == "SAFE", (st, sd)
    ys = [ts * c for c in u]; eta = min(dist(dot(Mi, ys)) for Mi in M) - F(1, N); return ys, eta, max(dot(r, r) for r in M)
def sub(Lb, z):
    K = relations18(z); d = len(Lb); return [[sum(c[j] * Lb[j][i] for j in range(d)) for i in range(m)] for c in K]
def kernel_vec(rows):                      # rows: (d-1) x d integer, rank d-1 -> integer kernel vector by cofactors
    d = len(rows[0]); A = np.array(rows, dtype=object); v = []
    for j in range(d):
        minor = [[A[i][c] for c in range(d) if c != j] for i in range(d - 1)]
        v.append((-1) ** j * det(minor))
    return v
def det(M):
    n = len(M)
    if n == 1: return M[0][0]
    if n == 2: return M[0][0] * M[1][1] - M[0][1] * M[1][0]
    return sum((-1) ** c * M[0][c] * det([r[:c] + r[c + 1:] for r in M[1:]]) for c in range(n))
def rays(A):
    d = len(A[0]); R = []
    for idx in itertools.combinations(range(len(A)), d - 1):
        r = kernel_vec([A[i] for i in idx])
        if not any(r): continue
        for sg in (1, -1):
            rr = [sg * x for x in r]
            if all(dot(a, rr) >= 0 for a in A) and rr not in R: R.append(rr)
    return R
def prim_np(d, R2):
    """primitive integer vectors with |z|^2 <= R2, first nonzero coordinate positive; built slice by slice in the first coordinate (memory)."""
    r = isqrt(int(R2)); ax = np.arange(-r, r + 1); out = []
    for x0 in range(0, r + 1):
        rest2 = int(R2) - x0 * x0
        if rest2 < 0: break
        rr = isqrt(rest2); bx = np.arange(-rr, rr + 1)
        G = np.stack(np.meshgrid(*([bx] * (d - 1)), indexing="ij"), -1).reshape(-1, d - 1)
        G = G[(G * G).sum(1) <= rest2]
        G = np.concatenate([np.full((len(G), 1), x0), G], 1)
        if x0 == 0:
            G = G[np.any(G != 0, 1)]
            first = G[np.arange(len(G)), np.argmax(G != 0, 1)]; G = G[first > 0]
        g = np.gcd.reduce(np.abs(G), axis=1); out.append(G[g == 1])
    return np.concatenate(out) if out else np.zeros((0, d), dtype=np.int64)
def cone_ok(Z, R):
    V = Z @ np.array(R, dtype=np.int64).T
    return (V.max(1) > 0) & (V.min(1) < 0)
rng = random.Random(20); t0 = time.time()
I = [[int(i == j) for j in range(m)] for i in range(m)]
R1 = F(1 * (2 ** 4 - 1)) / (4 * (F(1, 2) - F(1, N)) ** 2)
Z1 = [z for z in prim_np(5, R1).tolist()]; Z1c = [z for z in Z1 if suffix_mixed(z)]
print("level 1: |z1|^2 <= %s : %d relations ; cone-admissible (CN1): %d" % (R1, len(Z1), len(Z1c)), flush=True)
tot2 = tot2c = 0; percount = []
for z1 in Z1c:
    Lb = sub(I, z1); M = [[Lb[j][i] for j in range(4)] for i in range(m)]
    if any(not any(r) for r in M): continue
    ys, eta, mu2 = coinc(M); R2 = F(7 * mu2) / (4 * eta * eta)
    Z2 = prim_np(4, R2); ok = cone_ok(Z2, rays(diffrows(M))); tot2 += len(Z2); c = int(ok.sum()); tot2c += c
    percount.append((z1, c))
print("level 2: DESC' |z2|^2 <= 7 mu^2/(4 eta^2): %d relations ; cone-admissible (CN2 in R^4): %d  (%.0fs)" % (tot2, tot2c, time.time() - t0), flush=True)
import pickle; pickle.dump((tot2, tot2c, percount), open("count20_level2.pkl", "wb"))
# uniform sample of level-2 survivors: node with probability proportional to its survivor count, then uniform inside the node
K = 300; res = []; W = [c for _, c in percount]
for z1, _ in rng.choices(percount, weights=W, k=K):
    Lb = sub(I, z1); M = [[Lb[j][i] for j in range(4)] for i in range(m)]
    ys, eta, mu2 = coinc(M); Z2 = prim_np(4, F(7 * mu2) / (4 * eta * eta)); S2 = Z2[cone_ok(Z2, rays(diffrows(M)))]
    res.append((z1, S2[rng.randrange(len(S2))].tolist()))
# level 3 (d = 3) and rank-2 leaves: ESTIMATES.  Exact enumeration when the radius is small; otherwise primitive-count asymptotics times a Monte Carlo cone fraction.
import math
ZETA3 = 1.2020569031595942
def count3(M, R3):
    R = rays(diffrows(M)); r = isqrt(int(R3))
    if r <= 40:
        Z3 = prim_np(3, R3); ok = cone_ok(Z3, R); return len(Z3), int(ok.sum()), Z3[ok]
    tot = 4 / 3 * math.pi * float(R3) ** 1.5 / ZETA3 / 2
    P = np.random.default_rng(1).normal(size=(20000, 3)); P = P / np.linalg.norm(P, axis=1)[:, None]
    V = P @ np.array(R, dtype=float).T; frac = float(((V.max(1) > 0) & (V.min(1) < 0)).mean())
    return tot, tot * frac, None
c3 = []; c3c = []; leaf = []
for z1, z2 in res:
    Lb = sub(sub(I, z1), z2); M = [[Lb[j][i] for j in range(3)] for i in range(m)]
    if any(not any(r) for r in M): c3.append(0); c3c.append(0); continue
    ys, eta, mu2 = coinc(M); R3 = F(3 * mu2) / (4 * eta * eta)
    a, b, surv = count3(M, R3); c3.append(a); c3c.append(b)
    if surv is not None and len(surv):
        z3 = surv[rng.randrange(len(surv))].tolist(); Lb2 = sub(Lb, z3); M2 = [[Lb2[j][i] for j in range(2)] for i in range(m)]
        if not any(not any(r) for r in M2):
            ys2, eta2, mu22 = coinc(M2); Dmax = float(mu22 / (4 * eta2 * eta2)); A2 = diffrows(M2)
            ang = [math.atan2(-a_[0], a_[1]) for a_ in A2]          # sector = intersection of half-planes a.w > 0 ; estimate its angle numerically
            th = np.linspace(0, 2 * math.pi, 20001)[:-1]; W = np.stack([np.cos(th), np.sin(th)], 1)
            fr = float(np.all(W @ np.array(A2, dtype=float).T > 0, axis=1).mean())
            leaf.append(6 / math.pi ** 2 * math.pi * Dmax * fr)
mean3 = sum(c3c) / len(c3c)
print("level 3 (%d uniformly sampled level-2 survivors): mean relations %.3g, mean cone-admissible %.3g -> estimated level-3 survivors %.2e" % (len(res), sum(c3) / len(c3), mean3, mean3 * tot2c), flush=True)
if leaf:
    ml = sum(leaf) / len(leaf)
    print("rank-2 nodes (%d sampled): mean primitive in-sector w with D <= mu^2/(4 eta^2) ~ %.3g -> rough leaf estimate %.2e before the delta, K1 and exact filters  (%.0fs)" % (len(leaf), ml, ml * mean3 * tot2c, time.time() - t0), flush=True)
