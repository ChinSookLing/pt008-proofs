# A29 (TEST of Lemmas P, P2, DE on every listed run; exact statistics of the link Q = Q_chain on real two-level descents).
import json, sys, glob, random
from collections import Counter
import bd19
from bd19 import dot
from dual29 import level1_dual, preimage
src = sys.argv[1]
if src == "exh":
    Us = []
    for f in sorted(glob.glob("exhlist29_*.json")): Us += json.load(open(f))["fail"]
elif src == "known":
    Us = [list(r[0]) for r in json.load(open("union20.json"))]
else:                                    # random, G1 off at the top so the lattice part runs
    rng = random.Random(int(sys.argv[2])); Us = []
    for H in (30, 60, 120, 250, 500, 1000): Us += [sorted(rng.sample(range(1, H), 5)) for _ in range(int(sys.argv[3]))]
    bd19.TOPGATE = False
stats = Counter(); tab = Counter(); ex = {}; grp = {}
for U in Us:
    D = level1_dual(U); stats["runs"] += 1; stats["P2 checked"] += 1
    if not D["fail"]: continue
    stats["level-1 failures"] += 1; stats["DE (Q double-even)"] += D["de"]
    if D["de"]: assert D["zz"] < 27
    st, t, tr = bd19.F19(6, U); L = tr["levels"]; assert L[0]["z"] == D["z"]
    if len(L) < 2 or "z" not in L[1]: stats["level 2 accepts"] += 1; continue
    stats["two-level descents"] += 1
    Lb4 = L[1]["basis"]; z1 = D["z"]; z2 = L[1]["z"]; x2 = preimage(Lb4, z1, z2)
    Lq = [dot(r, D["q"]) for r in Lb4]; link = Lq == z2 or Lq == [-v for v in z2]
    z1even = sum(z1) % 2 == 0; cde = z1even and sum(x2) % 2 == 0
    stats["link Q = Q_chain"] += link
    key = ("z1 even" if z1even else "z1 odd", "link" if link else "no link", "Q-DE" if D["de"] else "-", "chain-DE" if cde else "-"); tab[key] += 1
    if key not in ex: ex[key] = (U, z1, D["q"], z2, Lq, x2, st)
    g = grp.setdefault((tuple(z1), tuple(z2)), {}); g.setdefault((D["de"], tuple(min(Lq, [-v for v in Lq]))), []).append(U)
bd19.TOPGATE = True
print("source %s: %s" % (src, dict(stats)))
for k, v in sorted(tab.items()): print("   %-60s %6d   e.g. U=%s z1=%s q=%s z2=%s Lb4.q=%s x2=%s %s" % (str(k), v, *ex[k]))
var = {k: v for k, v in grp.items() if len(v) > 1}; varde = {k: v for k, v in grp.items() if len({a for a, b in v}) > 1}
print("   prefixes (z1, z2) met: %d ; with more than one level-1 dual pair class (Lb4.q up to sign): %d ; with both Q-DE and non-Q-DE leaves: %d" % (len(grp), len(var), len(varde)))
for k, v in list(var.items())[:2]: print("      prefix z1=%s z2=%s : %s" % (list(k[0]), list(k[1]), {str(a): b[:2] for a, b in v.items()}))
for k, v in list(varde.items())[:2]: print("      DE varies: prefix z1=%s z2=%s : %s" % (list(k[0]), list(k[1]), {str(a): b[:2] for a, b in v.items()}))
