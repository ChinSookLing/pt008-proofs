# A21 cross-check: the class-certificate leaf routine (class21.leaves) on the 42 known rank-2 nodes must reproduce the C35 replay counts.
import json, sys
sys.argv = ["x", "1", "1", "1"]
import class21
from class21 import leaves
from bd19 import F19
nodes = {}
for U, _ in json.load(open("union20.json")):
    st, _, tr = F19(6, U); last = tr["levels"][-1]
    B = tuple(map(tuple, last["basis"])); Y = [c * last["target"]["t*"] for c in last["target"]["u"]]
    nodes[B] = (Y, last["eta"], last["mu2"])
st = {k: 0 for k in ("in_sector", "K1_miss", "rank2_fails", "H6_miss", "known_hit", "node_closed_sector", "node_closed_K1", "node_closed_rank2", "node_closed_H6", "node_closed_replay")}
cex = []
for B, (Y, eta, mu2) in nodes.items():
    M2 = [[B[j][i] for j in range(2)] for i in range(5)]
    cex += leaves(M2, Y, eta, mu2, st)
print("42-node cross-check: nodes %d ; in_sector %d (C35: 6680) ; K1_miss %d (C35: 2191) ; rank2_fails %d (C35: 235) ; H6_miss %d (C35: 0) ; counterexamples %d"
      % (len(nodes), st["in_sector"], st["K1_miss"], st["rank2_fails"], st["H6_miss"], len(cex)))
