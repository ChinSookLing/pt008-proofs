# A27 exploration (TEST): how often is a rank-2-failing, K1-failing leaf a true TOP-RANK1 input, and how does H6 cover those?
import sys, random, json, time
sys.argv = ["x", "-1", "9", "-1", "10", "-1", "53", "cert"]
import class25 as C
import numpy as np
from fractions import Fraction as F
from math import gcd, lcm
from collections import Counter
from bd19 import F19
from br20 import mc_select, br_select, kq
rng = random.Random(27)
Z1 = [z for z in C.prim_np(5, F(9)).tolist() if C.suffix_mixed(z)]
def h6first(U):
    for q in range(7, 19):
        t = mc_select(U, q, 6) if kq(q, 6) == 1 else br_select(U, q, 6)
        if t is not None: return q, t
    return None
def rank2_fail_leaves(M2, ys, eta, mu2):
    H = lcm(ys[0].denominator, ys[1].denominator); Y = [int(y * H) for y in ys]
    P, Q = C.sector_disk_rows(C.diffrows(M2), int(mu2 / (4 * eta * eta)))
    k = np.gcd(P, Q) == 1; P, Q = P[k], Q[k]; Mn = np.array(M2, dtype=np.int64); U = (Mn @ np.stack([P, Q])).T
    k1 = np.any(U % 4 == 0, 1) & np.any(U % 5 == 0, 1) & np.any(U % 6 == 0, 1); P, Q, U = P[k1], Q[k1], U[k1]
    D = P * P + Q * Q; Zn = -Q * Y[0] + P * Y[1]; r0 = np.floor_divide(Zn, H); rem = Zn - H * r0
    dH = Zn - H * (r0 + (2 * rem > H) + ((2 * rem == H) & (r0 % 2 != 0))); nz = dH != 0; P, Q, D, U, dH = P[nz], Q[nz], D[nz], U[nz], dH[nz]
    fail = np.zeros(len(P), dtype=bool)
    for i in range(5):
        c = -Mn[i, 0] * Q + Mn[i, 1] * P; MY = int(Mn[i, 0]) * Y[0] + int(Mn[i, 1]) * Y[1]
        num = D * MY - dH * c; den = H * D; s = np.mod(num, den); fail |= 6 * np.minimum(s, den - s) < den
    return [tuple(u) for u in U[fail].tolist()], [(p, q) for p, q in zip(P[fail].tolist(), Q[fail].tolist())]
t0 = time.time(); nodes = 0; leaves = 0; top = {}; other = Counter()
while time.time() - t0 < float(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].replace('.', '').isdigit() else time.time() - t0 < 300:
    z1 = rng.choice(Z1); Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, min(F(10), F(7 * m4) / (4 * e4 * e4))); Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    if not len(Z2): continue
    z2 = Z2[rng.randrange(len(Z2))].tolist(); Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3)
    if any(not any(r) for r in M3): continue
    y3, e3, m3 = C.coinc(M3); Z3 = C.prim_np(3, min(F(53), F(3 * m3) / (4 * e3 * e3))); Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
    if not len(Z3): continue
    z3 = Z3[rng.randrange(len(Z3))].tolist(); M2 = C.forms(C.sub(Lb3, z3))
    if any(not any(r) for r in M2): continue
    ys, eta, mu2 = C.coinc(M2); nodes += 1
    Us, ws = rank2_fail_leaves(M2, ys, eta, mu2)
    for U, w in zip(Us, ws):
        leaves += 1; st, t, tr = F19(6, list(U))
        if st == "UNFINISHED":
            zs = [lv["z"] for lv in tr["levels"]]; same = (zs[0] in (z1, [-x for x in z1]))
            top[U] = (h6first(list(U)), [sum(x * x for x in z) for z in zs[:3]], str(ys), str(eta))
        else: other[tr["end"][:16]] += 1
print("sampled rank-2 nodes %d (uniform z1 <= 9, then random z2 <= 10, z3 <= 53) ; rank-2-failing K1-failing leaves replayed %d ; outcomes %s ; TOP-RANK1 distinct %d"
      % (nodes, leaves, dict(other), len(top)))
print("H6 first q among TOP-RANK1:", Counter(v[0][0] if v[0] else None for v in top.values()))
json.dump([[list(k), v[0][0] if v[0] else None, str(v[0][1]) if v[0] else None, v[1], v[2], v[3]] for k, v in top.items()], open("explore27_top.json", "w"))
