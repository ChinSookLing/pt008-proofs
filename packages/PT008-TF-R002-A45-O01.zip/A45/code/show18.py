# A18 trace printer for F18 runs (shared by example18.py and exc18.py).
import sys, itertools
from fractions import Fraction as F
from math import gcd
import bd18
from bd18 import F18, relations18, dot
from a02_lib import dist, safe
def show(tr, ind=""):
    print(ind + "F(N=%d, V=%s)   [recursion depth %d]" % (tr["N"], tr["V"], tr["depth"]))
    if "U" in tr: print(ind + "  G0: sorted distinct |v| -> g = %d, U = %s" % (tr["g"], tr["U"]))
    import bd18
    if "U" in tr and not tr["end"].startswith("G1") and not bd18.FAREY: print(ind + "  G1: Farey gate NOT applied (diagnostic mode: tight branch only, U != (1..N-1))")
    if "U" in tr and not tr["end"].startswith("G1") and bd18.FAREY:
        U = tr["U"]; N = tr["N"]; blk = []
        for q in range(2, N + 1):
            for a in range(1, q):
                if gcd(a, q) == 1:
                    bad = [u for u in U if dist(F(u * a, q)) < F(1, N)]
                    blk.append("%d/%d blocked by %s" % (a, q, bad[0]))
        print(ind + "  G1 Farey gate fails: " + "; ".join(blk))
    for k, lv in enumerate(tr["levels"], 1):
        print(ind + "  level %d: rank d=%d, basis of L (rows) %s, coordinates w = %s" % (k, lv["d"], lv["basis"], lv["w"]))
        tg = lv["target"]
        if tg == "1/2": print(ind + "    target y* = (1/2,...,1/2)")
        else:
            print(ind + "    coincidence line u = %s, speeds s = M u = %s -> recursive call F(%d, |s|) returned %s t* = %s ; y* = t* u" % (tg["u"], tg["s"], tg["recursive N"], tg["status"], tg["t*"]))
            if "inner" in lv: show(lv["inner"], ind + "      ")
        if "eta" in lv:
            print(ind + "    eta = %s ; rho^2 = %s ; mu^2 = %s ; strict test rho^2 mu^2 < eta^2: %s" % (lv["eta"], lv["rho2"], lv["mu2"], lv["strict"]))
            print(ind + "    Babai coefficients %s ; point x = %s ; min_i ||M_i x|| = %s (need >= 1/%d)" % (lv["babai_coeffs"], [str(v) for v in lv["x"]], lv["min_dist"], tr["N"]))
        if "accept" in lv: print(ind + "    ACCEPT (%s): gamma = %s (sum gamma_i w_i = 1), s = sum gamma_i x_i mod 1 = %s, t = s/g" % (lv["accept"], lv["gamma"], lv["s"]))
        if "z" in lv: print(ind + "    exact check FAILED -> DESC relation z = %s (|z|^2 = %d <= bound %s); L <- L cap z-perp" % (lv["z"], dot(lv["z"], lv["z"]), lv["z2_bound"]))
    print(ind + "  END: " + tr["end"])
