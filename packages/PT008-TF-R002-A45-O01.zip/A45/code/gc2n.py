# A11.  2GC-N: natural-parameter two-generator closure, with zero-speed rejection (C15 ERR-1) and an independently checkable
# emptiness certificate (C15 ERR-3).  Picture: torus coords (y,x), forms f_m = v_m y + w_m x, time curve t -> (t, 0).
#   For each speed i (v_i != 0) and component k of the boundary line f_i = 1/N (g_i = gcd(v_i,w_i) components):
#   P(tau) = (y0 + w' tau, -v' tau), tau in [0,1), y0 = c_k / v', c_k = (1/N + k)/g_i, (v',w') = (v_i,w_i)/g_i.
#   Other forms along the component: f_m = v_m y0 + tau (v_m w' - w_m v')  (affine; slope = signed determinant / g_i).
#   Curve points on the component: tau = l/|v'|.  In each closed safe arc [tau1,tau2] take l = ceil(tau1 |v'|).
# Correct + complete for every w not making any (v_i, w_i) zero; cost O(sum_i g_i * m + sum |det|), independent of |v|.
from fractions import Fraction as F
from math import gcd, floor, ceil
from a02_lib import safe, dist
from gc2 import arcs_affine
def prepare(V, W):
    """C15 ERR-1: a zero relative speed makes the separation condition fail everywhere -> no safe time.
       Then normalise signs (||-f|| = ||f||) and merge duplicate forms."""
    for i, v in enumerate(V):
        if v == 0: return None, ("ZERO_SPEED", i)
    seen = {}
    for v, w in zip(V, W):
        if v < 0: v, w = -v, -w
        seen.setdefault((v, w), None)
    return list(seen), None
def gc2n(V, W, N, want_cert=True):
    forms, zero = prepare(V, W)
    if zero: return None, 0, {"type": "ZERO_SPEED", "index": zero[1]}
    speeds = sorted({v for v, w in forms})
    cert = {"type": "EMPTY", "N": N, "forms": forms, "lines": []}; work = 0
    for i, (vi, wi) in enumerate(forms):
        g = gcd(vi, wi); vp, wp = vi // g, wi // g
        for k in range(g):
            ck = (F(1, N) + k) / g; y0 = ck / vp
            cs = [(vm * y0, F(vm * wp - wm * vp)) for m, (vm, wm) in enumerate(forms) if m != i]
            arcs = arcs_affine(cs, N); work += 1 + len(arcs); rec = []
            for t1, t2 in arcs:
                l = ceil(t1 * abs(vp)); tau = F(l, abs(vp))
                if tau <= t2:
                    t = (y0 + wp * tau) % 1
                    assert safe(speeds, N, t), (forms, i, k, t1, t2, t)
                    return t, work, {"type": "SAFE", "t": t}
                rec.append((t1, t2, l))
            if want_cert: cert["lines"].append((i, k, rec))
    return None, work, cert
# ---------------- independent checker for EMPTY certificates (different arc algorithm: per-form interval intersection) -------------
def safe_intervals_affine(c, s, N):
    """{tau in [0,1] : ||c + s tau|| >= 1/N} as a sorted list of closed intervals, computed directly (no midpoint sampling)."""
    if s == 0:
        return [(F(0), F(1))] if dist(c) >= F(1, N) else []
    out = []
    lo, hi = sorted((c, c + s)); 
    for k in range(floor(lo) - 1, ceil(hi) + 1):
        a, b = (k + F(1, N) - c) / s, (k + 1 - F(1, N) - c) / s
        a, b = min(a, b), max(a, b); a, b = max(a, F(0)), min(b, F(1))
        if a <= b: out.append((a, b))
    return sorted(out)
def intersect(A, B):
    out, i, j = [], 0, 0
    while i < len(A) and j < len(B):
        a, b = max(A[i][0], B[j][0]), min(A[i][1], B[j][1])
        if a <= b: out.append((a, b))
        if A[i][1] < B[j][1]: i += 1
        else: j += 1
    merged = []
    for a, b in out:
        if merged and a <= merged[-1][1]: merged[-1] = (merged[-1][0], max(b, merged[-1][1]))
        else: merged.append((a, b))
    return merged
def check_empty_cert(V, W, N, cert):
    if cert["type"] == "ZERO_SPEED": return V[cert["index"]] == 0
    forms, zero = prepare(V, W)
    if zero or cert["type"] != "EMPTY" or cert["N"] != N or sorted(cert["forms"]) != sorted(forms): return False
    need = {(i, k) for i, (vi, wi) in enumerate(forms) for k in range(gcd(vi, wi))}
    got = {(i, k) for i, k, rec in cert["lines"]}
    if need != got: return False
    for i, k, rec in cert["lines"]:
        vi, wi = forms[i]; g = gcd(vi, wi); vp, wp = vi // g, wi // g; y0 = ((F(1, N) + k) / g) / vp
        arcs = [(F(0), F(1))]
        for m, (vm, wm) in enumerate(forms):
            if m != i: arcs = intersect(arcs, safe_intervals_affine(vm * y0, F(vm * wp - wm * vp), N))
        if [(a, b) for a, b, l in rec] != arcs: return False
        for a, b, l in rec:
            if l != ceil(a * abs(vp)) or F(l, abs(vp)) <= b: return False
    return True
# ---------------- choosing w: LLL on the wedge form |V ^ w|^2 (exact rationals) ----------------
def lll_short_w(V, delta=F(3, 4)):
    m = len(V); n2 = sum(v * v for v in V)
    G = [[F(n2 * (i == j) - V[i] * V[j]) + F(V[i] * V[j], n2 * n2) for j in range(m)] for i in range(m)]   # wedge form + tiny V-direction penalty
    B = [[int(i == j) for j in range(m)] for i in range(m)]
    def ip(a, b): return sum(a[i] * G[i][j] * b[j] for i in range(m) for j in range(m))
    k = 1
    def gso():
        Bs, mu, nb = [], [[F(0)] * m for _ in range(m)], []
        for i in range(m):
            v = [F(x) for x in B[i]]
            for j in range(i):
                mu[i][j] = ip(B[i], Bs[j]) / nb[j]; v = [v[t] - mu[i][j] * Bs[j][t] for t in range(m)]
            Bs.append(v); nb.append(ip(v, v))
        return Bs, mu, nb
    Bs, mu, nb = gso()
    while k < m:
        for j in range(k - 1, -1, -1):
            q = round(mu[k][j])
            if q: B[k] = [B[k][t] - q * B[j][t] for t in range(m)]; Bs, mu, nb = gso()
        if nb[k] >= (delta - mu[k][k - 1] ** 2) * nb[k - 1]: k += 1
        else: B[k], B[k - 1] = B[k - 1], B[k]; Bs, mu, nb = gso(); k = max(k - 1, 1)
    return B
def gamma(V, w):
    m = len(V)
    return sum(gcd(V[i], w[i]) for i in range(m)) + sum(abs(V[i] * w[j] - V[j] * w[i]) for i in range(m) for j in range(m) if i != j)
def best_w(V):
    cands = [w for w in lll_short_w(V) if any(V[i] * w[j] != V[j] * w[i] for i in range(len(V)) for j in range(len(V)))]
    return min(cands, key=lambda w: gamma(V, w))
