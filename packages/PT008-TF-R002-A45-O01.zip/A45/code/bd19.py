# A19 · BD-v19 = BD-v18 with the C32 kernel scale, the K1 gate by divisibility, typed UNFINISHED, and the exact rank-2 Babai formula cross-check.
# (A18 header follows; differences are listed in A19-O01 §1.)
# A18 · BD-v18: the FIXED evaluation rule t = F(N, V) (Babai descent, verified variant) with explicit outcome states.
#
# OUTCOMES (three, never conflated):
#   ("SAFE", t, trace)        t is a time with ||v_i t|| >= 1/N for all i (checked exactly before returning)
#   ("NOSOL", None, trace)    proved: no safe time exists (only source: a zero speed, Lemma Z)
#   ("UNFINISHED", None, trace)  the rule did not finish: a rank-1 exception (at this level or inside a recursive call) with no table entry.
#                                The trace records WHERE (N, U, recursion depth, chain of relations z) and WHY (exact check failed at every level).
#
# FIXED CONVENTIONS
#   * arithmetic: exact rationals (fractions.Fraction) throughout; no floating point anywhere in the rule.
#   * rounding:   rnd(x) = Python round(Fraction) = nearest integer, ties to EVEN.  Used in LLL size reduction and in Babai.
#   * LLL:        textbook exact LLL, delta = 3/4, size-reduce row k against rows k-1..0 (in that order), Lovasz test, swap, k <- max(k-1,1).
#   * kernel basis of an integer vector w (d coordinates):  LLL of rows (e_i, C*w_i), C = 10^6 (1 + max|w_i|)^2;  keep rows whose last entry is 0.
#                 Guarantee (C28 / C29 item 3): if C^2 > 2^(d-1) |w|_2^2 then the first d-1 LLL rows have length <= 2^((d-1)/2) lambda_{d-1} <= 2^((d-1)/2) |w|_2 < C,
#                 so their last entry is 0, and they form a Z-basis of Rel(w) (the d-th row has nonzero last entry).  Asserted at run time (integer comparison).
#                 Negating w negates the appended column; the Gram matrix is unchanged, so +-w give the SAME kernel basis.
#   * gates (before the lattice part, in this order):
#       G0  zero speed -> NOSOL.   Normalise: S = sorted distinct |v_i|, g = gcd(S), U = S/g.
#       G1  Farey gate of order N: for q = 2..N, for a = 1..q-1 with gcd(a, q) = 1 (increasing a): if ||u a/q|| >= 1/N for all u in U, return a/(q g).
#           (q = N, a = 1 is the tight-family branch: U = {1..N-1} -> 1/(N g).  m = 1 (U = (1)) -> 1/(2g).)  At most N^2/2 candidates, fixed for each N.
#   * lattice part (levels; L = Z^m initially, rank d):
#       F1  basis Lb (rows), forms M (M[i][j] = Lb_j[i]), coordinates w with U = M w (exact solve; w primitive since gcd(U) = 1).
#       F2  target y*:  d = m -> (1/2,...,1/2);  d < m -> A12 coincidence line u, speeds s = M u, distinct |s| (n of them), recursive call F(n+1, s)
#           (strictly smaller N); if that call is not SAFE the outer call returns UNFINISHED with the inner trace attached (source kept).
#           eta = min_i ||M_i y*|| - 1/N  (> 0 by REC).
#       F3  Lambda = dual basis of LLL(Rel(w)), then LLL; Babai nearest plane toward pi_w(y*) -> point x = y* - e (x = tau w mod Z^d).
#           ACCEPT iff  min_i ||M_i x|| >= 1/N  (exact check, equality allowed).  t = (sum gamma_i x_i mod 1) / g,  sum gamma_i w_i = 1.
#           (The strict sufficient condition rho*mu < eta is recorded but is not needed: it implies the exact check.)
#       F4  otherwise rho*mu >= eta necessarily (BAB contrapositive), so DESC applies: z = b*_n / |b*_n|^2 is a primitive integer relation of w
#           with |z| <= mu sqrt(n) 2^((n-1)/2) / (2 eta).  New L = M {a in Z^d : z.a = 0} (kernel basis of z, mapped by the current basis).  Go to F1.
#       F5  d = 1: rank-1 exception.  TABLES[N][U] if present (SAFE), else UNFINISHED.
from fractions import Fraction as F
from math import gcd, isqrt
import lll19 as _lll          # identical output to lll.lll (lll19_check.py), incremental GSO bookkeeping
import dclose
from a02_lib import dist, safe

def dot(a, b): return sum(x * y for x, y in zip(a, b))

def kernel_scale(V):
    """C32: C = max(C18, isqrt(2^(d-1) |w|^2) + 1), C18 = 10^6 (1 + max|w_i|)^2.  Then C > 2^((d-1)/2) |w|_2 always; C = C18 wherever C18 already sufficed."""
    m = len(V); C18 = 10 ** 6 * (1 + max(abs(v) for v in V)) ** 2
    return max(C18, isqrt(2 ** (m - 1) * dot(V, V)) + 1), C18
SCALE_LOG = []                           # (d, C18 sufficient?) for the regression
def relations18(V):
    m = len(V); C, C18 = kernel_scale(V)
    if C != C18: SCALE_LOG.append((m, max(abs(v) for v in V)))
    assert C * C > 2 ** (m - 1) * dot(V, V)
    rows = _lll.lll([[int(i == j) for j in range(m)] + [C * V[i]] for i in range(m)])
    K = [r[:m] for r in rows if r[m] == 0]
    assert len(K) == m - 1 and all(r[m] == 0 for r in rows[:m - 1]) and rows[m - 1][m] != 0
    return K
dclose.relations = relations18          # coincidence lines use the same checked kernel routine

TABLES = None                            # {N: {U(tuple): Fraction}}  finite certified exception tables
TOPGATE = True                           # diagnostics only: False skips G1 at depth 0 (recursive calls keep it)
FAREY = True                             # G1 on/off (off only for diagnostics comparing with the A17 rule)
TIGHT_ONLY = False                       # diagnostics: replace G1 by the tight branch U == (1..N-1) only

def egcd(a, b):
    if b == 0: return (1 if a >= 0 else -1), 0, abs(a)
    x, y, g = egcd(b, a % b); return y, x - (a // b) * y, g
def ext_gcd_vec(w):
    g, coef = 0, [0] * len(w)
    for i, x in enumerate(w):
        if x == 0: continue
        if g == 0: g = abs(x); coef = [0] * len(w); coef[i] = 1 if x > 0 else -1; continue
        a0, b0, g2 = egcd(g, x); coef = [a0 * c for c in coef]; coef[i] += b0; g = g2
    return g, coef
def solve_coords(Lb, U):
    d = len(Lb); G = [[F(dot(a, b)) for b in Lb] for a in Lb]; r = [F(dot(a, U)) for a in Lb]
    A = [row[:] + [rv] for row, rv in zip(G, r)]
    for c in range(d):
        p = next(i for i in range(c, d) if A[i][c] != 0); A[c], A[p] = A[p], A[c]
        for i in range(d):
            if i != c and A[i][c] != 0:
                f = A[i][c] / A[c][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    w = [A[i][d] / A[i][i] for i in range(d)]
    assert all(x.denominator == 1 for x in w); w = [int(x) for x in w]
    assert [sum(w[j] * Lb[j][i] for j in range(d)) for i in range(len(U))] == list(U)
    return w
def gso(B):
    Bs = []
    for b in B:
        v = [F(x) for x in b]
        for s in Bs: mu = dot(b, s) / dot(s, s); v = [a - mu * c for a, c in zip(v, s)]
        Bs.append(v)
    return Bs
def inv(G):
    n = len(G); A = [row[:] + [F(int(i == j)) for j in range(n)] for i, row in enumerate(G)]
    for c in range(n):
        p = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[p] = A[p], A[c]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c] / A[c][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return [[A[i][n + j] / A[i][i] for j in range(n)] for i in range(n)]

def farey_gate(U, N):
    """G1 = K1 gate (Lemma KG): the first q in 2..N dividing no u gives 1/q.  Same output as the A18 Farey loop (only a = 1 is ever needed)."""
    if TIGHT_ONLY:
        return F(1, N) if list(U) == list(range(1, N)) else None
    for q in range(2, N + 1):
        if all(u % q for u in U): return F(1, q)
    return None

def F19(N, V, depth=0): return F18(N, V, depth)
def F18(N, V, depth=0):
    """returns (status, t, trace).  trace: dict with gate / levels / exception info."""
    tr = {"N": N, "V": list(V), "depth": depth, "levels": []}
    if any(v == 0 for v in V): tr["end"] = "G0 zero speed"; return "NOSOL", None, tr
    S = sorted({abs(v) for v in V}); g = 0
    for v in S: g = gcd(g, v)
    U = [v // g for v in S]; m = len(U); tr["g"] = g; tr["U"] = U
    if (FAREY or TIGHT_ONLY) and (TOPGATE or depth > 0):
        s0 = farey_gate(U, N)
        if s0 is not None:
            t = s0 / g; assert safe(S, N, t); tr["end"] = "G1 Farey %s" % s0; return "SAFE", t, tr
    if m == 1:
        t = F(1, 2 * g); tr["end"] = "m=1"; return "SAFE", t, tr
    Lb = [[int(i == j) for j in range(m)] for i in range(m)]
    while True:
        d = len(Lb)
        if d == 1: break
        w = solve_coords(Lb, U); M = [[Lb[j][i] for j in range(d)] for i in range(m)]
        lv = {"d": d, "basis": [r[:] for r in Lb], "w": w[:]}
        if d == m:
            ystar = [F(1, 2)] * d; lv["target"] = "1/2"
        else:
            u, s, merges = dclose.coincidence_line(M)
            sd = sorted({abs(x) for x in s}); n = len(sd)
            st, ts, itr = F18(n + 1, sd, depth + 1)
            lv["target"] = {"u": u, "s": s, "recursive N": n + 1, "t*": ts, "status": st}; lv["inner"] = itr
            if st != "SAFE":
                tr["levels"].append(lv)
                tr["end"] = "UNFINISHED: recursive call F(%d,%s) returned %s" % (n + 1, sd, st)
                tr["kind"] = "INNER"; tr["source"] = itr["source"]; tr["via_level"] = len(tr["levels"]); return "UNFINISHED", None, tr
            ystar = [ts * c for c in u]
        eta = min(dist(dot(Mi, ystar)) for Mi in M) - F(1, N); assert eta > 0
        Rb = relations18(w); n_ = len(Rb)
        Gi = inv([[F(dot(a, b)) for b in Rb] for a in Rb])
        B = [[sum(Gi[i][k] * Rb[k][c] for k in range(n_)) for c in range(d)] for i in range(n_)]
        B = _lll.lll(B); Bs = gso(B)
        ww = F(dot(w, w)); T = [y - dot(ystar, w) / ww * wi for y, wi in zip(ystar, w)]
        e = T[:]; coeffs = []
        for i in range(n_ - 1, -1, -1):
            c = round(dot(e, Bs[i]) / dot(Bs[i], Bs[i])); coeffs.append(c); e = [a - c * b for a, b in zip(e, B[i])]
        rho2 = sum(dot(b, b) for b in Bs) / 4; mu2 = max(dot(Mi, Mi) for Mi in M)
        x = [a - b for a, b in zip(ystar, e)]
        if d == 2:                                               # C32 exact rank-2 formula: z = (-q, p), D = p^2 + q^2, delta = z.y* - rnd(z.y*), x = y* - (delta/D) z
            p_, q_ = w; zz2 = [-q_, p_]; D_ = p_ * p_ + q_ * q_; zy = dot(zz2, ystar); delta = zy - round(zy)
            assert x == [y - delta / D_ * c for y, c in zip(ystar, zz2)], "rank-2 formula disagrees with Babai"
            lv["delta"] = delta; lv["D"] = D_
        vals = [dist(dot(Mi, x)) for Mi in M]
        strict = rho2 * mu2 < eta * eta
        lv.update({"eta": eta, "rho2": rho2, "mu2": mu2, "strict": strict, "babai_coeffs": coeffs[::-1], "x": x, "min_dist": min(vals)})
        if min(vals) >= F(1, N):
            g1, gam = ext_gcd_vec(w); assert g1 == 1
            s_ = sum(gi * xi for gi, xi in zip(gam, x)) % 1
            assert all(dist(dot(Mi, [s_ * wi for wi in w])) >= F(1, N) for Mi in M)
            t = s_ / g; assert safe(S, N, t)
            lv.update({"accept": "strict" if strict else "exact", "gamma": gam, "s": s_}); tr["levels"].append(lv)
            tr["end"] = "ACCEPT level %d (d=%d, %s)" % (len(tr["levels"]), d, lv["accept"]); return "SAFE", t, tr
        assert not strict                                        # BAB: strict would have passed the exact check
        z = [xx / dot(Bs[-1], Bs[-1]) for xx in Bs[-1]]
        assert all(xx.denominator == 1 for xx in z); z = [int(xx) for xx in z]; assert dot(z, w) == 0
        zz = 0
        for xx in z: zz = gcd(zz, xx)
        assert zz == 1                                           # primitive (C28/C29 item 1)
        bound2 = mu2 * n_ * 2 ** (n_ - 1) / (4 * eta * eta)
        assert dot(z, z) <= bound2                               # DESC
        assert dot(z, z) <= mu2 * (2 ** n_ - 1) / (4 * eta * eta)  # DESC' (A19 Lemma: |b*_i|^2 <= 2^(n-i)|b*_n|^2)
        K = relations18(z)
        lv.update({"z": z, "z2_bound": bound2}); tr["levels"].append(lv)
        Lb = [[sum(c[j] * Lb[j][i] for j in range(d)) for i in range(m)] for c in K]
    tr["exception"] = {"N": N, "U": tuple(U)}
    if TABLES is not None and N in TABLES and tuple(U) in TABLES[N]:
        t = TABLES[N][tuple(U)] / g; assert safe(S, N, t); tr["end"] = "TABLE"; return "SAFE", t, tr
    tr["end"] = "UNFINISHED: rank-1 exception N=%d U=%s" % (N, tuple(U))
    tr["kind"] = "TOP-RANK1" if depth == 0 else "RANK1-AT-DEPTH-%d" % depth; tr["source"] = (N, tuple(U), depth); return "UNFINISHED", None, tr

def decide(U, N):
    """Exact decider (certificate tool, NOT part of the rule): least safe time in [0,1), or proof that none exists.
    No cap: each iteration moves t to a strictly larger left endpoint (k + 1/N)/u of some safe arc; there are at most sum(u) of them in [0,1)."""
    from rec import next_safe
    t = F(0); it = 0; bound = sum(U) + 1
    while True:
        nt = max(next_safe(u, t, N) for u in U); it += 1
        if nt == t: return "SAFE", t, it
        if nt >= 1: return "NOSOL", None, it
        t = nt; assert it <= bound
