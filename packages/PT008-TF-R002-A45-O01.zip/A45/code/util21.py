# A21: helper functions extracted verbatim from count20.py (A20) so that importing them does not rerun the A20 counting.
import itertools
import numpy as np
from math import isqrt
from bd19 import dot
def kernel_vec(rows):                      # rows: (d-1) x d integer, rank d-1 -> integer kernel vector by cofactors
    d = len(rows[0]); A = np.array(rows, dtype=object); v = []
    for j in range(d):
        minor = [[A[i][c] for c in range(d) if c != j] for i in range(d - 1)]
        v.append((-1) ** j * det(minor))
    return v
def det(M):
    n = len(M)
    if n == 1: return M[0][0]
    if n == 2: return M[0][0] * M[1][1] - M[0][1] * M[1][0]
    return sum((-1) ** c * M[0][c] * det([r[:c] + r[c + 1:] for r in M[1:]]) for c in range(n))
def rays(A):
    d = len(A[0]); R = []
    for idx in itertools.combinations(range(len(A)), d - 1):
        r = kernel_vec([A[i] for i in idx])
        if not any(r): continue
        for sg in (1, -1):
            rr = [sg * x for x in r]
            if all(dot(a, rr) >= 0 for a in A) and rr not in R: R.append(rr)
    return R
def prim_np(d, R2):
    """primitive integer vectors with |z|^2 <= R2, first nonzero coordinate positive; built slice by slice in the first coordinate (memory)."""
    r = isqrt(int(R2)); ax = np.arange(-r, r + 1); out = []
    for x0 in range(0, r + 1):
        rest2 = int(R2) - x0 * x0
        if rest2 < 0: break
        rr = isqrt(rest2); bx = np.arange(-rr, rr + 1)
        G = np.stack(np.meshgrid(*([bx] * (d - 1)), indexing="ij"), -1).reshape(-1, d - 1)
        G = G[(G * G).sum(1) <= rest2]
        G = np.concatenate([np.full((len(G), 1), x0), G], 1)
        if x0 == 0:
            G = G[np.any(G != 0, 1)]
            first = G[np.arange(len(G)), np.argmax(G != 0, 1)]; G = G[first > 0]
        g = np.gcd.reduce(np.abs(G), axis=1); out.append(G[g == 1])
    return np.concatenate(out) if out else np.zeros((0, d), dtype=np.int64)
def cone_ok(Z, R):
    assert len(R)
    # All relation coordinates are bounded by 8 for these three caps.
    assert all(sum(abs(x) for x in row)*8 < 2**63 for row in R)
    V = Z @ np.array(R, dtype=np.int64).T
    return (V.max(1) > 0) & (V.min(1) < 0)
