# A27 Lemma SR (shortest-relation comparison) and the node/prefix exclusion tests it gives.
# Lemma SR.  At a BD-v19 descent with coordinate vector w in Z^d (n = d-1), the relation used is z = b*_n/|b*_n|^2 for an LLL-reduced (delta = 3/4) basis B of
#   Lambda = pi_w(Z^d), whose dual lattice is Rel(w) = Z^d cap w^perp.  The reversed dual basis has Gram-Schmidt vectors b*_i/|b*_i|^2, so every nonzero
#   y in Rel(w) has |y| >= min_i 1/|b*_i| = 1/max_i |b*_i|; LLL gives |b*_i|^2 <= 2^(n-i)|b*_n|^2.  Hence  |z|^2 <= 2^(n-1) * lambda_1(Rel(w))^2.
# Exclusion.  If every leaf of a node lies in a lattice L (in the coordinates of some level), then Rel(w) contains L^perp, so lambda_1(Rel(w)) <= lambda_1(L^perp):
#   E1 (level 1, n = 4):  |z1|^2 > 8 * lambda_1( L^perp in Z^5 )^2      => no input descends through this node/prefix with first relation z1;
#   E2 (level 2, n = 3):  |z2|^2 > 4 * lambda_1( (L2 in L4-coordinates)^perp in Z^4 )^2  => no input reaches this rank-2 node.
from fractions import Fraction as F
import lll19
from bd19 import dot, relations18
from math import isqrt
def kernel_rows(A):
    """integer basis of {x in Z^c : A x = 0} for an integer k x c matrix A of full row rank (LLL of [I | S A^T], S large; the zero-tail rows)."""
    c = len(A[0]); k = len(A); S = 10 ** 6 * (1 + max(abs(v) for r in A for v in r)) ** 2 * 2 ** c
    rows = lll19.lll([[int(i == j) for j in range(c)] + [S * A[t][i] for t in range(k)] for i in range(c)])
    K = [r[:c] for r in rows if not any(r[c:])]
    assert len(K) == c - k and all(all(dot(r, a) == 0 for a in A) for r in K)
    return K
def lambda1_sq(B):
    """exact squared length of a shortest nonzero vector of the lattice with integer basis rows B (Fincke-Pohst on the LLL basis)."""
    B = lll19.lll([list(r) for r in B]); n = len(B)
    Bs = []; mu = [[F(0)] * n for _ in range(n)]
    for i in range(n):
        v = [F(x) for x in B[i]]
        for j in range(i):
            mu[i][j] = F(dot(B[i], Bs[j])) / dot(Bs[j], Bs[j]); v = [a - mu[i][j] * b for a, b in zip(v, Bs[j])]
        Bs.append(v)
    bb = [dot(v, v) for v in Bs]; best = [dot(B[0], B[0])]
    def rec(k, c, partial):
        # choose c_k given c_{k+1..n-1}; center = -sum_{j>k} c_j mu[j][k]
        center = -sum(c[j] * mu[j][k] for j in range(k + 1, n)); rad2 = best[0] - partial
        if rad2 < 0: return
        r = (rad2 / bb[k]) ** 0.5 + 1
        for ck in range(int(center - r) - 1, int(center + r) + 2):
            p = partial + (ck - center) ** 2 * bb[k]
            if p > best[0]: continue
            c[k] = ck
            if k == 0:
                if any(c):
                    v = [sum(c[i] * B[i][t] for i in range(n)) for t in range(len(B[0]))]; best[0] = min(best[0], dot(v, v))
            else: rec(k - 1, c, p)
        c[k] = 0
    rec(n - 1, [0] * n, F(0))
    return best[0]
def e1_value(L):          # L: basis rows (in Z^5) of the lattice containing every leaf -> lambda_1(L^perp)^2
    return lambda1_sq(kernel_rows(L))
