# A27: lambda_1(Rel(U))^2 and |z1|^2 on the 74 known TOP-RANK1 inputs, and on the K1-failing H6-missing leaves listed by the A23 certificate block (if present).
import json
from collections import Counter
from bd19 import F19, dot
from sr27 import kernel_rows, lambda1_sq
c = Counter()
for r in json.load(open("union20.json")):
    U = list(r[0]); st, t, tr = F19(6, U); z1 = tr["levels"][0]["z"]
    c[(lambda1_sq(kernel_rows([U])), dot(z1, z1))] += 1
print("74 known TOP-RANK1: (lambda_1(Rel U)^2, |z1|^2) -> count:", dict(sorted(c.items())))
