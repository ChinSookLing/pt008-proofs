# A28 (TEST of the PROVED lemmas R, P, RP on real runs) + statistics of real level-1 descents.
import json, random, sys
from collections import Counter
from fractions import Fraction as F
import bd19
from row28 import levels_of_run, check_level
rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 28); NS = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
Us = [tuple(r[0]) for r in json.load(open("union20.json"))]
for H in (30, 60, 120, 250, 500, 1000, 3000):
    Us += [tuple(sorted(rng.sample(range(1, H), 5))) for _ in range(NS)]
nl = 0; s1 = Counter(); top = []; Pmax = {}
bd19.TOPGATE = False
for U in Us:
    st, tr, res = levels_of_run(U)
    for k, D in enumerate(res):
        if not D["fail"]: continue
        check_level(D); nl += 1
        if k == 0:
            s1[D["zz"]] += 1; Pmax[D["zz"]] = max(Pmax.get(D["zz"], 0), D["P"])
            top.append((D["zz"], float(D["P"]), U))
bd19.TOPGATE = True
print("runs %d (G1 off at the top) ; failing levels checked against Lemmas R, P, RP and the LLL profile: %d, violations 0" % (len(Us), nl))
print("level-1 descents by |z1|^2:", dict(sorted(s1.items())))
print("max P = sum_{j<4}|b*_j|^2/|b*_4|^2 by |z1|^2 (LLL cap 14):", {k: round(float(v), 3) for k, v in sorted(Pmax.items())})
top.sort(reverse=True); print("largest |z1|^2 level-1 descents:", top[:8])
