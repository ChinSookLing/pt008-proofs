# C18-CERT02.  Step-by-step certificate for DC (coincidence iteration + Lemma E) and an INDEPENDENT verifier.
# The producer is dclose.co_step / kernel_basis; the verifier re-derives every claimed property with its own exact linear algebra.
import random, json
from fractions import Fraction as F
from a02_lib import dist
from dclose import co_step, kernel_basis, strict_time, dot
def produce(M, N):
    d = len(M[0]); P = [[int(i == j) for j in range(d)] for i in range(d)]; steps = []
    while len(P) > 1:
        rows = [[dot(Mi, z) for z in P] for Mi in M]
        k, l, sg, D = co_step(rows); K = kernel_basis(D)
        newP = [[sum(c[i] * P[i][j] for i in range(len(P))) for j in range(d)] for c in K]
        steps.append({"P": P, "k": k, "l": l, "sk": sg[0], "sl": sg[1], "D": D, "K": K}); P = newP
    u = P[0]; s = [dot(Mi, u) for Mi in M]; t = strict_time(s, N)
    return {"M": M, "N": N, "steps": steps, "u": u, "t": [t.numerator, t.denominator] if t is not None else None}
# ---------------- independent verifier ----------------
def rk(vs):
    A = [[F(x) for x in v] for v in vs if any(v)]
    if not A: return 0
    r, n = 0, len(A[0])
    for c in range(n):
        p = next((i for i in range(r, len(A)) if A[i][c] != 0), None)
        if p is None: continue
        A[r], A[p] = A[p], A[r]
        for i in range(len(A)):
            if i != r and A[i][c] != 0:
                f = A[i][c] / A[r][c]; A[i] = [a - f * b for a, b in zip(A[i], A[r])]
        r += 1
    return r
def classes(rows):
    cls = []
    for i, r in enumerate(rows):
        for c in cls:
            q = rows[c[0]]
            if r == q or r == [-x for x in q]: c.append(i); break
        else: cls.append([i])
    return len(cls)
def verify(cert):
    M, N = cert["M"], cert["N"]; m, d = len(M), len(M[0]); P = [[int(i == j) for j in range(d)] for i in range(d)]
    rows0 = [[sum(a * b for a, b in zip(Mi, z)) for z in P] for Mi in M]
    assert all(any(r) for r in rows0) and rk(rows0) == d, "V0 rows nonzero and spanning"
    ncls = classes(rows0)
    for st in cert["steps"]:
        assert st["P"] == P, "V0' chain continuity"
        rows = [[sum(a * b for a, b in zip(Mi, z)) for z in P] for Mi in M]
        D = [st["sk"] * a + st["sl"] * b for a, b in zip(rows[st["k"]], rows[st["l"]])]
        assert D == st["D"] and any(D), "V1 D = sk r_k + sl r_l != 0"
        assert all(rk([D, r]) == 2 for r in rows), "V2 D not parallel to any restricted row"
        K = st["K"]
        assert all(sum(a * b for a, b in zip(D, c)) == 0 for c in K) and rk(K) == len(P) - 1, "V3 K spans ker D (over Q)"
        P = [[sum(c[i] * P[i][j] for i in range(len(P))) for j in range(d)] for c in K]
        rows2 = [[sum(a * b for a, b in zip(Mi, z)) for z in P] for Mi in M]
        assert all(any(r) for r in rows2) and rk(rows2) == len(P), "V4 restricted rows nonzero and spanning"
        n2 = classes(rows2); assert n2 < ncls, "V5 class count strictly decreases"
        ncls = n2
    u = P[0]; s = [sum(a * b for a, b in zip(Mi, u)) for Mi in M]
    assert P == [cert["u"]] and all(s), "V6 final speeds nonzero"
    nd = len({abs(x) for x in s}); assert nd <= m - d + 1, "V6' distinct |speeds| <= m-d+1"
    if 2 * nd <= N: assert cert["t"] is not None, "Lemma E guarantees a strict time"
    if cert["t"] is not None:
        t = F(*cert["t"]); y = [t * c for c in u]
        assert all(dist(sum(a * b for a, b in zip(Mi, y))) > F(1, N) for Mi in M), "V7 strict point"
    return nd
if __name__ == "__main__":
    rng = random.Random(1818); tot = 0; worst = {}
    def rand_rows(m, d, H, mode):
        while True:
            if mode == "generic": M = [[rng.randint(-H, H) for _ in range(d)] for _ in range(m)]
            elif mode == "parallel":
                base = [[rng.randint(-H, H) for _ in range(d)] for _ in range(d)]
                M = base + [[rng.choice([1, -1, 2, -2, 3]) * x for x in rng.choice(base)] for _ in range(m - d)]
            elif mode == "coplanar":
                a = [rng.randint(-H, H) for _ in range(d)]; b = [rng.randint(-H, H) for _ in range(d)]
                M = [[rng.randint(-2, 2) * x + rng.randint(-2, 2) * y for x, y in zip(a, b)] for _ in range(m - d + 2)] + [[rng.randint(-H, H) for _ in range(d)] for _ in range(d - 2)]
            else:
                e = [rng.randint(-H, H) for _ in range(d)]
                M = [[j * x for x in e] for j in range(1, m - d + 2)] + [[rng.randint(-H, H) for _ in range(d)] for _ in range(d - 1)]
            rng.shuffle(M)
            if all(any(r) for r in M) and rk(M) == d: return M
    sample = None
    for N, d in [(6, 3), (6, 4), (6, 2), (5, 3), (5, 2), (4, 2), (4, 3), (7, 4), (7, 3)]:
        for mode in ("generic", "parallel", "coplanar", "tightlike"):
            for _ in range(150):
                M = rand_rows(N - 1, d, 4, mode); cert = produce(M, N); nd = verify(json.loads(json.dumps(cert)))
                tot += 1; worst[(N, d)] = max(worst.get((N, d), 0), nd)
                if sample is None and N == 6 and d == 3 and mode == "coplanar": sample = cert
    print("certificates produced and independently verified: %d; max distinct speeds per (N,d): %s" % (tot, worst))
    json.dump(sample, open("dc_cert_sample_N6_d3.json", "w"), indent=1)
    print("sample N=6, d=3 certificate written (dc_cert_sample_N6_d3.json)")
