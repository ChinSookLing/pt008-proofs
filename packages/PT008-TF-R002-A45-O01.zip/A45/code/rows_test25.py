# TEST: sector_disk_rows == old box+disk+sector mask (same point set and same order), random rows and bounds.
import random, numpy as np, sys
sys.argv = ["x", "-1", "1", "-1", "1", "-1", "1", "count"]
from class25 import sector_disk_rows
rng = random.Random(44); bad = 0; n = 0; tot = 0
for _ in range(3000):
    rows = [(rng.randint(-9, 9), rng.randint(-9, 9)) for _ in range(5)]; B = rng.randint(0, 3000); R = int(B ** 0.5) + 1
    ax = np.arange(-R, R + 1); P, Q = np.meshgrid(ax, ax, indexing="ij"); P = P.ravel(); Q = Q.ravel()
    keep = (P * P + Q * Q <= B) & np.all(np.stack([P, Q], 1) @ np.array(rows).T > 0, axis=1)
    p, q = sector_disk_rows(rows, B); n += 1; tot += len(p)
    bad += not (np.array_equal(p, P[keep]) and np.array_equal(q, Q[keep]))
print("row-interval generator vs box mask: %d random cases (%d points), %d differences (set and order)" % (n, tot, bad))
