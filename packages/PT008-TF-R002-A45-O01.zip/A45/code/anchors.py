# A05 Endpoint Anchoring.  Exact safe set S(V) (closed, finite union of closed intervals / points) and its left endpoints;
# anchor test: t = (Nk+1)/(N v) is a LEFT endpoint of the safe interval of speed v  (v t = k + 1/N).   TESTS / exact certificates only.
import sys, itertools
from fractions import Fraction as F
from math import gcd
from a02_lib import classify, safe, dist
def prep(V): return sorted({abs(v) for v in V if v != 0})
def components(V, N):
    V = prep(V)
    pts = sorted({F(N * k + s, N * v) for v in V for k in range(0, v + 1) for s in (-1, 1)} | {F(0), F(1)})
    pts = [x for x in pts if 0 <= x <= 1]
    comps = []; cur = None
    for i, x in enumerate(pts):
        if safe(V, N, x):
            if cur is None: cur = [x, x]
            else: cur[1] = x
        else:
            if cur is not None: comps.append(tuple(cur)); cur = None
            continue
        if i + 1 < len(pts):
            m = (x + pts[i + 1]) / 2
            if not safe(V, N, m) and cur is not None: comps.append(tuple(cur)); cur = None
    if cur is not None: comps.append(tuple(cur))
    return comps
def left_anchors(alpha, V, N):
    return [v for v in prep(V) if (N * v * alpha) % N == 1 and (N * v * alpha).denominator == 1]
def provides(v, V, N):
    return [k for k in range(v) if safe(V, N, F(N * k + 1, N * v))]
if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "demo":
        for N, V, nm in ((6, (1, 2, 3, 4, 5), "A1"), (6, (1, 3, 4, 5, 9), "A2"), (6, (1, 2, 4, 5, 6), "E1"), (6, (1, 15, 16, 17, 18), "E2"), (5, (840, 1, 2, 7), "E3")):
            C = components(V, N)
            print("%s N=%d V=%s: %d components; first: %s ; left anchors of each component: %s" % (nm, N, V, len(C), [(str(a), str(b)) for a, b in C[:3]],
                  [left_anchors(a, V, N) for a, b in C][:8]))
            print("    speeds providing an anchored safe time (v: #k): %s" % {v: len(provides(v, V, N)) for v in prep(V) if v <= 2000})
