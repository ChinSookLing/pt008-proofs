# A12 Task 2 (constructive form of Lemma CO-iter + Lemma E3):  given m nonzero integer forms M_1..M_m on T^d spanning Q^d (d >= 2),
# build u in Z^d by d-1 coincidence steps (each merges two classes of rows that are non-parallel on the current sublattice),
# then a strict time t for the <= m-d+1 distinct speeds s = M u  (exact gap computation), and the point y = t u:
#   ||M_i y|| > 1/N for all i   (checked exactly).
from fractions import Fraction as F
from math import gcd, floor, ceil
from a02_lib import dist
from lll import relations
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def rank(vs):
    rows = [[F(x) for x in v] for v in vs]; r = 0; ncol = len(rows[0]) if rows else 0
    for c in range(ncol):
        p = next((i for i in range(r, len(rows)) if rows[i][c] != 0), None)
        if p is None: continue
        rows[r], rows[p] = rows[p], rows[r]
        for i in range(len(rows)):
            if i != r and rows[i][c] != 0:
                f = rows[i][c] / rows[r][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[r])]
        r += 1
    return r
def parallel(a, b): return rank([a, b]) < 2
def co_step(rows):
    """Lemma CO: rows nonzero, spanning rank >= 2.  Return (k, l, signs, D) with D = sk*row_k + sl*row_l != 0, not parallel to any row."""
    n = len(rows)
    i0, j0 = next((i, j) for i in range(n) for j in range(i + 1, n) if not parallel(rows[i], rows[j]))
    a, b = rows[i0], rows[j0]
    plane = [r for r in range(n) if rank([a, b, rows[r]]) == 2]
    # plane coordinates (alpha, beta) of each in-plane row: solve r = alpha a + beta b via two independent coordinates
    k = len(a); p, q = next((p, q) for p in range(k) for q in range(p + 1, k) if a[p] * b[q] - a[q] * b[p] != 0)
    det = a[p] * b[q] - a[q] * b[p]
    def coords(r): return (F(r[p] * b[q] - r[q] * b[p], det), F(a[p] * r[q] - a[q] * r[p], det))
    reps = []
    for r in plane:
        al, be = coords(rows[r]); sg = 1
        if be < 0 or (be == 0 and al < 0): al, be, sg = -al, -be, -1
        reps.append((al, be, r, sg))
    # sort by angle in [0, pi): compare by cross product (all in closed upper half plane, alpha>0 when beta=0)
    import functools
    def cmp(x, y):
        cr = x[0] * y[1] - x[1] * y[0]
        return -1 if cr > 0 else (1 if cr < 0 else 0)
    reps.sort(key=functools.cmp_to_key(cmp))
    lines = []
    for x in reps:
        if not lines or cmp(lines[-1], x) != 0: lines.append(x)
    x, y = lines[0], lines[1]                                  # consecutive lines; sector < pi
    sx, sy = x[3], y[3]
    D = [sx * u + sy * v for u, v in zip(rows[x[2]], rows[y[2]])]
    assert any(D) and not any(parallel(D, r) for r in rows)
    return x[2], y[2], (sx, sy), D
def kernel_basis(D):
    """basis (columns) of {z in Z^k : D.z = 0}."""
    k = len(D)
    if k == 1: return []
    return relations(D)
def coincidence_line(M):
    d = len(M[0]); P = [[int(i == j) for j in range(d)] for i in range(d)]   # current sublattice basis: rows of P are vectors in Z^d
    merges = []
    while len(P) > 1:
        rows = [[dot(Mi, z) for z in P] for Mi in M]           # restricted rows in coordinates of P
        assert all(any(r) for r in rows) and rank(rows) == len(P)
        k, l, sg, D = co_step(rows); merges.append((k, l, sg))
        K = kernel_basis(D)                                    # vectors c in Z^{len(P)} with D.c = 0
        P = [[sum(c[i] * P[i][j] for i in range(len(P))) for j in range(d)] for c in K]
    u = P[0]; s = [dot(Mi, u) for Mi in M]; assert all(s)
    return u, s, merges
def strict_time(s, N):
    S = sorted({abs(x) for x in s}); ivs = []
    for v in S:
        for j in range(v + 1): ivs.append((F(j, v) - F(1, N * v), F(j, v) + F(1, N * v)))
    ivs.sort(); best = None; cur = ivs[0][1]
    for a, b in ivs[1:]:
        if a > cur and (best is None or a - cur > best[1] - best[0]): best = (cur, a)
        cur = max(cur, b)
    if best is None: return None
    t = (best[0] + best[1]) / 2
    assert all(dist(v * t) > F(1, N) for v in S)
    return t
def strict_point(M, N):
    u, s, merges = coincidence_line(M); t = strict_time(s, N)
    if t is None: return None, u, s, merges
    y = [t * c for c in u]; x = [dot(Mi, y) for Mi in M]
    assert all(dist(xi) > F(1, N) for xi in x)
    return y, u, s, merges
