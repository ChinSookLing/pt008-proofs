# A21: Lemma BR construction with the C35 cost corrections: unit table prepared once per (q, N); after the all-forbidding check u = 0 (mod q),
# the residue r = 0 is skipped (u != 0 times a unit is never 0); for g = gcd(u, q) only the nonzero bad residues divisible by g are lifted:
# at most 2*floor(k/g) residues, each with at most g lifts, i.e. at most 2k candidate numerators per u.
from math import gcd
from fractions import Fraction as F
_cache = {}
def tables(q, N):
    if (q, N) not in _cache:
        k = -(-q // N) - 1
        _cache[(q, N)] = (k, [a for a in range(1, q) if gcd(a, q) == 1])
    return _cache[(q, N)]
def br_select21(U, q, N):
    k, units = tables(q, N); Fb = set()
    for u in U:
        u %= q
        if u == 0: return None
        g = gcd(u, q); qg = q // g
        if qg == 1: continue
        ui = pow(u // g, -1, qg)
        for r in list(range(g, k + 1, g)) + [-x for x in range(g, k + 1, g)]:     # nonzero bad residues that are multiples of g
            a0 = (r // g) * ui % qg
            for t in range(g):
                Fb.add((a0 + t * qg) % q)
    for a in units:
        if a not in Fb: return F(a, q)
    return None
if __name__ == "__main__":
    import random
    from br20 import br_select
    rng = random.Random(35); n = bad = 0
    for _ in range(40000):
        N = rng.randint(3, 9); q = rng.randint(2, 3 * N); U = [rng.randint(1, 10 ** rng.randint(1, 6)) for _ in range(rng.randint(1, N - 1))]
        n += 1; bad += br_select21(U, q, N) != br_select(U, q, N)
    print("br_select21 (C35 cost form) vs br_select (A20): %d cases, %d differences" % (n, bad))
