# A26 prefix-saturation certificate: remove the third bound for a listed set S of prefixes (z1, z2) with |z1|^2, |z2|^2 <= 12.
# For P in S every third relation 80 < |z3|^2 <= cap3(P) = 3 mu3^2/(4 eta3^2) (DESC') that passes the cone test is processed with the A25 leaf routine
# (interval generation, exact rank-2 check, K1, H6 masks, original BD-v19 replay).  |z3|^2 <= 80 is CL(12,12,80) (C45); |z3|^2 > cap3 is impossible (DESC').
# Usage: cert26.py budget [k/K]   (S = the cheapest prefixes by number of beyond-80 nodes whose cumulative count stays <= budget, from caps26_prefixes.json)
import sys, os, json, time
budget = int(sys.argv[1]); sl = sys.argv[2] if len(sys.argv) > 2 else "0/1"
sys.argv = ["x", "-1", "12", "-1", "12", "80", "100000", "cert"]
import class25 as C
from fractions import Fraction as F
from multiprocessing import Pool
PREF = json.load(open("caps26_prefixes.json"))
srt = sorted(PREF, key=lambda p: p[3]); S = []; cum = 0
for p in srt:
    if cum + p[3] > budget: break
    cum += p[3]; S.append(p)
k_, K_ = map(int, sl.split("/")); work = [p for p in S if p[3] > 0][k_::K_]
def job(p):
    z1, z2, c3s, nb = p
    st = {k: 0 for k in ("nodes", "in_sector", "K1_miss", "rank2_fails", "H6_miss", "known_hit", "box_points", "generated_points", "exact_checked", "fail_digest",
                         "node_closed_sector", "node_closed_K1", "node_closed_rank2", "node_closed_H6", "node_closed_replay")}; cex = []
    Lb4 = C.sub(C.I, z1); Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3)
    y3, e3, m3 = C.coinc(M3); c3 = F(3 * m3) / (4 * e3 * e3); assert str(c3) == c3s
    Z3 = C.prim_np(3, c3); Z3 = Z3[(Z3 * Z3).sum(1) > 80]; Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
    assert len(Z3) == nb
    for z3 in Z3.tolist():
        M2 = C.forms(C.sub(Lb3, z3))
        if any(not any(r) for r in M2): continue
        ys, eta, mu2 = C.coinc(M2); st["nodes"] += 1
        cex += [(u, k, z1, z2, z3) for u, k in C.leaves(M2, ys, eta, mu2, st, (tuple(z1), tuple(z2), tuple(z3)))]
    st.pop("_R", None); return st, cex
if __name__ == "__main__":
    t0 = time.perf_counter(); tot = {}; cex = []; MISS = {}
    with Pool(2) as pl:
        for st, cx in pl.imap_unordered(job, work, chunksize=4):
            for k, v in st.items():
                if k == "_known": continue
                elif k == "_miss": MISS.update(v)
                elif k == "fail_digest": tot[k] = (tot.get(k, 0) + v) % (1 << 64)
                else: tot[k] = tot.get(k, 0) + v
            cex += cx
    from collections import Counter
    tot["fail_digest"] = "%016x" % tot.get("fail_digest", 0); tot["H6_miss_distinct"] = len(MISS); tot["H6_miss_outcomes"] = dict(Counter(v[1] for v in MISS.values()))
    print("prefix-saturation budget %d slice %s: |S| = %d prefixes (%d with beyond-80 nodes, this slice %d) ; %s ; counterexamples %d %s  (%.0fs)"
          % (budget, sl, len(S), sum(1 for p in S if p[3] > 0), len(work), tot, len(cex), cex[:3], time.perf_counter() - t0))
    tag = "%d_%s" % (budget, sl.replace("/", "of"))
    json.dump({"budget": budget, "slice": sl, "prefixes_in_S": [[p[0], p[1], p[2]] for p in S], "counts": tot, "counterexamples": cex}, open("cert26_%s.json" % tag, "w"))
    json.dump(sorted([list(k), v] for k, v in MISS.items()), open("cert26_%s_H6miss.json" % tag, "w"))
