# A21 cross-check on random nodes of C(6,6,17): numpy integer leaf routine vs an independent Fraction implementation (C35 style) of
# sector + primitivity + K1 + exact rank-2 failure.  The sets of failing U must coincide node by node.
import sys, random, json
sys.argv = ["x", "6", "6", "17"]
import class21 as C
from class21 import sub, forms, coinc, I, prim_np, rays, cone_ok, diffrows, suffix_mixed
from fractions import Fraction as F
from math import gcd, isqrt
from a02_lib import dist
import numpy as np
rng = random.Random(21); nodes = []
Z1 = [z for z in prim_np(5, F(6)).tolist() if suffix_mixed(z)]
for z1 in Z1:
    Lb4 = sub(I, z1); M4 = forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = coinc(M4); Z2 = prim_np(4, min(F(6), F(7 * m4) / (4 * e4 * e4))); Z2 = Z2[cone_ok(Z2, rays(diffrows(M4)))]
    for z2 in Z2.tolist():
        Lb3 = sub(Lb4, z2); M3 = forms(Lb3)
        if any(not any(r) for r in M3): continue
        y3, e3, m3 = coinc(M3); Z3 = prim_np(3, min(F(17), F(3 * m3) / (4 * e3 * e3))); Z3 = Z3[cone_ok(Z3, rays(diffrows(M3)))]
        for z3 in Z3.tolist():
            if rng.random() < 0.03: nodes.append(forms(sub(Lb3, z3)))
def frac_fails(M2, ys, eta, mu2):
    Dmax = F(mu2, 4) / eta ** 2; R = isqrt(int(Dmax)); out = set()
    for p in range(-R, R + 1):
        Q = isqrt(int(Dmax) - p * p) if int(Dmax) >= p * p else -1
        for q in range(-Q, Q + 1):
            if gcd(p, q) != 1: continue
            U = tuple(a * p + b * q for a, b in M2)
            if not 0 < U[0] or any(u >= v for u, v in zip(U, U[1:])): continue
            if any(all(u % b for u in U) for b in (4, 5, 6)): continue
            D = p * p + q * q; ZY = -q * ys[0] + p * ys[1]; delta = ZY - round(ZY)
            x0, x1 = ys[0] + delta * q / D, ys[1] - delta * p / D
            if all(dist(a * x0 + b * x1) >= F(1, 6) for a, b in M2): continue
            out.add(U)
    return out
bad = 0; tot = 0
for M2 in nodes:
    if any(not any(r) for r in M2): continue
    ys, eta, mu2 = coinc(M2)
    st = {k: 0 for k in ("in_sector", "K1_miss", "rank2_fails", "H6_miss", "known_hit", "node_closed_sector", "node_closed_K1", "node_closed_rank2", "node_closed_H6", "node_closed_replay")}
    # capture the numpy failing set by re-running the routine's arithmetic with a hook: count only (sets compared through counts and a direct recomputation)
    a = frac_fails(M2, ys, eta, mu2)
    C.leaves(M2, ys, eta, mu2, st); tot += 1
    bad += (st["rank2_fails"] != len(a))
print("random nodes of C(6,6,17): %d compared ; rank-2-fail counts differing between the numpy routine and the Fraction implementation: %d" % (tot, bad))
