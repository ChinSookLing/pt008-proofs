# A28 (TEST, exhaustive): all normalized U = (u1<...<u5), gcd 1, G1 (= K1) failing, Hlo < u5 <= Hhi.  Level 1 of BD-v19 is replayed exactly (row28.level_data);
# every level-1 Babai failure is checked against Lemmas R, P, RP and tabulated by |z1|^2.  Usage: python3 exh28.py Hlo Hhi k K
import sys, json, time
from itertools import combinations
from math import gcd
from functools import reduce
from collections import Counter
from fractions import Fraction as F
from row28 import level_data, check_level
Hlo, Hhi, k, K = map(int, sys.argv[1:5])
I = [[int(i == j) for j in range(5)] for i in range(5)]; Y = [F(1, 2)] * 5
t0 = time.process_time(); tot = 0; fails = Counter(); Pmax = {}; ex = {}; slack = {}
for u5 in range(Hlo + 1, Hhi + 1):
    if u5 % K != k: continue
    for c in combinations(range(1, u5), 4):
        U = list(c) + [u5]
        if reduce(gcd, U) != 1 or not all(any(u % q == 0 for u in U) for q in range(2, 7)): continue
        tot += 1; D = level_data(I, Y, U, 6)
        if not D["fail"]: continue
        sl = check_level(D); s = D["zz"]; fails[s] += 1
        if D["P"] > Pmax.get(s, -1): Pmax[s] = D["P"]
        ex.setdefault(s, []);
        if len(ex[s]) < 3: ex[s].append(U)
        if sl is not None and (s not in slack or sl < slack[s][0]): slack[s] = (sl, U)
print("H in (%d,%d] shard %d/%d: G1-failing inputs %d ; level-1 failures %d ; cpu %.0f s" % (Hlo, Hhi, k, K, tot, sum(fails.values()), time.process_time() - t0))
print("by |z1|^2:", dict(sorted(fails.items())))
json.dump({"tot": tot, "fails": {str(a): b for a, b in fails.items()}, "Pmax": {str(a): str(b) for a, b in Pmax.items()}, "ex": {str(a): b for a, b in ex.items()},
           "slack": {str(a): [str(b[0]), b[1]] for a, b in slack.items()}}, open("exh28_%d_%d_%d.json" % (Hlo, Hhi, k), "w"))
