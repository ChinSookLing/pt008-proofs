# A45 (TEST): what goes wrong in plausible implementation slips — minimal witnesses.
#  V1 drop degenerate polygons (area 0);  V2 open bands (strict 1/6 < ...);  V3 floating ceil;  V4 h = a x - b y (wrong orientation).
from fractions import Fraction as F
from math import gcd, ceil
from itertools import product
from poly45 import polygons, rule, safe_set, is_safe, area2, egcd
def rule_variant(p, q, a, b, drop_deg=False, wrong_h=False):
    g, al, be = egcd(a, b)
    for k, P in polygons(p, q):
        if drop_deg and (len(set(P)) < 3 or area2(P) == 0): continue
        hs = [(a * x - b * y) if wrong_h else (b * x - a * y) for x, y in P]; m = min(hs); M = max(hs); j = ceil(m)
        if j <= M:
            Xm = P[hs.index(m)]; Xp = P[hs.index(M)]
            X = Xm if m == M else tuple(Xm[i] + (j - m) / (M - m) * (Xp[i] - Xm[i]) for i in range(2))
            return (al * X[0] + be * X[1]) % 1
    return None
# V1/V2: smallest |U|_inf input (5 speeds) whose safe set is points only: then dropping degenerate polygons or opening the bands loses every hit
print("V1/V2 witness: U = (1,2,3,4,5), p = U, q = e2, (a,b) = (1,0): safe set only {1/6, 5/6}")
p, q = (1, 2, 3, 4, 5), (0, 1, 0, 0, 0)
print("   exact rule t =", rule(p, q, 1, 0)[0], "; drop-degenerate variant t =", rule_variant(p, q, 1, 0, drop_deg=True),
      "(None = false miss; with open bands the point/segment cells are empty as well, so the same false miss)")
# V4: wrong orientation of h returns unsafe times; find the smallest witness over small planes
found = None
for p in product(range(-1, 3), repeat=5):
    q = (0, 1, 0, 0, 0)
    for a, b in [(1, 1), (1, 2), (2, 1), (1, -1)]:
        U = [a * x + b * y for x, y in zip(p, q)]
        if any(u == 0 for u in U): continue
        t = rule_variant(p, q, a, b, wrong_h=True)
        if t is not None and not is_safe(U, t): found = (p, q, a, b, U, t); break
    if found: break
print("V4 witness (h = a x - b y instead of b x - a y):", found and "p=%s q=%s (a,b)=(%d,%d) U=%s returns t=%s, which is NOT safe" % (found[0], found[1], found[2], found[3], found[4], found[5]))
# V3: floating-point ceil on an exact integer m: m = 1/3*3 computed in floats
m = 0.1 * 3 * 10 / 3; print("V3 illustration: float m = 0.1*3*10/3 =", repr(m), "ceil ->", ceil(m), "(exact value 1); a float ceil can skip the integer level j = m exactly when P touches it")
