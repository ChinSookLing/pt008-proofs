# A28 rerun (sr28, integer range) of the A27 checks of Lemma SR (TEST on real runs) and of the E1/E2 tests on the 74 known TOP-RANK1 inputs (they must never be excluded).
import json, sys, random
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "count"]
import class25 as C
from bd19 import F19, dot
from sr28 import kernel_rows, lambda1_sq
from itertools import product
def l1_rel(w):           # lambda_1(Rel(w))^2 exactly
    return lambda1_sq(kernel_rows([list(w)]))
# (1) Lemma SR on every descent of many real runs
rng = random.Random(1); n_desc = 0; bad = 0; tight = 0
Us = [tuple(r[0]) for r in json.load(open("union20.json"))] + [tuple(sorted(rng.sample(range(1, 400), 5))) for _ in range(1500)]
for U in Us:
    import bd19; bd19.TOPGATE = False
    st, t, tr = F19(6, list(U)); bd19.TOPGATE = True
    for lv in tr["levels"]:
        if "z" not in lv: continue
        z = lv["z"]; n = len(lv["w"]) - 1; l1 = l1_rel(lv["w"]); n_desc += 1
        if dot(z, z) > 2 ** (n - 1) * l1: bad += 1
        tight += dot(z, z) == l1
print("Lemma SR on %d descents of %d runs (G1 off at the top so that the lattice part runs): violations %d ; descents where z is itself a shortest relation: %d" % (n_desc, len(Us), bad, tight))
# (2) E1/E2 on the true chains of the 74 known TOP-RANK1 inputs
viol = 0
for U in [tuple(r[0]) for r in json.load(open("union20.json"))]:
    st, t, tr = F19(6, list(U)); L = tr["levels"]; z1, z2, z3 = L[0]["z"], L[1]["z"], L[2]["z"]
    Lb4 = C.sub(C.I, z1); Lb3 = C.sub(Lb4, z2); Lb2 = C.sub(Lb3, z3)
    e1p = lambda1_sq(kernel_rows(Lb3)); e1n = lambda1_sq(kernel_rows(Lb2))
    K2 = C.relation_kernel(tuple(z2)); K3 = C.relation_kernel(tuple(z3)); W = [[sum(K3[a][j] * K2[j][c] for j in range(3)) for c in range(4)] for a in range(2)]
    e2n = lambda1_sq(kernel_rows(W))
    if dot(z1, z1) > 8 * e1p or dot(z1, z1) > 8 * e1n or dot(z2, z2) > 4 * e2n: viol += 1
print("E1 (prefix and node) and E2 (node) on the true chains of the 74 known TOP-RANK1 inputs: exclusions %d (must be 0)" % viol)
