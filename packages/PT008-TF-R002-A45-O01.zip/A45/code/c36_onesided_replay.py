# C36 appendix 1 (verbatim): one-sided margin replay on the 42 known nodes
from collections import Counter
from fractions import Fraction as F
from math import gcd, isqrt
from pathlib import Path
import json
from bd19 import F19
from a02_lib import dist

nodes = {}
for U,_ in json.loads(Path("union20.json").read_text()):
    status,_,trace=F19(6,U)
    assert status == "UNFINISHED" and trace["kind"] == "TOP-RANK1"
    level=trace["levels"][-1]
    assert level["d"] == 2
    target=level["target"]
    nodes[tuple(map(tuple,level["basis"]))]=(
        [target["t*"]*u for u in target["u"]],level["eta"],level["mu2"])
counts=Counter()
for (A,B),(Y,eta,mu2) in nodes.items():
    H=F(mu2,4)/eta**2
    target=[(a*Y[0]+b*Y[1])%1 for a,b in zip(A,B)]
    for p in range(-isqrt(int(H)),isqrt(int(H))+1):
        r=isqrt(int(H)-p*p)
        for q in range(-r,r+1):
            if gcd(p,q)!=1:
                continue
            U=[a*p+b*q for a,b in zip(A,B)]
            if U[0]<=0 or any(x>=y for x,y in zip(U,U[1:])):
                continue
            if any(all(u%j for u in U) for j in (4,5,6)):
                continue
            D=p*p+q*q
            zy=-q*Y[0]+p*Y[1]
            delta=zy-round(zy)
            if D*eta**2 > mu2*delta**2:
                continue
            counts['delta_bound']+=1
            shifts=[delta*(-a*q+b*p) for a,b in zip(A,B)]
            disk=any(s>(t-F(1,6))*D or -s>(F(5,6)-t)*D
                     for s,t in zip(shifts,target))
            exact=any(dist(t-s/D)<F(1,6) for s,t in zip(shifts,target))
            assert not exact or disk
            counts['disk']+=disk
            counts['exact_fail']+=exact
print(len(nodes),dict(counts))

