# A45 (TEST): edge cases of the rule — threshold equality, unit-square boundary, segments, single points, m = M — and a random cross-check.
import random
from fractions import Fraction as F
from math import gcd
from poly45 import polygons, rule, safe_set, is_safe, area2
def check(p, q, a, b, label=""):
    U = [a * x + b * y for x, y in zip(p, q)]
    S = safe_set(U); r = rule(p, q, a, b)
    exists = bool(S)
    if r is None: return ("MISS", exists, U, S, None)
    t = r[0]; assert is_safe(U, t), ("UNSAFE", p, q, a, b, t)
    return ("HIT", exists, U, S, r)
# 1) tight instances whose safe set is a single pair of points: the polygon that is hit must be a point (or the hit a vertex), equality at 1/6
print("== single-point safe sets (threshold equality, degenerate P) ==")
for U, p, q, a, b in [((1, 2, 3, 4, 5), (1, 2, 3, 4, 5), (0, 1, 0, 0, 0), 1, 0),
                      ((1, 2, 3, 4, 5), (1, 1, 1, 1, 1), (0, 1, 2, 3, 4), 1, 1),
                      ((1, 2, 3, 4, 5), (0, 1, 2, 3, 4), (1, 1, 1, 1, 1), 1, 1),
                      ((1, 3, 4, 5, 9), (1, 3, 4, 5, 9), (0, 0, 1, 0, 0), 1, 0)]:
    st, ex, UU, S, r = check(p, q, a, b)
    print(" U=%s via p=%s q=%s (a,b)=(%d,%d): safe set %s ; rule %s t=%s polygon kind=%s hit kind=%s" %
          (UU, p, q, a, b, [(str(l), str(r_)) for l, r_ in S], st, r[0] if r else None, r[4] if r else None, r[3] if r else None))
# 2) exhaustive small planes: every p, q in {-2..2}^5 sampled, all primitive (a,b) with a^2+b^2 <= 50: rule vs exact safe set
print("== random small planes vs exact safe set ==")
rng = random.Random(45); n = 0; miss_ok = 0; hits = 0; bad = 0; kinds = {}; degs = {}; unsafe = 0
while n < 4000:
    p = [rng.randint(-3, 3) for _ in range(5)]; q = [rng.randint(-3, 3) for _ in range(5)]
    a = rng.randint(-7, 7); b = rng.randint(-7, 7)
    if gcd(a, b) != 1: continue
    U = [a * x + b * y for x, y in zip(p, q)]
    if any(u == 0 for u in U): continue
    n += 1; st, ex, UU, S, r = check(p, q, a, b)
    if st == "HIT": hits += 1; kinds[r[3]] = kinds.get(r[3], 0) + 1; degs[r[4]] = degs.get(r[4], 0) + 1
    if (st == "HIT") != ex: bad += 1
print(" cases %d (all u_i != 0) ; rule hits %d ; rule result != (safe set nonempty): %d ; returned t unsafe: 0 (asserted) ; hit kinds %s ; polygon kinds %s" % (n, hits, bad, kinds, degs))
# 3) adversarial: planes where u_i can vanish (rule must then report a miss iff the safe set is empty) and boundary-heavy planes (p_i, q_i in {0, +-1})
print("== boundary-heavy planes (p_i, q_i in {-1,0,1}) incl. zero speeds ==")
n = 0; bad = 0; zero = 0
for _ in range(3000):
    p = [rng.randint(-1, 1) for _ in range(5)]; q = [rng.randint(-1, 1) for _ in range(5)]
    a = rng.randint(-5, 5); b = rng.randint(-5, 5)
    if gcd(a, b) != 1: continue
    n += 1; st, ex, UU, S, r = check(p, q, a, b); zero += any(u == 0 for u in UU)
    if (st == "HIT") != ex: bad += 1
print(" cases %d (with a zero speed: %d) ; mismatches %d" % (n, zero, bad))
