# A27 helper functions shared by explore27/outside27 (rank-2 failing leaves, H6 first hit)
# A27 exploration (TEST): how often is a rank-2-failing, K1-failing leaf a true TOP-RANK1 input, and how does H6 cover those?
import sys, random, json, time
import class25 as C
import numpy as np
from fractions import Fraction as F
from math import gcd, lcm
from collections import Counter
from bd19 import F19
from br20 import mc_select, br_select, kq
def h6first(U):
    for q in range(7, 19):
        t = mc_select(U, q, 6) if kq(q, 6) == 1 else br_select(U, q, 6)
        if t is not None: return q, t
    return None
def rank2_fail_leaves(M2, ys, eta, mu2):
    H = lcm(ys[0].denominator, ys[1].denominator); Y = [int(y * H) for y in ys]
    P, Q = C.sector_disk_rows(C.diffrows(M2), int(mu2 / (4 * eta * eta)))
    k = np.gcd(P, Q) == 1; P, Q = P[k], Q[k]; Mn = np.array(M2, dtype=np.int64); U = (Mn @ np.stack([P, Q])).T
    k1 = np.any(U % 4 == 0, 1) & np.any(U % 5 == 0, 1) & np.any(U % 6 == 0, 1); P, Q, U = P[k1], Q[k1], U[k1]
    D = P * P + Q * Q; Zn = -Q * Y[0] + P * Y[1]; r0 = np.floor_divide(Zn, H); rem = Zn - H * r0
    dH = Zn - H * (r0 + (2 * rem > H) + ((2 * rem == H) & (r0 % 2 != 0))); nz = dH != 0; P, Q, D, U, dH = P[nz], Q[nz], D[nz], U[nz], dH[nz]
    fail = np.zeros(len(P), dtype=bool)
    for i in range(5):
        c = -Mn[i, 0] * Q + Mn[i, 1] * P; MY = int(Mn[i, 0]) * Y[0] + int(Mn[i, 1]) * Y[1]
        num = D * MY - dH * c; den = H * D; s = np.mod(num, den); fail |= 6 * np.minimum(s, den - s) < den
    return [tuple(u) for u in U[fail].tolist()], [(p, q) for p, q in zip(P[fail].tolist(), Q[fail].tolist())]
