# A29 (TEST): Q-DE versus level-1 failure on random G1-failing normalized inputs of larger size.
import random, sys
from math import gcd
from functools import reduce
from collections import Counter
from dual29 import level1_dual
rng = random.Random(int(sys.argv[2])); c = Counter()
for H in (60, 120, 250, 500, 1000, 5000):
    n = 0
    while n < int(sys.argv[1]):
        U = sorted(rng.sample(range(1, H), 5))
        if reduce(gcd, U) != 1 or not all(any(u % q == 0 for u in U) for q in range(2, 7)): continue
        n += 1; D = level1_dual(U); c["inputs"] += 1; c["Q-DE"] += D["de"]; c["fail"] += D["fail"]; c["Q-DE and fail"] += D["de"] and D["fail"]
print("random G1-failing inputs (u5 < 60 ... 5000): %s" % dict(c))
