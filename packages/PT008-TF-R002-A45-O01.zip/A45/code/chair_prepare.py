# C36 appendix 2 (verbatim): 64-bit guards + mask H6 cross-check, applied to a COPY of class21.py/util21.py
from pathlib import Path
p=Path("class21.py")
s=p.read_text()
def change(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
change('from math import gcd, isqrt','from math import gcd, isqrt')
change('def leaves(M2, ys, eta, mu2, st):', '''MASKS = {}
for mod in range(7, 19):
    units = [a for a in range(1, (mod//2)+1) if gcd(a, mod) == 1]
    MASKS[mod] = np.array([
        sum(1 << j for j,a in enumerate(units) if 6*min(a*u % mod, -a*u % mod) >= mod)
        for u in range(mod)], dtype=np.int64)

def leaves(M2, ys, eta, mu2, st):''')
change('    ax = np.arange(-R, R + 1); P, Q', '''    lim = (1 << 63) - 1
    M = max(abs(x) for row in M2 for x in row)
    E, G = eta.numerator, eta.denominator
    assert all(abs(x) <= lim for x in (H, *Y, 2*R*R, 8*R*R*E*E, mu2*G*G, 4*M*R, 2*M))
    Z = R * (abs(Y[0]) + abs(Y[1]))
    assert max(Z + H, 2*H, Z+2*H, 6*H*2*R*R, 2*R*R*M*(abs(Y[0])+abs(Y[1])) + H*M*R) <= lim
    ax = np.arange(-R, R + 1, dtype=np.int64); P, Q''')
change('    for u in U[fail].tolist():\n', '''    UV = U[fail]
    # Independent H6 check by intersecting masks for all five original residues.
    h6_miss = np.ones(len(UV), dtype=bool)
    for modulus, mask in MASKS.items():
        live = np.flatnonzero(h6_miss)
        if not len(live):
            break
        h6_miss[live] = np.bitwise_and.reduce(mask[UV[live] % modulus],axis=1) == 0
    for u, missing in zip(UV.tolist(), h6_miss.tolist()):
''')
change('        if h6(u) is None:', '        if missing:\n            assert h6(u) is None')
change('            if s_ == "UNFINISHED": out.append((u, tr["kind"]))', '''            if s_ != "SAFE": out.append((u, tr.get("kind",s_)))
            assert s_ != "SAFE" or (t_ is not None and all(dist(a*t_) >= F(1,6) for a in u))''')
p.write_text(s)
p=Path('util21.py')
s=p.read_text()
s=s.replace('    V = Z @ np.array(R, dtype=np.int64).T','''    assert len(R)
    # All relation coordinates are bounded by 8 for these three caps.
    assert all(sum(abs(x) for x in row)*8 < 2**63 for row in R)
    V = Z @ np.array(R, dtype=np.int64).T''')
p.write_text(s)