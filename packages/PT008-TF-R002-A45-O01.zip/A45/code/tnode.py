import time, random
from fractions import Fraction as F
exec(open("count20.py").read().split("rng = random.Random(20)")[0])
I = [[int(i == j) for j in range(m)] for i in range(m)]
Z1c = [z for z in prim_np(5, F(135, 4)).tolist() if suffix_mixed(z)]
rng = random.Random(1); tot = 0; t0 = time.time(); sizes = []
for z1 in rng.sample(Z1c, 15):
    Lb = sub(I, z1); M = [[Lb[j][i] for j in range(4)] for i in range(m)]
    if any(not any(r) for r in M): continue
    ys, eta, mu2 = coinc(M); R2 = F(7 * mu2) / (4 * eta * eta); t1 = time.time()
    Z2 = prim_np(4, R2); ok = cone_ok(Z2, rays(diffrows(M))); sizes.append((float(R2), len(Z2), int(ok.sum()), round(time.time() - t1, 2)))
print(sizes, "%.1fs per node" % ((time.time() - t0) / 15))
