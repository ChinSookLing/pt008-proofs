# C35 appendix: Chair's replay program for the 42 known rank-2 nodes (verbatim)
import json
from collections import Counter
from fractions import Fraction as F
from math import gcd, isqrt
from bd19 import F19
from a02_lib import dist

def safe_denominator(U, q):
    return any(
        all(6 * min((a * u) % q, (-a * u) % q) >= q for u in U)
        for a in range(1, q // 2 + 1) if gcd(a, q) == 1
    )

nodes = {}
known = {tuple(U) for U, _ in json.load(open("union20.json"))}
for U in known:
    status, _, trace = F19(6, U)
    assert status == "UNFINISHED" and trace["kind"] == "TOP-RANK1"
    last = trace["levels"][-1]
    assert last["d"] == 2
    B = tuple(map(tuple, last["basis"]))
    Y = tuple(c * last["target"]["t*"] for c in last["target"]["u"])
    eta, mu2 = last["eta"], last["mu2"]
    assert nodes.setdefault(B, (Y, eta, mu2)) == (Y, eta, mu2)

counts = Counter()
miss = set()
survivors = set()
for (A, B), (Y, eta, mu2) in nodes.items():
    Dmax = F(mu2, 4) / eta**2
    R = isqrt(int(Dmax))
    counts["max_R"] = max(counts["max_R"], R)
    for p in range(-R, R+1):
        Q = isqrt(int(Dmax) - p*p)
        for q in range(-Q, Q+1):
            if gcd(p, q) != 1:
                continue
            U = tuple(a*p + b*q for a, b in zip(A,B))
            if not 0 < U[0] or any(u >= v for u,v in zip(U,U[1:])):
                continue
            assert gcd(*U) == 1
            counts["primitive_in_cone"] += 1
            if any(all(u % b for u in U) for b in (4,5,6)):
                continue
            counts["K1_miss"] += 1
            D = p*p + q*q
            ZY = -q*Y[0] + p*Y[1]
            delta = ZY - round(ZY)
            if D * eta**2 > mu2 * delta**2:
                continue
            counts["delta_bound"] += 1
            x0,x1 = Y[0]+delta*q/D,Y[1]-delta*p/D
            if all(dist(a*x0+b*x1) >= F(1,6) for a,b in zip(A,B)):
                continue
            counts["rank2_fails"] += 1
            survivors.add(U)
            if not any(safe_denominator(U, b) for b in range(7,19)):
                counts["H6_miss"] += 1
                miss.add(U)

assert known <= survivors
actual = []
for U in sorted(miss):
    status, _, trace = F19(6, U)
    if status == "UNFINISHED":
        actual.append((U, trace["kind"]))
print(f"nodes={len(nodes)} known={len(known)}")
print(dict(counts))
print(f"distinct rank2 fails={len(survivors)} distinct H6 misses={len(miss)} actual uncovered={actual}")