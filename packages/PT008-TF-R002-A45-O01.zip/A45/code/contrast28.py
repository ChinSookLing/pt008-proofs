# A28: a G1-failing input with |z1|^2 = 13 whose level-1 profile P = 5.44 already exceeds 4*13/9 - 1, yet level 1 does NOT fail:
# a profile-only lemma cannot exclude |z1|^2 = 13; the loss sits in the alignment of e with the failing row.
from fractions import Fraction as F
from math import sqrt
from row28 import level_data
import bd19
for U in ([14, 20, 30, 37, 49], [5, 16, 23, 24, 64]):
    I = [[int(i == j) for j in range(5)] for i in range(5)]; D = level_data(I, [F(1, 2)] * 5, U, 6); s = D["zz"]; z = D["z"]
    st, t, tr = bd19.F19(6, U)
    print("U = %s : G1 %s ; BD-v19 %s, %s ; z1 = %s, |z1|^2 = %d, delta = %s, P = %.4f, Babai GS coefficients %s" %
          (U, bd19.farey_gate(U, 6), st, tr["end"], z, s, D["delta"], float(D["P"]), [str(c) for c in D["gsc"]]))
    for i, r in enumerate(D["rows"]):
        rest2 = float(r["pi2"]) - z[i] ** 2 / s; dz = abs(float(D["delta"])) * abs(z[i]) / s
        Ci = dz + 0.5 * sqrt(float(D["P"]) / s * rest2)
        print("   row %d (u = %d, z_i = %d): |e_i| = %.4f  (fails iff > 1/3) ; A' = %.4f ; C = %.4f %s" %
              (i + 1, U[i], z[i], float(abs(r["Me"])), dz + sum(abs(float(b[i])) for b in D["Bs"][:-1]) / 2, Ci, "> 1/3" if Ci > 1 / 3 else ""))
