# A29 (TEST, exhaustive): how often the level-1 dual pair is double-even (Q-DE) among ALL G1-failing normalized inputs with u5 in (Hlo, Hhi], and whether any Q-DE input fails at level 1.
import sys, json, time
from itertools import combinations
from math import gcd
from functools import reduce
from collections import Counter
from dual29 import level1_dual
Hlo, Hhi, k, K = map(int, sys.argv[1:5]); t0 = time.process_time(); c = Counter(); ex = []
for u5 in range(Hlo + 1, Hhi + 1):
    if u5 % K != k: continue
    for cc in combinations(range(1, u5), 4):
        U = list(cc) + [u5]
        if reduce(gcd, U) != 1 or not all(any(u % q == 0 for u in U) for q in range(2, 7)): continue
        D = level1_dual(U); c["inputs"] += 1; c["z1 even"] += D["zz"] % 2 == 0; c["Q-DE"] += D["de"]; c["fail"] += D["fail"]; c["Q-DE and fail"] += D["de"] and D["fail"]
        if D["de"] and len(ex) < 3: ex.append((U, D["z"], D["q"], D["zz"], float(D["P12"])))
print("H in (%d,%d] shard %d/%d: %s ; Q-DE examples %s ; cpu %.0f s" % (Hlo, Hhi, k, K, dict(c), ex, time.process_time() - t0))
