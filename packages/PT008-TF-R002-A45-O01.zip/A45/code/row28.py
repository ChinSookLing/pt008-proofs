# A28: the row form of the Babai failure condition (C51) and its consequences for the first relation z1.
# For a level with forms M (rows M_i), target y*, coordinates w, LLL basis B of Lambda = pi_w(Z^d), GS vectors b*_j, Babai error e (x = y* - e):
#   Lemma R    (row form):     if ||M_i x|| < 1/N then eta_i < |<M_i, e>| <= (1/2) sum_j |<M_i, b*_j>|,   eta_i = ||M_i y*|| - 1/N.
#   Lemma P    (last coefficient): the coefficient of e on b*_n is delta = y*.z - rnd(y*.z)  (z = b*_n/|b*_n|^2), exactly.
#   Lemma RP   (row form with the last coefficient and the LLL profile):
#              eta_i < |delta| |M_i.z| / |z|^2 + (1/2) sqrt((2^n - 2)/|z|^2) * sqrt(|pi_w M_i|^2 - (M_i.z)^2/|z|^2).
#   Level 1 (M = I, y* = 1/2, eta_i = 1/3, n = 4): delta = 0 iff |z|^2 even (sum z_i = |z|^2 mod 2), else |delta| = 1/2.
from fractions import Fraction as F
from math import isqrt
import bd19
from bd19 import dot, relations18, inv, gso, solve_coords
import lll19 as _lll
from a02_lib import dist
def level_data(M, ystar, w, N):
    """replays F3/F4 of BD-v19 exactly and returns the quantities of Lemmas R, P, RP."""
    d = len(w); Rb = relations18(w); n_ = len(Rb)
    Gi = inv([[F(dot(a, b)) for b in Rb] for a in Rb])
    B = [[sum(Gi[i][k] * Rb[k][c] for k in range(n_)) for c in range(d)] for i in range(n_)]
    B = _lll.lll(B); Bs = gso(B)
    ww = F(dot(w, w)); T = [y - dot(ystar, w) / ww * wi for y, wi in zip(ystar, w)]
    e = T[:]; coef = []
    for i in range(n_ - 1, -1, -1):
        c = round(dot(e, Bs[i]) / dot(Bs[i], Bs[i])); e = [a - c * b for a, b in zip(e, B[i])]
    gsc = [dot(e, b) / dot(b, b) for b in Bs]                 # GS coefficients of the final error
    assert all(abs(c) <= F(1, 2) for c in gsc)
    x = [a - b for a, b in zip(ystar, e)]
    z = [v / dot(Bs[-1], Bs[-1]) for v in Bs[-1]]
    zint = all(v.denominator == 1 for v in z)
    rows = []
    for Mi in M:
        eta = dist(dot(Mi, ystar)) - F(1, N); Me = dot(Mi, e); A = sum(abs(dot(Mi, b)) for b in Bs) / 2
        rows.append({"M": Mi, "eta": eta, "Me": Me, "A": A, "fail": dist(dot(Mi, x)) < F(1, N), "pi2": dot(Mi, Mi) - F(dot(Mi, w)) ** 2 / ww})
    out = {"d": d, "n": n_, "Bs": Bs, "e": e, "gsc": gsc, "x": x, "rows": rows, "fail": any(r["fail"] for r in rows)}
    if zint:
        z = [int(v) for v in z]; zz = dot(z, z); yz = dot(ystar, z); delta = yz - round(yz)
        out.update({"z": z, "zz": zz, "delta": delta, "P": sum(dot(b, b) for b in Bs[:-1]) * zz})   # P = sum_{j<n}|b*_j|^2 / |b*_n|^2  (<= 2^n - 2 by LLL)
    return out
def levels_of_run(U, N=6):
    """runs the original F19 and re-derives each level's data from its trace (and checks x against the trace)."""
    st, t, tr = bd19.F19(N, list(U)); res = []
    m = len(tr["U"]) if "U" in tr else 0
    for lv in tr["levels"]:
        Lb = lv["basis"]; d = lv["d"]; w = lv["w"]; M = [[Lb[j][i] for j in range(d)] for i in range(m)]
        if lv["target"] == "1/2": ys = [F(1, 2)] * d
        else: ys = [lv["target"]["t*"] * c for c in lv["target"]["u"]]
        if "eta" not in lv: break
        D = level_data(M, ys, w, N); assert D["x"] == lv["x"]
        if "z" in lv: assert D["z"] == lv["z"]
        res.append(D)
    return st, tr, res
def check_level(D):
    """asserts Lemma R, P, RP on one failing level; returns the RP slack of the tightest failing row."""
    assert D["fail"]; n = D["n"]; zz = D["zz"]; best = None
    assert D["gsc"][-1] == D["delta"]                                       # Lemma P
    assert D["P"] <= 2 ** n - 2                                             # LLL profile
    for r in D["rows"]:
        if not r["fail"]: continue
        assert r["eta"] < abs(r["Me"]) <= r["A"]                            # Lemma R
        Mz = dot(r["M"], D["z"]) if len(r["M"]) == len(D["z"]) else None
        rest2 = r["pi2"] - F(Mz) ** 2 / zz; assert rest2 >= 0
        # RP:  eta < |delta||Mz|/zz + (1/2) sqrt((2^n-2)/zz) sqrt(rest2)   <=>  (eta - |delta||Mz|/zz) < (1/2) sqrt(((2^n-2)/zz) rest2)   (exact, squared when lhs >= 0)
        lhs = r["eta"] - abs(D["delta"]) * abs(Mz) / zz
        assert lhs < 0 or 4 * lhs * lhs < F(2 ** n - 2) / zz * rest2
        sl = (F(2 ** n - 2) / zz * rest2) / (4 * lhs * lhs) if lhs > 0 else None   # > 1 by RP; how close to 1 = how tight
        best = sl if best is None or (sl is not None and sl < best) else best
    return best
