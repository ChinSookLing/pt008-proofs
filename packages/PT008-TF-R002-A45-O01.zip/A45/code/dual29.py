# A29: the penultimate Babai coefficient (C52) and the link between the level-1 dual pair (z, q) and the chain (z1, z2).
# Level data are replayed exactly as in BD-v19 F3/F4 (row28.level_data logic), now also returning the LLL basis B and its integer dual basis D.
#   Lemma P2 (C52):  c_{n-1} = (y*.q + mu*delta) - rnd(y*.q + mu*delta),  q = D_{n-1}, mu = mu_{n,n-1}, delta = c_n  (Lemma P);  b*_{n-1}/|b*_{n-1}|^2 = q + mu z.
#   Lemma DE (level 1): sum z1 and sum q both even  =>  c_n = c_{n-1} = 0  =>  e in span(b*_1, b*_2)  =>  a level-1 failure needs |z1|^2 < 27.
#   Intrinsic form: Q = Z z + Z q = Rel(U) cap span(b_1, b_2)^perp ; DE <=> the parity map y -> sum(y) mod 2 vanishes on Q.
#   Chain form: Q_chain = Lb3^perp = Z z1 + Z x2 (Lb4 x2 = z2) ; chain-DE <=> sum z1 and sum x2 even (well defined once sum z1 is even).
#   Link question: does Q = Q_chain (<=> Lb4 q = +-z2) for real descents?
from fractions import Fraction as F
import bd19
from bd19 import dot, relations18, inv, gso
import lll19 as _lll
from a02_lib import dist
def level1_dual(U, N=6, ystar=None, M=None):
    d = len(U); w = list(U); ystar = ystar or [F(1, 2)] * d
    Rb = relations18(w); n_ = len(Rb)
    Gi = inv([[F(dot(a, b)) for b in Rb] for a in Rb])
    B = [[sum(Gi[i][k] * Rb[k][c] for k in range(n_)) for c in range(d)] for i in range(n_)]
    B = _lll.lll(B); Bs = gso(B)
    ww = F(dot(w, w)); T = [y - dot(ystar, w) / ww * wi for y, wi in zip(ystar, w)]
    e = T[:]
    for i in range(n_ - 1, -1, -1):
        c = round(dot(e, Bs[i]) / dot(Bs[i], Bs[i])); e = [a - c * b for a, b in zip(e, B[i])]
    gsc = [dot(e, b) / dot(b, b) for b in Bs]
    x = [a - b for a, b in zip(ystar, e)]; fail = any(dist(v) < F(1, N) for v in x) if M is None else any(dist(dot(Mi, x)) < F(1, N) for Mi in M)
    Gd = inv([[dot(a, b) for b in B] for a in B]); D = [[sum(Gd[i][k] * B[k][c] for k in range(n_)) for c in range(d)] for i in range(n_)]
    assert all(v.denominator == 1 for r in D for v in r); D = [[int(v) for v in r] for r in D]
    assert all(dot(r, w) == 0 for r in D)
    z = D[-1]
    assert [F(v) for v in z] == [v / dot(Bs[-1], Bs[-1]) for v in Bs[-1]]
    yz = dot(ystar, z); delta = yz - round(yz); assert gsc[-1] == delta                              # Lemma P
    if n_ < 2: return {"z": z, "fail": fail, "delta": delta}
    q = D[-2]
    mu = dot(B[-1], Bs[-2]) / dot(Bs[-2], Bs[-2]); zz = dot(z, z)
    assert [v / dot(Bs[-2], Bs[-2]) for v in Bs[-2]] == [a + mu * b for a, b in zip(q, z)]          # b*_{n-1}/|b*_{n-1}|^2 = q + mu z
    a = dot(ystar, q) + mu * delta; assert gsc[-2] == a - round(a)                                   # Lemma P2
    de = sum(z) % 2 == 0 and sum(q) % 2 == 0
    if M is None and de: assert gsc[-1] == 0 and gsc[-2] == 0
    P12 = sum(dot(b, b) for b in Bs[:-2]) * zz; assert P12 <= 2 ** n_ - 4
    return {"z": z, "q": q, "mu": mu, "delta": delta, "c3": gsc[-2], "gsc": gsc, "fail": fail, "de": de, "zz": zz, "P12": P12, "x": x, "B": B}
def egcd(a, b):
    if b == 0: return (a, 1, 0) if a >= 0 else (-a, -1, 0)
    g, x, y = egcd(b, a % b); return g, y, x - (a // b) * y
def finv(M):          # exact inverse of a unimodular integer matrix
    n = len(M); A = [[F(x) for x in r] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0); A[c], A[p] = A[p], A[c]
        pv = A[c][c]; A[c] = [x / pv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c]; A[r] = [a - f * b for a, b in zip(A[r], A[c])]
    out = [[x for x in r[n:]] for r in A]; assert all(x.denominator == 1 for r in out for x in r); return [[int(x) for x in r] for r in out]
def unit_vec(c):
    g, acc = c[0], [1] + [0] * (len(c) - 1)
    for i in range(1, len(c)):
        g2, xx, yy = egcd(g, c[i]); acc = [xx * t for t in acc]; acc[i] = yy; g = g2
    if g < 0: acc = [-t for t in acc]
    assert dot(acc, c) == 1; return acc
def preimage(Lb4, z1, z2):
    """an integer x2 with Lb4 x2 = z2 (via the unimodular completion [Lb4; e], e.z1 = 1)."""
    Mi = finv([list(r) for r in Lb4] + [unit_vec(z1)]); x2 = [sum(Mi[r][c] * (z2[c] if c < 4 else 0) for c in range(5)) for r in range(5)]
    assert [dot(r, x2) for r in Lb4] == list(z2); return x2
