# A28: where the tightening stalls, on replayable real level-1 descents of BD-v19 (original rule, G1 on: these inputs fail G1).
# For each failing row i:  1/3 = eta_i < |e_i| <= A'_i <= C_i <= L_i   with
#   A'_i = |delta||z_i|/s + (1/2) sum_{j<4} |<e_i, b*_j>|                  (Babai coefficients replaced by +-1/2)
#   C_i  = |delta||z_i|/s + (1/2) sqrt(P/s) sqrt(rest2_i)                   (Cauchy-Schwarz, actual profile P)
#   L_i  = |delta||z_i|/s + (1/2) sqrt(14/s) sqrt(rest2_i)                  (LLL profile cap 2^4 - 2 = 14)  = Lemma RP
import sys
from fractions import Fraction as F
from math import sqrt
from row28 import levels_of_run
import bd19
for U in ([2, 5, 6, 28, 41], [1, 8, 14, 18, 20], [5, 8, 24, 26, 30], [2, 4, 7, 20, 30], [1, 6, 18, 24, 30]):
    st, tr, res = levels_of_run(U); D = res[0]; s = D["zz"]; z = D["z"]
    print("U = %s : BD-v19 %s (%s) ; G1 %s ; level 1: z1 = %s, |z1|^2 = %d, delta = %s, Babai GS coefficients %s" %
          (U, st, tr["end"], bd19.farey_gate(U, 6), z, s, D["delta"], [str(c) for c in D["gsc"]]))
    prof = [float(sum(v * v for v in b) * s) for b in D["Bs"]]
    print("   profile |b*_j|^2 * |z1|^2 = %s  (LLL caps 8, 4, 2, 1) ; P = %.4f (cap 14)" % ([round(p, 4) for p in prof], float(D["P"])))
    uu = sum(u * u for u in U)
    for i, r in enumerate(D["rows"]):
        if not r["fail"]: continue
        rest2 = float(r["pi2"]) - z[i] ** 2 / s; dz = abs(float(D["delta"])) * abs(z[i]) / s
        Ap = dz + sum(abs(float(b[i])) for b in D["Bs"][:-1]) / 2
        Ci = dz + 0.5 * sqrt(float(D["P"]) / s * rest2); Li = dz + 0.5 * sqrt(14 / s * rest2)
        print("   failing row %d (u = %d, z_i = %d): ||x_i|| = %.4f ; eta = 1/3 < |e_i| = %.4f <= A' = %.4f <= C = %.4f <= L = %.4f" %
              (i + 1, U[i], z[i], float(min(r["Me"] % 1, 1 - r["Me"] % 1)) if False else float(abs(F(1, 2) - abs(r["Me"]))), float(abs(r["Me"])), Ap, Ci, Li))
    # bounds on s each stage would give if the stage were the only loss (Cauchy over rows, delta averaged out): 9(1+P)/4
    print("   bound on |z1|^2 from the actual profile alone: 9(1+P)/4 = %.2f ; from the LLL cap: 135/4 = 33.75 ; actual %d" % (9 * (1 + float(D["P"])) / 4, s))
    if len(res) > 1: print("   later levels: " + ", ".join("d=%d |z|^2=%s fail=%s" % (E["d"], E.get("zz"), E["fail"]) for E in res[1:]))
