# A27 (TEST, sampling): search for TOP-RANK1 inputs (and double failures) at rank-2 nodes OUTSIDE C(12,12,80).
# Region R1: 12 < |z1|^2 <= 135/4, then z2, z3 uniformly among the cone-admissible relations inside DESC'.
# Region R2: |z1|^2 <= 12, 12 < |z2|^2 <= cap2, z3 inside DESC'.
# Region R3: |z1|^2, |z2|^2 <= 12, 80 < |z3|^2 <= cap3, prefixes outside the saturated set S of A26 (weighted by their beyond-80 node counts).
# At each sampled node every primitive in-sector w with K1 failure and exact rank-2 failure is replayed with the original BD-v19;
# TOP-RANK1 runs are recorded with their TRUE chain norms and the H6 readout (none = double failure witness).
import sys, random, json, time
region = sys.argv[1]; secs = float(sys.argv[2]); seed = int(sys.argv[3]) if len(sys.argv) > 3 else 27
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "cert"]
import class25 as C
import numpy as np
from fractions import Fraction as F
from collections import Counter
from bd19 import F19, dot
from explore27_lib import rank2_fail_leaves, h6first
rng = random.Random(seed)
Z1all = [z for z in C.prim_np(5, F(135, 4)).tolist() if C.suffix_mixed(z)]
Z1in = [z for z in Z1all if dot(z, z) <= 12]; Z1out = [z for z in Z1all if dot(z, z) > 12]
PREF = json.load(open("caps26_prefixes.json")); srt = sorted(PREF, key=lambda p: p[3]); S = set(); cum = 0
for p in srt:
    if cum + p[3] > 2000000: break
    cum += p[3]; S.add((tuple(p[0]), tuple(p[1])))
OPEN3 = [p for p in PREF if (tuple(p[0]), tuple(p[1])) not in S and p[3] > 0]; W3 = [p[3] for p in OPEN3]
def pick(arr): return arr[rng.randrange(len(arr))].tolist()
def node():
    if region == "R3":
        z1, z2, c3s, nb = rng.choices(OPEN3, weights=W3)[0]
        Lb4 = C.sub(C.I, z1); Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3); y3, e3, m3 = C.coinc(M3)
        Z3 = C.prim_np(3, F(3 * m3) / (4 * e3 * e3)); Z3 = Z3[(Z3 * Z3).sum(1) > 80]; Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
        return z1, z2, pick(Z3), Lb3
    z1 = rng.choice(Z1out if region == "R1" else Z1in)
    Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): return None
    y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, F(7 * m4) / (4 * e4 * e4))
    if region == "R2": Z2 = Z2[(Z2 * Z2).sum(1) > 12]
    Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    if not len(Z2): return None
    z2 = pick(Z2); Lb3 = C.sub(Lb4, z2); M3 = C.forms(Lb3)
    if any(not any(r) for r in M3): return None
    y3, e3, m3 = C.coinc(M3); Z3 = C.prim_np(3, F(3 * m3) / (4 * e3 * e3)); Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
    if not len(Z3): return None
    return z1, z2, pick(Z3), Lb3
t0 = time.time(); nodes = 0; leaves = 0; top = {}; dbl = []; other = Counter()
while time.time() - t0 < secs:
    r = node()
    if r is None: continue
    z1, z2, z3, Lb3 = r; M2 = C.forms(C.sub(Lb3, z3))
    if any(not any(x) for x in M2): continue
    ys, eta, mu2 = C.coinc(M2); nodes += 1
    for U in rank2_fail_leaves(M2, ys, eta, mu2)[0]:
        leaves += 1; st, t, tr = F19(6, list(U))
        if st == "UNFINISHED":
            zs = [lv["z"] for lv in tr["levels"]]; n = [dot(z, z) for z in zs[:3]]; h = h6first(list(U))
            top[U] = (n, h[0] if h else None, str(h[1]) if h else None, (z1, z2, z3))
            if h is None: dbl.append((U, zs))
        else: other[tr["end"][:16]] += 1
inside = sum(1 for v in top.values() if v[0][0] <= 12 and v[0][1] <= 12 and v[0][2] <= 80)
print("region %s seed %d: sampled rank-2 nodes %d ; K1-failing rank-2-failing leaves replayed %d ; non-exception outcomes %s" % (region, seed, nodes, leaves, dict(other)))
print("  TOP-RANK1 distinct %d (true chain inside C(12,12,80): %d, outside: %d) ; H6 first q %s ; DOUBLE FAILURES %d %s"
      % (len(top), inside, len(top) - inside, dict(Counter(v[1] for v in top.values())), len(dbl), dbl[:3]))
json.dump([[list(k), v[0], v[1], v[2], v[3]] for k, v in top.items()], open("outside27_%s_s%d.json" % (region, seed), "w"))
