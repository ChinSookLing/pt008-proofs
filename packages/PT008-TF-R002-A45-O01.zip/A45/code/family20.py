# A20 TEST: search for further N = 6 rank-1 exceptions inside the rank-2 lattices where the known exceptions end, and check the residue rules on them.
# For every top-level exception U0 in the box (scan20 json), take the rank-2 basis of its last level, enumerate primitive w with |w|_inf <= R,
# normalise U = sorted distinct |M w|, run the rule BD-v19, collect the exceptions, then apply H6 (missing-class q = 7..12, forbidden set q = 13..18).
import json, sys, time
from math import gcd
from multiprocessing import Pool
from bd19 import F19
from br20 import mc_select, br_select, kq
N = 6; R = int(sys.argv[2]) if len(sys.argv) > 2 else 25
def bases():
    out = set()
    for row in json.load(open(sys.argv[1])):
        U0 = row[0] if isinstance(row[0], list) else row
        st, t, tr = F19(N, U0); out.add(tuple(map(tuple, tr["levels"][-1]["basis"])))
    return sorted(out)
def job(B):
    found = []
    for p in range(-R, R + 1):
        for q in range(-R, R + 1):
            if gcd(p, q) != 1: continue
            V = [p * a + q * b for a, b in zip(*B)]
            if 0 in V: continue
            U = sorted({abs(v) for v in V})
            g = 0
            for u in U: g = gcd(g, u)
            U = [u // g for u in U]
            if len(U) != 5: continue
            st, t, tr = F19(N, U)
            if st == "UNFINISHED": found.append(tuple(U))
    return found
def h6(U):
    for q in range(N + 1, 3 * N + 1):
        t = mc_select(U, q, N) if kq(q, N) == 1 else br_select(U, q, N)
        if t is not None: return q, t
    return None
if __name__ == "__main__":
    t0 = time.time(); Bs = bases(); allx = set()
    with Pool(2) as pl:
        for f in pl.imap_unordered(job, Bs): allx.update(f)
    allx = sorted(allx); unc = [U for U in allx if h6(U) is None]
    hist = {}
    for U in allx:
        h = h6(U); k = h[0] if h else None; hist[k] = hist.get(k, 0) + 1
    print("rank-2 lattices of the box exceptions: %d ; |w|_inf <= %d ; distinct exceptions found: %d (max entry %d) ; H6 first q: %s ; NOT covered by q <= 18: %d %s  (%.0fs)"
          % (len(Bs), R, len(allx), max(max(U) for U in allx), dict(sorted(hist.items(), key=lambda kv: (kv[0] is None, kv[0] or 0))), len(unc), unc[:20], time.time() - t0))
    json.dump([list(U) for U in allx], open("family20_%s_R%d.json" % (sys.argv[3] if len(sys.argv) > 3 else "r1", R), "w"))
