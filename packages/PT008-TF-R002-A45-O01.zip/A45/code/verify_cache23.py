# A23 task 1: node-by-node check of the C40 kernel cache on the complete small class C(6,6,17):
# at every descent the cached sub() must return exactly the original sub() basis (same rows, same order, same signs), and every rank-2 node must give
# identical (y*, eta, mu^2) and an identical rank-2-failure count from the leaf routine.
import sys
sys.argv = ["x", "-1", "6", "-1", "6", "-1", "17", "cert"]
import class23 as C
from fractions import Fraction as F
calls = 0; diff = 0; nodes = 0; ndiff = 0
def both(Lb, z):
    global calls, diff
    a = C.sub_orig(Lb, z); b = C.sub_cached(Lb, z); calls += 1; diff += (a != b); return a
for z1 in [z for z in C.prim_np(5, F(6)).tolist() if C.suffix_mixed(z)]:
    Lb4 = both(C.I, z1); M4 = C.forms(Lb4)
    if any(not any(r) for r in M4): continue
    y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, min(F(6), F(7 * m4) / (4 * e4 * e4))); Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
    for z2 in Z2.tolist():
        Lb3 = both(Lb4, z2); M3 = C.forms(Lb3)
        if any(not any(r) for r in M3): continue
        y3, e3, m3 = C.coinc(M3); Z3 = C.prim_np(3, min(F(17), F(3 * m3) / (4 * e3 * e3))); Z3 = Z3[C.cone_ok(Z3, C.rays(C.diffrows(M3)))]
        for z3 in Z3.tolist():
            a = C.sub_orig(Lb3, z3); b = C.sub_cached(Lb3, z3); calls += 1; diff += (a != b)
            Ma, Mb = C.forms(a), C.forms(b)
            if any(not any(r) for r in Ma): continue
            nodes += 1; ra = C.coinc(Ma); rb = C.coinc(Mb)
            sa = {k: 0 for k in ("in_sector", "K1_miss", "rank2_fails", "H6_miss", "known_hit", "node_closed_sector", "node_closed_K1", "node_closed_rank2", "node_closed_H6", "node_closed_replay")}
            sb = dict(sa); C.leaves(Ma, *ra, sa); C.leaves(Mb, *rb, sb)
            ndiff += (ra != rb) or (sa["rank2_fails"] != sb["rank2_fails"]) or (sa["K1_miss"] != sb["K1_miss"])
print("C(6,6,17): sub() calls %d, cached basis != original basis: %d ; rank-2 nodes %d, nodes with different (y*, eta, mu^2) or leaf counts: %d ; distinct cached kernel keys %d"
      % (calls, diff, nodes, ndiff, C.relation_kernel.cache_info().currsize))
