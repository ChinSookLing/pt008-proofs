import Mathlib
/-!
PT008-TF-R002 · A45 · Opus independent formalisation of the "safe polygon" time rule (review aid, not a submission).
U = a p + b q,  ℓ_i(x,y) = p_i x + q_i y,  h(x,y) = b x - a y,  α a + β b = 1.
* `orbit_point`   : b x - a y = n ∈ ℤ  ⇒  (x, y) = t (a, b) + n (β, -α),  t = α x + β y.
* `band_safe`     : k + 1/6 ≤ v ≤ k + 5/6  ⇒  v is 1/6-safe (end points included).
* `poly_time_safe`: a point of the band intersection with h ∈ ℤ gives a safe time t - r for every integer r ("t mod 1").
* `interp_point`  : the interpolated point X = X₋ + λ(X₊ - X₋) stays in every band and in the unit square, and h X = j.
* `hit_of_ceil`   : ⌈m⌉ ≤ M with m, M attained at points of P  ⇒  P contains a point with h ∈ ℤ (covers m = M).
* `ceil_of_hit`   : a point of P with h ∈ ℤ and m ≤ h ≤ M on P  ⇒  ⌈m⌉ ≤ M.
* `complete`      : if U has ANY 1/6-safe time, then some band intersection P_k ⊂ [0,1]² contains a point with h ∈ ℤ.
-/
namespace PT008A45

/-- `v` is `θ`-safe: distance from every integer at least θ (non-strict). -/
def Safe (θ v : ℝ) : Prop := ∀ m : ℤ, θ ≤ |v - m|

theorem safe_shift {θ v : ℝ} (z : ℤ) (h : Safe θ v) : Safe θ (v + z) := by
  intro m
  have := h (m - z)
  push_cast at this
  have e : v + (z:ℝ) - m = v - ((m:ℝ) - z) := by ring
  rw [e]; exact this

theorem orbit_point (a b α β n : ℤ) (x y : ℝ) (hab : α * a + β * b = 1)
    (hn : (b:ℝ) * x - (a:ℝ) * y = n) :
    x = ((α:ℝ) * x + (β:ℝ) * y) * a + (n:ℝ) * β ∧ y = ((α:ℝ) * x + (β:ℝ) * y) * b - (n:ℝ) * α := by
  have habR : (α:ℝ) * a + (β:ℝ) * b = 1 := by exact_mod_cast hab
  constructor
  · rw [← hn]; linear_combination (-x) * habR
  · rw [← hn]; linear_combination (-y) * habR

theorem band_safe (k : ℤ) (v : ℝ) (h1 : (k:ℝ) + 1/6 ≤ v) (h2 : v ≤ (k:ℝ) + 5/6) : Safe (1/6) v := by
  intro m
  rcases le_or_lt m k with hm | hm
  · have : (m:ℝ) ≤ k := by exact_mod_cast hm
    rw [abs_of_nonneg (by linarith)]; linarith
  · have : (k:ℝ) + 1 ≤ m := by exact_mod_cast hm
    rw [abs_of_nonpos (by linarith)]; linarith

theorem poly_time_safe {ι : Type*} (p q k : ι → ℤ) (a b α β n : ℤ) (x y : ℝ)
    (hab : α * a + β * b = 1) (hn : (b:ℝ) * x - (a:ℝ) * y = n)
    (hband : ∀ i, (k i:ℝ) + 1/6 ≤ (p i:ℝ) * x + (q i:ℝ) * y ∧ (p i:ℝ) * x + (q i:ℝ) * y ≤ (k i:ℝ) + 5/6)
    (r : ℤ) :
    ∀ i, Safe (1/6) (((a * p i + b * q i : ℤ) : ℝ) * (((α:ℝ) * x + (β:ℝ) * y) - r)) := by
  intro i
  obtain ⟨hx, hy⟩ := orbit_point a b α β n x y hab hn
  have hs := band_safe (k i) _ (hband i).1 (hband i).2
  have key : ((a * p i + b * q i : ℤ) : ℝ) * (((α:ℝ) * x + (β:ℝ) * y) - r)
      = ((p i:ℝ) * x + (q i:ℝ) * y) + ((-(p i) * n * β + q i * n * α - (a * p i + b * q i) * r : ℤ) : ℝ) := by
    push_cast
    have e1 : (p i:ℝ) * x = (p i:ℝ) * ((((α:ℝ) * x + (β:ℝ) * y) * a + (n:ℝ) * β)) := by rw [← hx]
    have e2 : (q i:ℝ) * y = (q i:ℝ) * ((((α:ℝ) * x + (β:ℝ) * y) * b - (n:ℝ) * α)) := by rw [← hy]
    rw [e1, e2]; ring
  rw [key]; exact safe_shift _ hs

/-- membership in the band intersection P_k inside the closed unit square -/
def InP {ι : Type*} (p q k : ι → ℤ) (x y : ℝ) : Prop :=
  (∀ i, (k i:ℝ) + 1/6 ≤ (p i:ℝ) * x + (q i:ℝ) * y ∧ (p i:ℝ) * x + (q i:ℝ) * y ≤ (k i:ℝ) + 5/6) ∧
  0 ≤ x ∧ x ≤ 1 ∧ 0 ≤ y ∧ y ≤ 1

/-- every defining constraint of P_k is a closed half-plane, so P_k is convex -/
theorem inP_convex {ι : Type*} (p q k : ι → ℤ) (x₁ y₁ x₂ y₂ c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (h₁ : InP p q k x₁ y₁) (h₂ : InP p q k x₂ y₂) :
    InP p q k (x₁ + c * (x₂ - x₁)) (y₁ + c * (y₂ - y₁)) := by
  obtain ⟨b₁, sx₁, sx₁', sy₁, sy₁'⟩ := h₁
  obtain ⟨b₂, sx₂, sx₂', sy₂, sy₂'⟩ := h₂
  have hc' : 0 ≤ 1 - c := by linarith
  refine ⟨fun i => ?_, ?_, ?_, ?_, ?_⟩
  · obtain ⟨l₁, u₁⟩ := b₁ i; obtain ⟨l₂, u₂⟩ := b₂ i
    have e : (p i:ℝ) * (x₁ + c * (x₂ - x₁)) + (q i:ℝ) * (y₁ + c * (y₂ - y₁))
        = (1 - c) * ((p i:ℝ) * x₁ + (q i:ℝ) * y₁) + c * ((p i:ℝ) * x₂ + (q i:ℝ) * y₂) := by ring
    rw [e]; constructor <;> nlinarith
  all_goals nlinarith

/-- the interpolation step of the rule -/
theorem interp_point {ι : Type*} (p q k : ι → ℤ) (a b : ℤ) (x₁ y₁ x₂ y₂ : ℝ) (j : ℤ)
    (h₁ : InP p q k x₁ y₁) (h₂ : InP p q k x₂ y₂)
    (hlt : (b:ℝ) * x₁ - (a:ℝ) * y₁ < (b:ℝ) * x₂ - (a:ℝ) * y₂)
    (hj1 : (b:ℝ) * x₁ - (a:ℝ) * y₁ ≤ j) (hj2 : (j:ℝ) ≤ (b:ℝ) * x₂ - (a:ℝ) * y₂) :
    let c := ((j:ℝ) - ((b:ℝ) * x₁ - (a:ℝ) * y₁)) / (((b:ℝ) * x₂ - (a:ℝ) * y₂) - ((b:ℝ) * x₁ - (a:ℝ) * y₁))
    InP p q k (x₁ + c * (x₂ - x₁)) (y₁ + c * (y₂ - y₁)) ∧
      (b:ℝ) * (x₁ + c * (x₂ - x₁)) - (a:ℝ) * (y₁ + c * (y₂ - y₁)) = j := by
  intro c
  have hd : 0 < ((b:ℝ) * x₂ - (a:ℝ) * y₂) - ((b:ℝ) * x₁ - (a:ℝ) * y₁) := by linarith
  have hc0 : 0 ≤ c := div_nonneg (by linarith) hd.le
  have hc1 : c ≤ 1 := (div_le_one hd).2 (by linarith)
  refine ⟨inP_convex p q k x₁ y₁ x₂ y₂ c hc0 hc1 h₁ h₂, ?_⟩
  have hcd : c * (((b:ℝ) * x₂ - (a:ℝ) * y₂) - ((b:ℝ) * x₁ - (a:ℝ) * y₁)) = (j:ℝ) - ((b:ℝ) * x₁ - (a:ℝ) * y₁) := by
    simp only [c]; field_simp
  linear_combination hcd

/-- ⌈m⌉ ≤ M (with m, M attained in P) gives a point of P on the orbit; covers m = M -/
theorem hit_of_ceil {ι : Type*} (p q k : ι → ℤ) (a b : ℤ) (x₁ y₁ x₂ y₂ : ℝ)
    (h₁ : InP p q k x₁ y₁) (h₂ : InP p q k x₂ y₂)
    (hle : (b:ℝ) * x₁ - (a:ℝ) * y₁ ≤ (b:ℝ) * x₂ - (a:ℝ) * y₂)
    (hceil : ((⌈(b:ℝ) * x₁ - (a:ℝ) * y₁⌉ : ℤ) : ℝ) ≤ (b:ℝ) * x₂ - (a:ℝ) * y₂) :
    ∃ x y : ℝ, InP p q k x y ∧ ∃ n : ℤ, (b:ℝ) * x - (a:ℝ) * y = n := by
  set j : ℤ := ⌈(b:ℝ) * x₁ - (a:ℝ) * y₁⌉
  have hj1 : (b:ℝ) * x₁ - (a:ℝ) * y₁ ≤ j := Int.le_ceil _
  rcases hle.lt_or_eq with hlt | heq
  · obtain ⟨hin, hh⟩ := interp_point p q k a b x₁ y₁ x₂ y₂ j h₁ h₂ hlt hj1 hceil
    exact ⟨_, _, hin, j, hh⟩
  · -- m = M: then j = m, X = X₋
    refine ⟨x₁, y₁, h₁, j, le_antisymm hj1 (by rw [heq]; exact hceil)⟩

/-- conversely, an orbit point in P forces ⌈m⌉ ≤ M -/
theorem ceil_of_hit (m M v : ℝ) (n : ℤ) (hm : m ≤ v) (hM : v ≤ M) (hv : v = n) : ((⌈m⌉ : ℤ) : ℝ) ≤ M := by
  have : ⌈m⌉ ≤ n := Int.ceil_le.2 (by rw [← hv]; exact hm)
  have : ((⌈m⌉ : ℤ) : ℝ) ≤ n := by exact_mod_cast this
  linarith

/-- completeness: any safe time puts a point of some P_k (k_i = ⌊ℓ_i⌋) on the orbit -/
theorem complete {ι : Type*} (p q : ι → ℤ) (a b : ℤ) (t : ℝ)
    (hsafe : ∀ i, Safe (1/6) (((a * p i + b * q i : ℤ) : ℝ) * t)) :
    ∃ x y : ℝ, ∃ k : ι → ℤ, InP p q k x y ∧ ∃ n : ℤ, (b:ℝ) * x - (a:ℝ) * y = n := by
  set x := Int.fract ((a:ℝ) * t)
  set y := Int.fract ((b:ℝ) * t)
  have hℓ : ∀ i, Safe (1/6) ((p i:ℝ) * x + (q i:ℝ) * y) := by
    intro i
    have e : (p i:ℝ) * x + (q i:ℝ) * y
        = ((a * p i + b * q i : ℤ) : ℝ) * t + ((-(p i) * ⌊(a:ℝ) * t⌋ - q i * ⌊(b:ℝ) * t⌋ : ℤ) : ℝ) := by
      simp only [x, y, Int.fract]; push_cast; ring
    rw [e]; exact safe_shift _ (hsafe i)
  refine ⟨x, y, fun i => ⌊(p i:ℝ) * x + (q i:ℝ) * y⌋, ⟨fun i => ?_, ?_, ?_, ?_, ?_⟩,
    a * ⌊(b:ℝ) * t⌋ - b * ⌊(a:ℝ) * t⌋, ?_⟩
  · have h0 := hℓ i ⌊(p i:ℝ) * x + (q i:ℝ) * y⌋
    have h1 := hℓ i (⌊(p i:ℝ) * x + (q i:ℝ) * y⌋ + 1)
    have f0 := Int.floor_le ((p i:ℝ) * x + (q i:ℝ) * y)
    have f1 := Int.lt_floor_add_one ((p i:ℝ) * x + (q i:ℝ) * y)
    rw [abs_of_nonneg (by linarith)] at h0
    push_cast at h1
    rw [abs_of_neg (by linarith)] at h1
    constructor <;> linarith
  · exact Int.fract_nonneg _
  · exact (Int.fract_lt_one _).le
  · exact Int.fract_nonneg _
  · exact (Int.fract_lt_one _).le
  · simp only [x, y, Int.fract]; push_cast; ring

#print axioms orbit_point
#print axioms poly_time_safe
#print axioms interp_point
#print axioms hit_of_ceil
#print axioms ceil_of_hit
#print axioms complete

end PT008A45
