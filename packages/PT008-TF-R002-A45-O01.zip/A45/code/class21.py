# A21 closure certificate for a CLASS of N = 6 nodes (m = 5), or a counterexample.
# Class C(c1, c2, c3): BD-v19 chains z1 -> z2 -> z3 (levels d = 5, 4, 3) with |z_i|^2 <= c_i, inside the DESC' bounds, passing the cone tests
# (CN1 in R^5; CN2 in R^4 and R^3: the next kernel must meet the open cone of strictly increasing positive inputs).
# For every rank-2 node of the class, every primitive w in the open sector with the exact rank-2 failure (C32: implies D <= mu^2/(4 eta^2)) and K1 failure
# is checked against H6 (q = 7..18, Lemma BR).  An H6 miss is replayed with the full rule: a TOP-RANK1 run would be a counterexample.
# Claim certified when the run ends with 0 counterexamples: every input whose BD-v19 run is TOP-RANK1 with chain in C(c1,c2,c3) gets a time from H6.
import sys, time, itertools, json
import numpy as np
from fractions import Fraction as F
from math import gcd, isqrt
from multiprocessing import Pool
from bd19 import F18, F19, relations18, dot
import dclose
from a02_lib import dist
from cone19 import suffix_mixed, diffrows
from util21 import prim_np, rays, cone_ok
from br20 import mc_select, br_select, kq
N = 6; m = 5
c1, c2, c3 = (F(x) for x in sys.argv[1:4])
I = [[int(i == j) for j in range(m)] for i in range(m)]
KNOWN = {tuple(r[0]) for r in json.load(open('union20.json'))}
def sub(Lb, z):
    K = relations18(z); d = len(Lb); return [[sum(c[j] * Lb[j][i] for j in range(d)) for i in range(m)] for c in K]
def forms(Lb): d = len(Lb); return [[Lb[j][i] for j in range(d)] for i in range(m)]
def coinc(M):
    u, s, _ = dclose.coincidence_line(M); sd = sorted({abs(x) for x in s}); st, ts, _ = F18(len(sd) + 1, sd); assert st == "SAFE"
    ys = [ts * c for c in u]; eta = min(dist(dot(Mi, ys)) for Mi in M) - F(1, N); assert eta > 0
    return ys, eta, max(dot(r, r) for r in M)
def h6(U):
    for q in range(N + 1, 3 * N + 1):
        t = mc_select(U, q, N) if kq(q, N) == 1 else br_select(U, q, N)
        if t is not None: return q
    return None
def leaves(M2, ys, eta, mu2, st):
    """rank-2 node: all primitive w in the open sector, exact rank-2 failure, K1 failure; H6 on the survivors; replay of H6 misses."""
    from math import lcm
    H = lcm(ys[0].denominator, ys[1].denominator); Y = [int(y * H) for y in ys]
    Dmax = mu2 / (4 * eta * eta); R = isqrt(int(Dmax))
    ax = np.arange(-R, R + 1); P, Q = np.meshgrid(ax, ax, indexing="ij"); P = P.ravel(); Q = Q.ravel()
    D = P * P + Q * Q; keep = (D > 0) & (D * 4 * eta.numerator ** 2 <= mu2 * eta.denominator ** 2)
    A = np.array(diffrows(M2), dtype=np.int64); Mn = np.array(M2, dtype=np.int64)
    W = np.stack([P, Q], 1)
    keep &= np.all(W @ A.T > 0, axis=1); keep &= np.gcd(P, Q) == 1
    P, Q, D = P[keep], Q[keep], D[keep]; st["in_sector"] += len(P)
    if len(P) == 0: st["node_closed_sector"] += 1; return []
    U = (Mn @ np.stack([P, Q])).T
    k1 = np.any(U % 4 == 0, 1) & np.any(U % 5 == 0, 1) & np.any(U % 6 == 0, 1)
    P, Q, D, U = P[k1], Q[k1], D[k1], U[k1]; st["K1_miss"] += len(P)
    if len(P) == 0: st["node_closed_K1"] += 1; return []
    Zn = -Q * Y[0] + P * Y[1]; r0 = np.floor_divide(Zn, H); rem = Zn - H * r0
    r = r0 + (2 * rem > H) + ((2 * rem == H) & (r0 % 2 != 0)); dH = Zn - H * r
    nz = dH != 0; P, Q, D, U, dH = P[nz], Q[nz], D[nz], U[nz], dH[nz]
    fail = np.zeros(len(P), dtype=bool)
    for i in range(m):
        c = -Mn[i, 0] * Q + Mn[i, 1] * P; MY = int(Mn[i, 0]) * Y[0] + int(Mn[i, 1]) * Y[1]
        num = D * MY - dH * c; den = H * D; s = np.mod(num, den); dd = np.minimum(s, den - s)
        fail |= 6 * dd < den
    st["rank2_fails"] += int(fail.sum()); out = []
    if not fail.any(): st["node_closed_rank2"] += 1; return []
    miss0 = st["H6_miss"]
    for u in U[fail].tolist():
        if tuple(u) in KNOWN: st["known_hit"] += 1; st.setdefault("_known", set()).add(tuple(u))
        if h6(u) is None:
            st["H6_miss"] += 1
            s_, t_, tr = F19(N, u); st.setdefault("_miss", {})[tuple(u)] = (s_, tr["end"][:20], str(t_))
            if s_ == "UNFINISHED": out.append((u, tr["kind"]))
    if st["H6_miss"] == miss0: st["node_closed_H6"] += 1
    else: st["node_closed_replay"] += 1
    return out
def job(z1):
    st = {k: 0 for k in ("L2_rel", "L2_cone", "L3_rel", "L3_cone", "nodes", "in_sector", "K1_miss", "rank2_fails", "H6_miss", "known_hit", "node_closed_sector", "node_closed_K1", "node_closed_rank2", "node_closed_H6", "node_closed_replay")}; cex = []
    Lb4 = sub(I, z1); M4 = forms(Lb4)
    if any(not any(r) for r in M4): return st, cex
    y4, e4, m4 = coinc(M4); b2 = min(c2, F(7 * m4) / (4 * e4 * e4))
    Z2 = prim_np(4, b2); ok = cone_ok(Z2, rays(diffrows(M4))); st["L2_rel"] += len(Z2); st["L2_cone"] += int(ok.sum())
    for z2 in Z2[ok].tolist():
        Lb3 = sub(Lb4, z2); M3 = forms(Lb3)
        if any(not any(r) for r in M3): continue
        y3, e3, m3 = coinc(M3); b3 = min(c3, F(3 * m3) / (4 * e3 * e3))
        Z3 = prim_np(3, b3); ok3 = cone_ok(Z3, rays(diffrows(M3))); st["L3_rel"] += len(Z3); st["L3_cone"] += int(ok3.sum())
        for z3 in Z3[ok3].tolist():
            Lb2 = sub(Lb3, z3); M2 = forms(Lb2)
            if any(not any(r) for r in M2): continue
            ys, eta, mu2 = coinc(M2); st["nodes"] += 1
            cex += [(u, k, z1, z2, z3) for u, k in leaves(M2, ys, eta, mu2, st)]
    return st, cex
if __name__ == "__main__":
    t0 = time.time()
    R1 = min(c1, F(15) / (4 * (F(1, 2) - F(1, N)) ** 2))
    Z1 = prim_np(5, R1).tolist(); Z1c = [z for z in Z1 if suffix_mixed(z)]
    tot = {"L1_rel": len(Z1), "L1_cone": len(Z1c)}; cex = []; KH = set(); MISS = {}
    with Pool(2) as p:
        for st, cx in p.imap_unordered(job, Z1c):
            for k, v in st.items():
                if k == "_known": KH.update(v)
                elif k == "_miss": MISS.update(v)
                else: tot[k] = tot.get(k, 0) + v
            cex += cx
    tot["known_distinct_hit"] = len(KH); tot["H6_miss_distinct"] = len(MISS)
    from collections import Counter
    tot["H6_miss_outcomes"] = dict(Counter(v[1] for v in MISS.values()))
    json.dump(sorted([list(k), v] for k, v in MISS.items()), open("class21_%s_%s_%s_H6miss.json" % (c1, c2, c3), "w"))
    print("class C(%s,%s,%s): %s ; counterexamples (TOP-RANK1 with H6 miss): %d %s  (%.0fs)" % (c1, c2, c3, tot, len(cex), cex[:5], time.time() - t0))
    json.dump({"class": [str(c1), str(c2), str(c3)], "counts": tot, "counterexamples": cex}, open("class21_%s_%s_%s.json" % (c1, c2, c3), "w"))
