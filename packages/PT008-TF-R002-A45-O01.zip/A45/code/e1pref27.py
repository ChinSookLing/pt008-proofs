# A27: Lemma SR applied to whole prefixes (z1, z2).  Every input whose TRUE BD-v19 chain starts (z1, z2) lies in Lb3, so Rel(U) contains Lb3^perp = Z z1 + Z x2
# (x2 any integer solution of Lb4 x = z2).  Lemma SR at level 1 (n = 4): |z1|^2 <= 8 lambda_1(Rel(U))^2 <= 8 lambda_1(Lb3^perp)^2.
# Test E1P: |z1|^2 > 8 lambda_1(Z z1 + Z x2)^2  =>  the whole subtree under (z1, z2) contains no input whose true chain starts (z1, z2).  (exact integers)
import sys, json, time
REG = sys.argv[1]
sys.argv = ["x", "-1", "12", "-1", "12", "-1", "80", "count"]
import class25 as C
import numpy as np
from fractions import Fraction as F
from bd19 import dot
from math import gcd
def egcd(a, b):
    if b == 0: return (a, 1, 0) if a >= 0 else (-a, -1, 0)
    g, x, y = egcd(b, a % b); return g, y, x - (a // b) * y
def unit_vec(c):            # e with e.c = 1 (c primitive)
    e = [0] * len(c); g = 0; coef = []
    g, acc = c[0], [1] + [0] * (len(c) - 1)
    for i in range(1, len(c)):
        g2, x, y = egcd(g, c[i]); acc = [x * a for a in acc]; acc[i] = y; g = g2
    if g < 0: acc = [-a for a in acc]; g = -g
    assert g == 1 and dot(acc, c) == 1; return acc
def inv(M):
    n = len(M); A = [[F(x) for x in r] + [F(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0); A[c], A[p] = A[p], A[c]
        pv = A[c][c]; A[c] = [x / pv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c]; A[r] = [a - f * b for a, b in zip(A[r], A[c])]
    return [[int(x) for x in r[n:]] for r in A]
def right_inverse(z1):      # R (5x4 integer) with Lb4 R = I_4, Lb4 = kernel basis of z1 used by the rule
    K = [list(r) for r in C.relation_kernel(tuple(z1))]; e = unit_vec(z1)
    Mi = inv(K + [e]); R = [r[:4] for r in Mi]
    assert all(sum(K[i][k] * R[k][j] for k in range(5)) == int(i == j) for i in range(4) for j in range(4)); return K, np.array(R, dtype=np.int64)
def lag_min(a, B):          # exact lambda_1^2 of Z a + Z b for each row b of B (Lagrange reduction, int64; entries are small)
    A = np.broadcast_to(np.array(a, dtype=np.int64), B.shape).copy(); B = B.copy()
    for _ in range(200):
        aa = (A * A).sum(1); bb = (B * B).sum(1); sw = aa > bb
        A[sw], B[sw] = B[sw].copy(), A[sw].copy(); aa = (A * A).sum(1); ab = (A * B).sum(1)
        k = np.floor_divide(2 * ab + aa, 2 * aa); B = B - k[:, None] * A
        if not k.any(): break
    else: raise RuntimeError("no convergence")
    aa = (A * A).sum(1); bb = (B * B).sum(1); ab = (A * B).sum(1); assert ((2 * np.abs(ab) <= aa) & (aa <= bb)).all()
    return aa
t0 = time.time(); tot = 0; exc = 0; per = {}
if REG in ("R1", "R2", "IN"):
    Z1all = [z for z in C.prim_np(5, F(135, 4)).tolist() if C.suffix_mixed(z)]
    Z1 = [z for z in Z1all if (dot(z, z) > 12) == (REG == "R1")]
    for z1 in Z1:
        Lb4 = C.sub(C.I, z1); M4 = C.forms(Lb4)
        if any(not any(r) for r in M4): continue
        y4, e4, m4 = C.coinc(M4); Z2 = C.prim_np(4, F(7 * m4) / (4 * e4 * e4))
        if REG == "R2": Z2 = Z2[(Z2 * Z2).sum(1) > 12]
        if REG == "IN": Z2 = Z2[(Z2 * Z2).sum(1) <= 12]
        Z2 = Z2[C.cone_ok(Z2, C.rays(C.diffrows(M4)))]
        if not len(Z2): continue
        K, R = right_inverse(z1); X2 = Z2 @ R.T
        assert (X2 @ np.array(K, dtype=np.int64).T == Z2).all()
        l1 = lag_min(z1, X2); bad = dot(z1, z1) > 8 * l1
        tot += len(Z2); exc += int(bad.sum()); per[dot(z1, z1)] = [per.get(dot(z1, z1), [0, 0])[0] + len(Z2), per.get(dot(z1, z1), [0, 0])[1] + int(bad.sum())]
    print("region %s: z1 %d ; cone-admissible prefixes (z1,z2) %d ; excluded by E1P %d (%.2f%%) ; %.0f s" % (REG, len(Z1), tot, exc, 100 * exc / max(tot, 1), time.time() - t0))
    print("  by |z1|^2: " + "  ".join("%d:%d/%d" % (k, v[1], v[0]) for k, v in sorted(per.items())))
else:   # R3: the open beyond-80 prefixes of A26 (outside the saturated set S), weighted by their beyond-80 node counts
    PREF = json.load(open("caps26_prefixes.json")); srt = sorted(PREF, key=lambda p: p[3]); S = set(); cum = 0
    for p in srt:
        if cum + p[3] > 2000000: break
        cum += p[3]; S.add((tuple(p[0]), tuple(p[1])))
    OPEN3 = [p for p in PREF if (tuple(p[0]), tuple(p[1])) not in S and p[3] > 0]
    wt = sum(p[3] for p in OPEN3); we = 0; ne = 0; cache = {}
    for z1, z2, _, nb in OPEN3:
        if tuple(z1) not in cache: cache[tuple(z1)] = right_inverse(z1)
        K, R = cache[tuple(z1)]; x2 = np.array([z2], dtype=np.int64) @ R.T
        if dot(z1, z1) > 8 * int(lag_min(z1, x2)[0]): ne += 1; we += nb
    print("R3 open prefixes %d (beyond-80 nodes %d) ; excluded by E1P: prefixes %d, nodes %d (%.2f%%) ; %.0f s" % (len(OPEN3), wt, ne, we, 100 * we / wt, time.time() - t0))
