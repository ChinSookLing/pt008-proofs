# Theorem 2GC (two-generator closure, s=1).  V = {v_i = A_i b + B_i} (normalised so v_i > 0), forms f_i(y,x) = A_i y + B_i x, x = t, y = b t (mod 1).
# EA1: every component of S(V) has a left endpoint t* with v_i t* = j* + 1/N for some i.  On the line A_i y + B_i x = 1/N (mod 1), branch kappa:
#   y = (1/N + kappa - B_i x)/A_i,  and the curve point at t = (j + 1/N)/v_i lies on branch kappa iff j = kappa (mod |A_i|).
#   Along branch kappa: f_m = A_m (1/N + kappa)/A_i + x (B_m - A_m B_i / A_i)   (affine in x, slope det/A_i).
# Read-out: for each i, kappa, and each closed safe x-arc [xi1, xi2] of the restricted system, take the least j = kappa (mod |A_i|) with
#   (j + 1/N)/v_i >= xi1;  if it is <= xi2 it is safe.  A_i = 0: check the |B_i| anchored times (j + 1/N)/B_i directly.
# Complete: S(V) nonempty  =>  some (i, kappa, arc) returns a safe time.  Work depends only on the coefficients, not on b.
import sys, itertools, random
from fractions import Fraction as F
from math import floor, ceil
from a02_lib import safe, dist
def norm(AB, b):
    out = []
    for A, B in AB:
        v = A * b + B
        if v == 0: continue
        out.append((A, B) if v > 0 else (-A, -B))
    return out
def arcs_affine(const_slope, N):
    """closed safe arcs in x in [0,1) for the 1D affine system {c_m + s_m x} (all must have ||.|| >= 1/N)."""
    pts = {F(0), F(1)}
    for c, s in const_slope:
        if s == 0: continue
        lo = floor(min(c, c + s)) - 1; hi = ceil(max(c, c + s)) + 1
        for k in range(lo, hi + 1):
            for e in (F(1, N), -F(1, N)):
                x = (k + e - c) / s
                if 0 <= x <= 1: pts.add(x)
    pts = sorted(pts)
    ok = lambda x: all(dist(c + s * x) >= F(1, N) for c, s in const_slope)
    arcs, cur = [], None
    for idx, x in enumerate(pts):
        if ok(x):
            cur = [x, x] if cur is None else [cur[0], x]
            if idx + 1 < len(pts) and not ok((x + pts[idx + 1]) / 2): arcs.append(tuple(cur)); cur = None
        elif cur is not None: arcs.append(tuple(cur)); cur = None
    if cur is not None: arcs.append(tuple(cur))
    return arcs
def gc2(AB, b, N):
    AB = norm(AB, b); V = [A * b + B for A, B in AB]; work = 0
    for i, (Ai, Bi) in enumerate(AB):
        vi = Ai * b + Bi
        if Ai == 0:
            for j in range(vi):
                t = F(j * N + 1, N * vi); work += 1
                if safe(V, N, t): return t, work
            continue
        for kappa in range(abs(Ai)):
            cs = [(Am * (F(1, N) + kappa) / Ai, Bm - F(Am * Bi, Ai)) for m, (Am, Bm) in enumerate(AB) if m != i]
            for xi1, xi2 in arcs_affine(cs, N):
                work += 1
                j = ceil(xi1 * vi - F(1, N))
                j += (kappa - j) % abs(Ai)
                if j < vi:
                    t = (j + F(1, N)) / vi
                    if t <= xi2:
                        assert safe(V, N, t), (AB, b, i, kappa, xi1, xi2, t)
                        return t, work
    return None, work
if __name__ == "__main__":
    from rec import chase
    print("C2 example W=(1,2,3,4)+u=5 (forms (0,B)), N=6, b=120:", gc2([(0, 1), (0, 2), (0, 3), (0, 4), (0, 5)], 120, 6))
    for b in (1, 7, 10 ** 6 + 3):
        print("C14-CE01 rank-one forms (k,k), k=1..4, N=5, b=%d: speeds %s -> %s" % (b, [k * (b + 1) for k in range(1, 5)], gc2([(1, 1), (2, 2), (3, 3), (4, 4)], b, 5)))
    fams = {"F(BJ)": (5, [(0, 1), (1, -1), (1, 1), (2, 0)]), "G": (6, [(0, 1), (1, -1), (1, 0), (1, 1), (1, 2)]),
            "H": (7, [(0, 1), (1, -1), (1, 0), (1, 1), (1, 2), (1, 3)]), "CE01-cluster": (7, [(0, 1), (1, 0), (1, -5), (1, -10), (1, -22)])}
    for nm, (N, AB) in fams.items():
        res = [(b,) + gc2(AB, b, N) for b in (3, 4, 5, 6, 30, 10 ** 9 + 7) if len({A * b + B for A, B in AB}) == len(AB) and all(A * b + B != 0 for A, B in AB)]
        print("%s N=%d: %s" % (nm, N, [(b, str(t), w) for b, t, w in res]))
    # completeness check against exact existence (chase) on random small-coefficient two-generator systems
    rng = random.Random(5); agree = tot = 0; maxwork = 0; found = 0
    for _ in range(3000):
        N = rng.choice([4, 5, 6, 7]); AB = []
        while len(AB) < N - 1:
            A, B = rng.randint(-3, 3), rng.randint(-25, 25)
            if (A, B) != (0, 0): AB.append((A, B))
        b = rng.choice([rng.randint(2, 60), rng.randint(61, 5000)])
        ABn = norm(AB, b); V = [A * b + B for A, B in ABn]
        if len(set(V)) < len(V) or len(V) < N - 1: continue
        t, w = gc2(AB, b, N); st, it = chase(V, N)
        tot += 1; agree += (t is not None) == (st is not None); found += t is not None; maxwork = max(maxwork, w)
    print("completeness vs exact chase: %d random systems (|A|<=3,|B|<=25, b up to 5000): agreement %d, safe time found %d, max arcs examined %d" % (tot, agree, found, maxwork))
