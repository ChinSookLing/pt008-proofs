# A22 task 1: on a FIXED batch of rank-2 nodes (all 14,911 nodes of C(6,6,17)), compare
#   (a) the A21 disc enumeration: every integer point of the box |p|,|q| <= R, R = isqrt(mu^2/(4 eta^2)), then sector, primitive, K1, delta != 0, exact failure;
#   (b) the C36 one-sided margin generator: only integer points inside the discs { s b_i.w > 2 h |w|^2 }  (b_i = J^T a_i, h = l_i or r_i, s = +-1),
#       which contain every w with  delta a_i.Jw > l_i D  or  -delta a_i.Jw > r_i D  (|delta| <= 1/2, discs through 0 nested in |delta|);
#       then sector, primitive, K1, delta != 0, the one-sided test with the actual delta (exact integers), exact failure.
# The failing sets must coincide node by node; we report points examined and time.  Boundary equality is safe (strict inequalities), ties to even as in bd19.
import sys, time, math
import numpy as np
from fractions import Fraction as F
from math import gcd, isqrt, lcm
sys.argv = ["x", "6", "6", "17"]
import class21g as C
from class21g import sub, forms, coinc, I, prim_np, rays, cone_ok, diffrows, suffix_mixed
def collect():
    nodes = []
    for z1 in [z for z in prim_np(5, F(6)).tolist() if suffix_mixed(z)]:
        Lb4 = sub(I, z1); M4 = forms(Lb4)
        if any(not any(r) for r in M4): continue
        y4, e4, m4 = coinc(M4); Z2 = prim_np(4, min(F(6), F(7 * m4) / (4 * e4 * e4))); Z2 = Z2[cone_ok(Z2, rays(diffrows(M4)))]
        for z2 in Z2.tolist():
            Lb3 = sub(Lb4, z2); M3 = forms(Lb3)
            if any(not any(r) for r in M3): continue
            y3, e3, m3 = coinc(M3); Z3 = prim_np(3, min(F(17), F(3 * m3) / (4 * e3 * e3))); Z3 = Z3[cone_ok(Z3, rays(diffrows(M3)))]
            for z3 in Z3.tolist():
                M2 = forms(sub(Lb3, z3))
                if any(not any(r) for r in M2): continue
                ys, eta, mu2 = coinc(M2); nodes.append((M2, ys, eta, mu2))
    return nodes
def common(P, Q, M2, Y, H, st, onesided):
    Mn = np.array(M2, dtype=np.int64); A = np.array(diffrows(M2), dtype=np.int64); W = np.stack([P, Q], 1)
    keep = np.all(W @ A.T > 0, axis=1) & (np.gcd(P, Q) == 1); P, Q = P[keep], Q[keep]
    U = (Mn @ np.stack([P, Q])).T
    k1 = np.any(U % 4 == 0, 1) & np.any(U % 5 == 0, 1) & np.any(U % 6 == 0, 1); P, Q, U = P[k1], Q[k1], U[k1]
    D = P * P + Q * Q; Zn = -Q * Y[0] + P * Y[1]; r0 = np.floor_divide(Zn, H); rem = Zn - H * r0
    dH = Zn - H * (r0 + (2 * rem > H) + ((2 * rem == H) & (r0 % 2 != 0)))
    nz = dH != 0; P, Q, D, U, dH = P[nz], Q[nz], D[nz], U[nz], dH[nz]
    if onesided:                                                          # C36 necessary condition, exact: 6 dH c_i > (6F_i - H) D  or  -6 dH c_i > (5H - 6F_i) D
        os_ = np.zeros(len(P), dtype=bool)
        for i in range(len(M2)):
            c = -Mn[i, 0] * Q + Mn[i, 1] * P; Fi = (int(Mn[i, 0]) * Y[0] + int(Mn[i, 1]) * Y[1]) % H
            os_ |= (6 * dH * c > (6 * Fi - H) * D) | (-6 * dH * c > (5 * H - 6 * Fi) * D)
        st["onesided_pass"] += int(os_.sum()); P, Q, D, U, dH = P[os_], Q[os_], D[os_], U[os_], dH[os_]
    st["exact_checked"] = st.get("exact_checked", 0) + len(P)
    fail = np.zeros(len(P), dtype=bool)
    for i in range(len(M2)):
        c = -Mn[i, 0] * Q + Mn[i, 1] * P; MY = int(Mn[i, 0]) * Y[0] + int(Mn[i, 1]) * Y[1]
        num = D * MY - dH * c; den = H * D; s = np.mod(num, den); fail |= 6 * np.minimum(s, den - s) < den
    return {tuple(u) for u in U[fail].tolist()}
def run_a(M2, ys, eta, mu2, st):
    H = lcm(ys[0].denominator, ys[1].denominator); Y = [int(y * H) for y in ys]; R = isqrt(int(mu2 / (4 * eta * eta)))
    ax = np.arange(-R, R + 1, dtype=np.int64); P, Q = np.meshgrid(ax, ax, indexing="ij"); P = P.ravel(); Q = Q.ravel()
    D = P * P + Q * Q; keep = (D > 0) & (D * 4 * eta.numerator ** 2 <= mu2 * eta.denominator ** 2); st["points"] += len(P)
    return common(P[keep], Q[keep], M2, Y, H, st, False)
def run_b(M2, ys, eta, mu2, st):
    H = lcm(ys[0].denominator, ys[1].denominator); Y = [int(y * H) for y in ys]; boxes = []
    for a0, a1 in M2:
        Fi = (a0 * Y[0] + a1 * Y[1]) % H
        for h in (F(6 * Fi - H, 6 * H), F(5 * H - 6 * Fi, 6 * H)):        # l_i, r_i  (both >= eta > 0)
            assert h > 0
            b = (a1, -a0); rad = math.hypot(*b) / (4 * float(h))
            for s in (1, -1):
                cx, cy = s * b[0] / (4 * float(h)), s * b[1] / (4 * float(h))
                xs = np.arange(math.floor(cx - rad) - 1, math.ceil(cx + rad) + 2, dtype=np.int64)
                ys_ = np.arange(math.floor(cy - rad) - 1, math.ceil(cy + rad) + 2, dtype=np.int64)
                P, Q = np.meshgrid(xs, ys_, indexing="ij"); P = P.ravel(); Q = Q.ravel()
                inside = 2 * float(h) * (P * P + Q * Q) < s * (b[0] * P + b[1] * Q) + 1e-9 * (1 + P * P + Q * Q)   # float pre-cut, generous
                boxes.append(np.stack([P[inside], Q[inside]], 1)); st["points"] += len(P)
    W = np.unique(np.concatenate(boxes), axis=0); W = W[np.any(W != 0, 1)]
    return common(W[:, 0], W[:, 1], M2, Y, H, st, True)
if __name__ == "__main__":
    t0 = time.time(); nodes = collect(); print("fixed batch: %d rank-2 nodes of C(6,6,17) (%.1fs to build)" % (len(nodes), time.time() - t0), flush=True)
    sa = {"points": 0}; sb = {"points": 0, "onesided_pass": 0}; ta = tb = 0.0; diff = 0; nfail = 0
    for M2, ys, eta, mu2 in nodes:
        t1 = time.time(); A = run_a(M2, ys, eta, mu2, sa); t2 = time.time(); B = run_b(M2, ys, eta, mu2, sb); t3 = time.time()
        ta += t2 - t1; tb += t3 - t2; diff += (A != B); nfail += len(A)
    print("(a) disc enumeration: points examined %d, entering the exact modular check %d, time %.1fs" % (sa["points"], sa["exact_checked"], ta))
    print("(b) one-sided discs : points examined %d (box points of the discs), passing the one-sided test (= entering the exact check) %d, time %.1fs" % (sb["points"], sb["onesided_pass"], tb))
    print("exact rank-2 failing (U) total %d ; nodes whose failing sets differ: %d" % (nfail, diff))
