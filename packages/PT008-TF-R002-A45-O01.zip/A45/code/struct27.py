# A27 exploration (TEST): safe-set structure of the known TOP-RANK1 inputs (74 from A20 + those found by explore27).
import json
from fractions import Fraction as F
from math import gcd
from collections import Counter
from a02_lib import dist
def safe_set(U, N=6):
    pts = sorted({F(N * k + s, N * u) for u in U for k in range(u + 1) for s in (1, -1) if 0 <= F(N * k + s, N * u) <= 1})
    out = []
    for a, b in zip(pts, pts[1:]):
        if all(dist(u * (a + b) / 2) >= F(1, N) for u in U):
            if out and out[-1][1] == a: out[-1] = (out[-1][0], b)
            else: out.append((a, b))
    return out
S = {tuple(r[0]) for r in json.load(open("union20.json"))} | {tuple(r[0]) for r in json.load(open("explore27_top.json"))}
rows = []
for U in sorted(S):
    comps = [(a, b) for a, b in safe_set(U) if a < F(1, 2) + F(1, 10**9)]          # [0,1/2] by symmetry
    L = max(b - a for a, b in comps); meas = 2 * sum(b - a for a, b in comps)
    best = None
    for q in range(2, 19):
        for a in range(1, q):
            if gcd(a, q) == 1 and all(dist(F(u * a, q)) >= F(1, 6) for u in U):
                best = (q, a); break
        if best: break
    rows.append((U, float(L), float(meas), len(comps), best))
print("TOP-RANK1 inputs analysed: %d" % len(rows))
print("longest safe component in [0,1/2]: min %.5f  median %.5f  max %.5f ; components > 1/18: %d of %d" % (min(r[1] for r in rows), sorted(r[1] for r in rows)[len(rows) // 2], max(r[1] for r in rows), sum(r[1] > 1 / 18 for r in rows), len(rows)))
print("safe-set measure: min %.5f median %.5f max %.5f" % (min(r[2] for r in rows), sorted(r[2] for r in rows)[len(rows) // 2], max(r[2] for r in rows)))
print("number of components in [0,1/2]:", Counter(r[3] for r in rows))
print("smallest safe denominator:", Counter(r[4][0] for r in rows))
for r in sorted(rows, key=lambda r: r[1])[:8]: print("   thinnest:", r)
