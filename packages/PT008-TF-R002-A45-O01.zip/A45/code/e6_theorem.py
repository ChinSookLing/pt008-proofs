# Theorem E6' (A04): for every c>=0, every finite prime set P (we always add 2,3,5), every prime l notin P, l>6:
#   V = V(c,P,l): K = max(4, c+2);  v_i = u_p * a^(p)_i (mod p^K) for p in P;  v_i = (l-1)/2 (mod l);
#   type A1=(1,2,3,4,5) signs/units at p=2 and p>=7; type A2=(1,3,4,5,9) at p=3,5 (signed entries below);
#   positive primitive lift: v_2..v_5 least positive CRT representatives, v_1 = r_1 + Q*m with m chosen so gcd(v_1, gcd(v_2..v_5)) = 1.
import sys
from math import gcd
from fractions import Fraction as F
from a02_lib import classify, vp, safe, dist
N = 6
ENT = {2: (11, (-4, -2, -1, 3, -5)), 3: (2452, (9, 1, 5, 3, 4)), 5: (12296, (5, 3, -1, -4, -9))}   # (unit, signed entries)
A1 = (1, 2, 3, 4, 5); A2 = (1, 3, 4, 5, 9)
def entries(p):
    return ENT.get(p, (1, A1))
def crt(rs, ms):
    x, m = 0, 1
    for r, mm in zip(rs, ms):
        k = ((r - x) * pow(m, -1, mm)) % mm; x += m * k; m *= mm
    return x % m, m
def primes_of(n):
    out, d = [], 2
    while d * d <= n:
        if n % d == 0:
            out.append(d)
            while n % d == 0: n //= d
        d += 1
    if n > 1: out.append(n)
    return out
def build(c, P, l):
    P = sorted(set(P) | {2, 3, 5}); assert l not in P and l > 6
    K = max(4, c + 2); mods = [p ** K for p in P] + [l]
    R = []
    for i in range(5):
        rs = [(entries(p)[0] * entries(p)[1][i]) % p ** K for p in P] + [(l - 1) // 2]
        R.append(crt(rs, mods)[0])
    Q = 1
    for mm in mods: Q *= mm
    V = [r if r > 0 else Q for r in R]                 # residues are nonzero mod every p (entries are units or p^e*unit with e<K), so r>0 anyway
    g = 0
    for v in V[1:]: g = gcd(g, v)
    # primitive lift of v_1: for primes s | g with s notin Q choose m avoiding r_1 + Q m = 0 (mod s); s | Q cannot divide all residues (see proof)
    bad = [s for s in primes_of(g) if Q % s]
    m = 0
    if bad:
        rs = [((-V[0] * pow(Q, -1, s)) + 1) % s for s in bad]   # m = -r1/Q + 1 (mod s)  =>  r1 + Q m = Q (mod s) != 0
        m = crt(rs, bad)[0]
    V[0] = V[0] + Q * m
    return V, K, Q, P
def check(c, P, l):
    V, K, Q, P = build(c, P, l)
    g = 0
    for v in V: g = gcd(g, v)
    cls = classify(V, N); h = {p: max(vp(v, p) for v in V) for p in P}
    Bs = [F(a + j * r, q * r) for q in range(2, 7) for r in range(2, 7) for a in range(1, r) if gcd(a, r) == 1 for j in range(q) if safe(V, N, F(a + j * r, q * r))]
    dead = True; checked = 0
    for p in P:
        for D in range(1, h[p] + c + 1):
            Qd = p ** D
            if Qd > 200000: continue                       # Lemma T* covers all D<=K; exact grid check where feasible
            checked += 1
            if any(all(N * min((v * x) % Qd, Qd - (v * x) % Qd) >= Qd for v in V) for x in range(1, Qd) if x % p): dead = False
    t = F(1, l); marg = min(dist(v * t) for v in V) - F(1, N)
    return dict(c=c, P=P, l=l, K=K, V=V, gcd=g, cls=cls, h=h, B_safe=len(Bs), dead=dead, grids=checked, margin=marg, tsafe=safe(V, N, t))
if __name__ == "__main__":
    print("mod-16/9/25 residue pattern:", [[(ENT[p][0] * e) % m for e in ENT[p][1]] for p, m in ((2, 16), (3, 9), (5, 25))])
    for c, P, l in [(0, [2, 3, 5], 7), (1, [2, 3, 5], 7), (2, [2, 3, 5, 7], 11), (3, [2, 3, 5, 7, 11, 13], 17), (6, [2, 3, 5], 7),
                    (8, [2, 3, 5, 7], 13), (4, [2, 3, 5, 11], 7), (10, [2, 3, 5, 7, 11, 13, 17, 19], 23)]:
        r = check(c, P, l)
        print("c=%d P=%s l=%d K=%d | gcd=%d class=%s h=%s | B safe candidates=%d | all c'/p^D dead (D<=h_p+c, %d exact grids)=%s | t=1/l safe=%s margin=%s"
              % (r["c"], r["P"], r["l"], r["K"], r["gcd"], r["cls"], r["h"], r["B_safe"], r["grids"], r["dead"], r["tsafe"], r["margin"]), flush=True)
