# Opus · PT008-TF-R002-A02 · shared exact helpers (Fractions only).  TESTS / falsification only.
from fractions import Fraction as F
from math import gcd, floor, ceil
def dist(x): x = x - floor(x); return min(x, 1 - x)
def safe(U, N, t): return all(dist(u * t) >= F(1, N) for u in U)
def bw(w, q, N): g = gcd(w, q); return g * -(-2 * (q // g) // N)
def classify(U, N):   # identical to R002-O01 r002_o01_cover.py
    for q in range(2, N + 1):
        if all(u % q for u in U): return "K1", None
    D = []
    for q in range(2, N + 1):
        c = sum(bw(u, q, N) for u in U if u % q)
        if c <= q - 1: return "K2", None
        D.append(c - q + 1)
    return ("K3A" if min(D) == 1 else "K3B"), min(D)
def vp(n, p):
    n = abs(n); e = 0
    while n % p == 0: n //= p; e += 1
    return e
def padic_safe(U, N, p, D):
    """all safe t = c/p^D with p not dividing c (exact denominator p^D), 0<c<p^D. Residues of U mod p^D suffice."""
    Q = p ** D; R = [u % Q for u in U]; out = []
    for c in range(1, Q):
        if c % p == 0: continue
        if all(min((r * c) % Q, Q - (r * c) % Q) * N >= Q for r in R): out.append(c)
    return out
def min_depth(U, N, p, Dmax):
    for D in range(1, Dmax + 1):
        s = padic_safe(U, N, p, D)
        if s: return D, s[0]
    return None, None
