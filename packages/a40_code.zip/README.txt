PT-008 R002 A40 certificate package (Hesper), Z=12 tail |U|^2>=21609, wedge bound |U^m|^2<=332.
Shape: primitive z1=(3,1,1,1,0) only; (2,2,2,0,0) excluded by primitivity (norm-12 vectors up to signed permutation are exactly these two).
Bound check: python3 bound.py 12  (S=16/3 for even Z; beta1>=1/2 excluded: min product 841/324 > 20736/21609; then beta2+beta3>29/6, min beta2*beta3 = 841/162, |U^m|^2 < 279936/841 = 332.86 -> <=332). Same script reproduces 546750/961 (Z=15) and 3203226/5929 (Z=13).
Replay:
  python3 gen.py 3,1,1,1,0 332 21609 planes_A.tsv
  python3 resid.py planes_A.tsv 21609 > resid_A.txt
  node times.js resid_A.txt rt_A.txt
  python3 verify.py 3,1,1,1,0 332 21609 planes_A.tsv rt_A.txt
Columns as A37/A38: planes p,q,det^2,tr,x0,y0,rr(exact rho^2),closed ; rt: p q a b u1..u5 i k, t=(6k+1)/(6|u_i|).
Closed planes are covered by Lean lemmaT_T6 (A39 Gate 1, commit d2128613), whose returned time is lemmaT_time with floor(s+1/2); the certificate itself evaluates no rounding.
Expected: planes 35646 closed 32322 residual planes 3324 residual inputs 664944 max |U|^2 677425 ALL PASS
