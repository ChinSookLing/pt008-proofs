set -e
tag=$1; z=$2
python3 gen.py $z 332 21609 planes_$tag.tsv > gen_$tag.log
python3 resid.py planes_$tag.tsv 21609 > resid_$tag.txt
node times.js resid_$tag.txt rt_$tag.txt 2>> gen_$tag.log
python3 verify.py $z 332 21609 planes_$tag.tsv rt_$tag.txt > ver_$tag.log 2>&1
