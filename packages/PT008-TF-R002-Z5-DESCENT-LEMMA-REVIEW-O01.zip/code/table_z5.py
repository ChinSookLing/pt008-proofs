# size of the (z1, z2) table for the doubled-pair shape z1 = (2,-1,0,0,0): W = {z1,z2}^perp meets U = (u,2u,v1,v2,v3)
# exactly through the linear form (A, c, d, e), A = a + 2b, i.e.  A u + c v1 + d v2 + e v3 = 0.
# Count primitive forms (up to sign and permutations of (c,d,e)) having a lift z2 with |z2|^2 <= 63 and admitting a
# positive solution with distinct speeds (u, 2u, v1, v2, v3).
import itertools
from math import gcd
best = {}
R = 8
for a, b, c, d, e in itertools.product(range(-R, R + 1), repeat=5):
    n = a * a + b * b + c * c + d * d + e * e
    if n > 63: continue
    A = a + 2 * b
    if (c, d, e) == (0, 0, 0): continue           # z2 parallel-ish to z1 on the (u,2u) block only -> forces u = 0
    f = (A, c, d, e); g = 0
    for x in f: g = gcd(g, x)
    f = tuple(x // g for x in f)
    key = min((s * f[0],) + tuple(sorted(s * y for y in f[1:])) for s in (1, -1))
    best[key] = min(best.get(key, 99), n)
def has_positive(f):
    A, c, d, e = f
    coeffs = [A, c, d, e]
    return any(x > 0 for x in coeffs) and any(x < 0 for x in coeffs)
forms = {k: v for k, v in best.items() if has_positive(k)}
print("primitive linear forms (A,c,d,e) up to sign/perm with a lift |z2|^2 <= 63:", len(best), "; with a positive solution:", len(forms))
from collections import Counter
print("by minimal |z2|^2 (cumulative):", [(N, sum(1 for v in forms.values() if v <= N)) for N in (5, 10, 20, 30, 37, 40, 50, 63)])
