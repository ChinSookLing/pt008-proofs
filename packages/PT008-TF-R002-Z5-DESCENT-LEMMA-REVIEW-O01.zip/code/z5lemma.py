# Z=5 descent lemma (Chair's proof candidate) -- exact numerical audit (Opus).
# For U in Z^5 (gcd 1) with a relation z1 of squared norm 5 (shape (2,-1,0,0,0) or (+-1,...)):
#   H = z1^perp, Lambda = Z^5 cap H, E = H cap U^perp, Gamma = pi_E(Lambda) (rank 3), Gamma^* = pi_H(Z^5) cap E.
#   LLL (delta = 3/4) on Gamma^*, b1 first vector.  Babai nearest plane with the reversed dual basis (a basis of Gamma)
#   on the target pi_E(c) has error <= sqrt(7)/(2|b1|); if |b1|^2 >= 63 the lifted lambda gives a safe time
#   t = <c - lambda, U>/|U|^2.  Otherwise there is an integer relation z2 (indep. of z1) with |z2|^2 <= 63.
# Everything exact (Fractions).  This file checks each step on concrete U, it does not replace the proof.
from fractions import Fraction as F
from math import gcd
import itertools

def dot(a, b): return sum(x * y for x, y in zip(a, b))
def sub(a, b): return [x - y for x, y in zip(a, b)]
def add(a, b): return [x + y for x, y in zip(a, b)]
def mul(k, a): return [k * x for x in a]
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)

def int_kernel(a):
    """unimodular column ops: returns a basis (list of 4 integer vectors) of {z in Z^5 : <z,a> = 0}"""
    n = len(a); M = [[int(i == j) for j in range(n)] for i in range(n)]   # columns of M: M[:,j]
    row = list(a)
    cols = [[M[i][j] for i in range(n)] for j in range(n)]
    # Euclid on row entries with column ops
    while sum(1 for x in row if x != 0) > 1:
        nz = [j for j in range(n) if row[j] != 0]
        p = min(nz, key=lambda j: abs(row[j]))
        for j in nz:
            if j == p: continue
            q = row[j] // row[p]
            row[j] -= q * row[p]; cols[j] = sub(cols[j], mul(q, cols[p]))
    return [cols[j] for j in range(n) if row[j] == 0]

def proj_out(v, w):
    """component of v orthogonal to w"""
    return sub(v, mul(F(dot(v, w), dot(w, w)), w))

def gso(B):
    Bs = []; mu = [[F(0)] * len(B) for _ in B]
    for i, b in enumerate(B):
        v = list(b)
        for j in range(i):
            mu[i][j] = F(dot(b, Bs[j]), dot(Bs[j], Bs[j])); v = sub(v, mul(mu[i][j], Bs[j]))
        Bs.append(v)
    return Bs, mu

def lll(B, delta=F(3, 4)):
    """exact LLL on vectors B (rational coordinates); returns reduced basis (same lattice)"""
    B = [list(b) for b in B]; k = 1
    while k < len(B):
        Bs, mu = gso(B)
        for j in range(k - 1, -1, -1):
            q = round(mu[k][j])
            if q: B[k] = sub(B[k], mul(q, B[j])); Bs, mu = gso(B)
        if dot(Bs[k], Bs[k]) >= (delta - mu[k][k - 1] ** 2) * dot(Bs[k - 1], Bs[k - 1]): k += 1
        else: B[k], B[k - 1] = B[k - 1], B[k]; k = max(k - 1, 1)
    return B

def inv3(G):
    """inverse of a 3x3 rational matrix"""
    n = len(G); A = [list(r) + [F(int(i == j)) for j in range(n)] for i, r in enumerate(G)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0); A[c], A[p] = A[p], A[c]
        piv = A[c][c]; A[c] = [x / piv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0: A[r] = sub(A[r], mul(A[r][c], A[c]))
    return [r[n:] for r in A]

def dual_basis(B):
    G = [[F(dot(x, y)) for y in B] for x in B]; Gi = inv3(G)
    return [[sum(Gi[i][j] * B[j][k] for j in range(3)) for k in range(len(B[0]))] for i in range(3)]

def babai(B, x):
    """nearest plane: integer coefficients k with |x - sum k_i B_i|^2 <= (1/4) sum |B_i^*|^2"""
    Bs, _ = gso(B); r = list(x); k = [0] * len(B)
    for i in range(len(B) - 1, -1, -1):
        c = round(F(dot(r, Bs[i]), dot(Bs[i], Bs[i]))); k[i] = c; r = sub(r, mul(c, B[i]))
    return k, r

def center(z1):
    """phase center c in z1^perp with every coordinate at distance exactly 1/3 from Z"""
    s = sorted(range(5), key=lambda i: -abs(z1[i]))
    if sorted(map(abs, z1)) == [0, 0, 0, 1, 2]:
        i2 = next(i for i in range(5) if abs(z1[i]) == 2); i1 = next(i for i in range(5) if abs(z1[i]) == 1)
        c = [F(1, 3)] * 5; c[i2] = F(1, 3) * (1 if z1[i2] > 0 else -1)
        c[i1] = -F(2, 3) * (1 if z1[i2] > 0 else -1) * (1 if z1[i1] > 0 else -1)   # 2*s2*c2' ... makes <z1,c> = 0
        c[i2] = F(1, 3) * (1 if z1[i2] > 0 else -1)
        c[i1] = -F(2, 3) * (1 if z1[i1] > 0 else -1) * 1
        # <z1,c> = z1[i2]*c[i2] + z1[i1]*c[i1] = 2/3 - 2/3 = 0 (|z1[i2]| = 2, |z1[i1]| = 1)
    else:
        e = [1 if x > 0 else -1 for x in z1]; y = [F(1, 3)] * 4 + [F(-4, 3)]     # sum y = 0
        c = [e[i] * y[i] for i in range(5)]                                          # <z1,c> = sum y = 0
    assert dot(z1, c) == 0 and all(dist(x) == F(1, 3) for x in c), (z1, c)
    return c

def audit(U, z1, delta=F(3, 4), thr=63):
    assert dot(U, z1) == 0 and dot(z1, z1) == 5
    U = list(U); c = center(z1)
    # Lambda basis containing U: kernel of z1, then rewrite so that U is a basis vector
    L = int_kernel(z1)
    # coordinates y of U in basis L (solve integer system: use least squares exact via Gram)
    G = [[F(dot(a, b)) for b in L] for a in L]
    # 4x4 inverse
    n = 4; A = [list(r) + [F(int(i == j)) for j in range(n)] for i, r in enumerate(G)]
    for col in range(n):
        p = next(r for r in range(col, n) if A[r][col] != 0); A[col], A[p] = A[p], A[col]
        piv = A[col][col]; A[col] = [x / piv for x in A[col]]
        for r in range(n):
            if r != col and A[r][col] != 0: A[r] = sub(A[r], mul(A[r][col], A[col]))
    Gi = [r[n:] for r in A]; rhs = [dot(a, U) for a in L]
    y = [sum(Gi[i][j] * rhs[j] for j in range(n)) for i in range(n)]
    assert all(v.denominator == 1 for v in y); y = [int(v) for v in y]
    assert gcd(*y) == 1 if hasattr(__import__('math'), 'gcd') else True
    # complete y to a unimodular matrix: kernel of y (3 vectors) + one vector w with <w-coeffs> giving U
    K = int_kernel(y)                               # 3 vectors k in Z^4 with <k,y> = 0 ... these span a complement? not nec.
    # Lambda / Z U  is spanned by images of the 4 basis vectors; use all 4 projections and LLL-free basis via Gamma^* route
    Gam_gen = [proj_out(proj_out(l, U), z1) if False else proj_out(l, U) for l in L]   # pi_E(l): l in H already
    # Gamma = Z-span of Gam_gen (rank 3).  Get a basis: Gamma^* = pi_H(R), R = int kernel of U; take its basis of rank 3.
    R = int_kernel(U)
    Ds = [proj_out(r, z1) for r in R]               # generators of Gamma^* (4 vectors, rank 3)
    # basis of Gamma^*: LLL handles dependency poorly; do integer row reduction on coefficients w.r.t. a rational basis
    # Simple route: z1 is in R and primitive; find R-basis containing z1 by solving z1 = sum m_j R_j (m primitive)
    GR = [[F(dot(a, b)) for b in R] for a in R]
    A = [list(r) + [F(int(i == j)) for j in range(4)] for i, r in enumerate(GR)]
    for col in range(4):
        p = next(r for r in range(col, 4) if A[r][col] != 0); A[col], A[p] = A[p], A[col]
        piv = A[col][col]; A[col] = [x / piv for x in A[col]]
        for r in range(4):
            if r != col and A[r][col] != 0: A[r] = sub(A[r], mul(A[r][col], A[col]))
    GRi = [r[4:] for r in A]; rhs = [dot(a, z1) for a in R]
    m = [sum(GRi[i][j] * rhs[j] for j in range(4)) for i in range(4)]; assert all(v.denominator == 1 for v in m)
    m = [int(v) for v in m]
    # unimodular completion of m: rows of a matrix whose first row is m -> use int_kernel to get complement via Smith trick:
    # find integer vector w with <w,m> = 1 (exists since m primitive), then {kernel of w} gives 3 vectors k with
    # R-combos sum k_j R_j spanning a complement of z1 modulo z1.
    # Easier: Gamma^* is generated by the 4 projected vectors; any 3 of them whose determinant equals the generated
    # lattice's determinant form a basis.  Use HNF over the 4 projections written in a fixed rational basis of E.
    E0 = [list(map(F, z1)), list(map(F, U))]
    for i in range(5):
        v = [F(int(i == j)) for j in range(5)]
        for w in E0: v = sub(v, mul(F(dot(v, w), dot(w, w)), w))
        if any(x != 0 for x in v): E0.append(v)
    Ebas = E0[2:5]
    coords = [[F(dot(d, e), dot(e, e)) for e in Ebas] for d in Ds]           # 4 x 3 rational
    den = 1
    for row in coords:
        for x in row: den = den * x.denominator // gcd(den, x.denominator)
    Z = [[int(x * den) for x in row] for row in coords]                       # integer 4x3, lattice = Z-rowspan / den
    # integer row reduction (HNF-like) to 3 independent rows
    rows = [r[:] for r in Z]; basis_rows = []
    for col in range(3):
        while True:
            nz = [i for i, r in enumerate(rows) if r[col] != 0]
            if len(nz) <= 1: break
            p = min(nz, key=lambda i: abs(rows[i][col]))
            for i in nz:
                if i != p: q = rows[i][col] // rows[p][col]; rows[i] = sub(rows[i], mul(q, rows[p]))
        nz = [i for i, r in enumerate(rows) if r[col] != 0]
        if nz: basis_rows.append(rows.pop(nz[0]))
    assert len(basis_rows) == 3 and all(all(x == 0 for x in r) for r in rows)
    Dbas = [[sum(F(r[k], den) * Ebas[k][t] for k in range(3)) for t in range(5)] for r in basis_rows]
    Dred = lll(Dbas, delta); b1 = Dred[0]; nb1 = dot(b1, b1)
    Bs, mu = gso(Dred)
    lll_ok = all(dot(Bs[i + 1], Bs[i + 1]) >= dot(Bs[i], Bs[i]) * (F(1, 2) if delta == F(3, 4) else F(3, 4)) for i in range(2))
    Gm = dual_basis(Dred); Grev = Gm[::-1]                                   # basis of Gamma, reversed dual
    # sanity: Grev is a basis of Gamma = pi_E(Lambda): every pi_E(l) is an integer combination, and vice versa
    # (checked through the duality <Grev_i, Dred_j> in {0,1})
    assert all(dot(Grev[i], Dred[j]) == (1 if 2 - i == j else 0) for i in range(3) for j in range(3))
    Gs, _ = gso(Grev)
    gs_ok = all(dot(Gs[i], Gs[i]) * dot(Bs[2 - i], Bs[2 - i]) == 1 for i in range(3))   # reversed-dual GS lengths
    target = proj_out(proj_out(c, U), z1)                                    # pi_E(c) (c in H already)
    k, r = babai(Grev, target); err2 = dot(r, r)
    bound_ok = err2 <= (F(7, 4) if delta == F(3, 4) else F(37, 36)) / nb1
    gam = sub(target, r)                                                      # lattice point of Gamma
    # lift gam to lambda in Lambda: lambda = gam + s U + (component along z1 = 0), find s with integer coordinates
    out = {"U": U, "z1": z1, "|b1|^2": nb1, "lll_ok": lll_ok, "gs_reversed_dual_ok": gs_ok, "babai_err2": err2, "bound_ok": bound_ok}
    # lift: gam = pi_E(lambda); lambda - gam is a multiple of U; s = frac to make integer
    # gam has rational coords; need s with gam + s U in Z^5: solve per coordinate
    s = None
    for i in range(5):
        if U[i] != 0:
            # s = (n - gam_i)/U_i ; try n so that all coords integer: scan s candidates over one period
            break
    # direct: s ranges over (n - gam_i)/U_i, period 1/U_i * ...; search n in range
    i0 = next(i for i in range(5) if U[i] != 0)
    for n in range(-abs(U[i0]) * 4 - 50, abs(U[i0]) * 4 + 50):
        cand = F(n) - gam[i0]; ss = cand / U[i0]
        lam = add(gam, mul(ss, U))
        if all(x.denominator == 1 for x in lam): s = ss; break
    assert s is not None, "lift failed"
    lam = add(gam, mul(s, U)); assert dot(lam, z1) == 0
    t = F(dot(sub(c, lam), U), dot(U, U))
    dists = [dist(t * x) for x in U]
    out.update({"t": t, "min_dist": min(dists), "safe": min(dists) >= F(1, 6)})
    if nb1 >= thr: out["lemma_case"] = "A (safe time)"; out["lemma_ok"] = out["safe"]
    else:
        # case B: lift b1 to integer relation z2 and reduce along z1
        # b1 = pi_H(z) for z in R: z = b1 + alpha z1 with integer coords; alpha in (1/5)Z
        z2 = None
        for num in range(-10**4, 10**4 + 1):
            al = F(num, 5); z = add(b1, mul(al, z1))
            if all(x.denominator == 1 for x in z): z2 = [int(x) for x in z]; break
        a = F(dot(z2, z1), 5); kk = round(a); z2 = sub(z2, mul(kk, z1))
        out["lemma_case"] = "B (second relation)"; out["z2"] = z2; out["|z2|^2"] = dot(z2, z2)
        out["lemma_ok"] = dot(z2, U) == 0 and dot(z2, z2) <= thr and any(z2[i] * z1[j] != z2[j] * z1[i] for i in range(5) for j in range(5))
    return out
