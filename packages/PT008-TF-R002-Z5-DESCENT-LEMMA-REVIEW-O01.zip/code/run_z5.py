# exact audit of the Z=5 descent lemma on concrete inputs
import random, sys, json
from fractions import Fraction as F
from math import gcd
from z5lemma import audit
random.seed(int(sys.argv[1])); DELTA = F(sys.argv[4]) if len(sys.argv) > 4 else F(3, 4); THR = int(sys.argv[5]) if len(sys.argv) > 5 else 63; N = int(sys.argv[2]); NMAX = int(sys.argv[3])
stats = {"A": 0, "A_ok": 0, "B": 0, "B_ok": 0, "lll_ok": 0, "gs_ok": 0, "bound_ok": 0, "safe_any": 0}
worst_ratio = F(0); maxz2 = 0; bad = []
cases = []
for i in range(N):
    if i % 2 == 0:   # doubled-pair shape: U = (u, 2u, v1, v2, v3), z1 = (2,-1,0,0,0)
        while True:
            u = random.randrange(1, NMAX); v = random.sample(range(1, NMAX), 3); U = [u, 2 * u] + v
            if len(set(U)) == 5 and gcd(*U) == 1: break
        z1 = [2, -1, 0, 0, 0]
    else:            # all-ones shape with signs: U1 + U2 = U3 + U4 + U5 (z1 = (1,1,-1,-1,-1)) or U1+U2+U3 = U4+U5
        while True:
            if random.random() < 0.5:
                a, b, c = (random.randrange(1, NMAX) for _ in range(3)); s = a + b + c
                x = random.randrange(1, s); U = [x, s - x, a, b, c]; z1 = [1, 1, -1, -1, -1]
            else:
                a, b = random.randrange(1, NMAX), random.randrange(1, NMAX); s = a + b
                x = random.randrange(1, s - 1) if s > 2 else 1; y = random.randrange(1, s - x) if s - x > 1 else 1
                U = [x, y, s - x - y, a, b]; z1 = [1, 1, 1, -1, -1]
            if min(U) > 0 and len(set(U)) == 5 and gcd(*U) == 1: break
    o = audit(U, z1, DELTA, THR)
    stats["lll_ok"] += o["lll_ok"]; stats["gs_ok"] += o["gs_reversed_dual_ok"]; stats["bound_ok"] += o["bound_ok"]; stats["safe_any"] += o["safe"]
    key = o["lemma_case"][0]; stats[key] += 1; stats[key + "_ok"] += o["lemma_ok"]
    r = o["babai_err2"] * o["|b1|^2"]; worst_ratio = max(worst_ratio, r)
    if key == "B": maxz2 = max(maxz2, o["|z2|^2"])
    if not o["lemma_ok"] and len(bad) < 5: bad.append({k: str(v) for k, v in o.items()})
print("seed %s, N %d, entries < %d : %s ; max babai_err^2 * |b1|^2 = %s (bound 7/4 for delta 3/4, 37/36 for delta 1) ; max |z2|^2 in case B = %d ; failures %s"
      % (sys.argv[1], N, NMAX, stats, float(worst_ratio), maxz2, bad))
