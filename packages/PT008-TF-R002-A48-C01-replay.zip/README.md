# PT-008 · A48-C01 · Z=3,4 幾何分支獨立重放

從解壓後根目錄執行（Python 3 + NumPy、C++17 + OpenMP）。

    OPENBLAS_NUM_THREADS=1 python3 a48-review/planes34.py
    sha256sum -c plane-sha256.txt
    g++ -O3 -fopenmp -std=c++17 a48-review/replay34.cpp -o replay34
    ./replay34 a48-review/Z3.bin
    ./replay34 a48-review/Z4.bin

兩張三維表的中心均逐項檢查飽和關係格同餘與正餘量。由整數第二關係重新枚舉空間，驗證名單完整。Z=3 使用平方範數界 37，Z=4 使用 O01 的半整數中心及平方範數界 10。Z=4 保留與 Z=3 重疊的分支以覆蓋整個關係型別。

投影枚舉以整數伴隨矩陣判定，浮點只作對照。秩一層由本原普呂克鍵重建飽和平面基，逐面驗 Gram 行列式。分母 12 內未找到中心時擴至 24。尾部以 \(\|U\|^2\ge21609\) 為閉下界；嚴格小於秩一取時界的剩餘速度重算有理見證，等號由 Babai 覆蓋。範數平方至多 21608 的部分接 A47-C11。此重放包涵蓋幾何 Z=3,4 分支。
