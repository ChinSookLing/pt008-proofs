# exact admissible planes for one W: P = W cap v^perp, v in Lambda_W^* = pi_W(Z^5), 0 < |v|^2 < T_W (T_W = 7/(12 m_W^2)).
# Lemma: in case B of the second round, b1' is such a v and U lies in W cap b1'^perp.  Coordinates: v = sum k_i d_i with
# (d_i) the dual basis of an LLL-reduced basis (w_i) of Z^5 cap W; then k_i = <v, w_i> and the plane is
# { sum a_i w_i : sum a_i k_i = 0 } (saturated when k is primitive).
import numpy as np, json, itertools, sys
from fractions import Fraction as F
from math import gcd, isqrt
from wtable import int_kernel
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def lll_int(B):
    import z5ll
    return z5ll.lll(B)
def reduce3(B):
    # simple exact LLL (delta 3/4) on integer vectors
    B = [list(b) for b in B]
    def gso(B):
        Bs = []; mu = [[F(0)] * 3 for _ in range(3)]
        for i, b in enumerate(B):
            v = [F(x) for x in b]
            for j in range(i):
                mu[i][j] = F(dot(b, Bs[j])) / dot(Bs[j], Bs[j]); v = [x - mu[i][j] * y for x, y in zip(v, Bs[j])]
            Bs.append(v)
        return Bs, mu
    k = 1
    while k < 3:
        Bs, mu = gso(B)
        for j in range(k - 1, -1, -1):
            qn = round(mu[k][j])
            if qn: B[k] = [x - qn * y for x, y in zip(B[k], B[j])]; Bs, mu = gso(B)
        if dot(Bs[k], Bs[k]) >= (F(3, 4) - mu[k][k - 1] ** 2) * dot(Bs[k - 1], Bs[k - 1]): k += 1
        else: B[k], B[k - 1] = B[k - 1], B[k]; k = max(k - 1, 1)
    return B
def plane_key(p, q):
    m = [p[i] * q[j] - p[j] * q[i] for i in range(5) for j in range(i + 1, 5)]
    g = 0
    for x in m: g = gcd(g, x)
    m = [x // g for x in m]; s = next(x for x in m if x)
    return tuple(x if s > 0 else -x for x in m)
def planes_exact(Wb, T):
    Wb = reduce3(Wb)
    G = np.array([[dot(a, b) for b in Wb] for a in Wb], dtype=float); Gi = np.linalg.inv(G)   # Gram of dual basis = G^-1
    Kmax = [int((T * G[i, i]) ** 0.5) + 1 for i in range(3)]
    rng = [np.arange(-K, K + 1) for K in Kmax]
    K = np.array(np.meshgrid(*rng, indexing="ij")).reshape(3, -1).T
    nrm = np.einsum("ni,ij,nj->n", K, Gi, K)
    K = K[(nrm < float(T) - 1e-9) & (nrm > 1e-12)]
    Gq = [[F(x) for x in row] for row in G.astype(int).tolist()]
    out = {}
    for k in K.tolist():
        g = gcd(gcd(k[0], k[1]), k[2])
        if g != 1: continue
        # exact check |v|^2 < T with rational Gram inverse via adjugate
        ab = int_kernel([k], n=3)
        p = [sum(ab[0][i] * Wb[i][t] for i in range(3)) for t in range(5)]; q = [sum(ab[1][i] * Wb[i][t] for i in range(3)) for t in range(5)]
        out.setdefault(plane_key(p, q), (p, q))
    return out
