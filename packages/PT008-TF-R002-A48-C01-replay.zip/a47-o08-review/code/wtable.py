# A47-T10 (Opus): independent rebuild of the 3-dim subspace table W = {z1, z2}^perp (|z2|^2 <= 37) for both Z=5 shapes,
# exclusions (a coordinate identically 0, or two coordinates identically equal up to sign), and strict safe centres
# c = r/q (q = 3, 4, 5) with the CORRECT membership test  c in W + Z^5  <=>  <s, r> = 0 mod q for s in a basis of the
# SATURATION S = Z^5 cap span(z1, z2)  (not only s = z1, z2).
import itertools, sys, json
from math import gcd
def int_kernel(rows, n=5):
    """Z-basis of {x in Z^n : <row, x> = 0 for all rows}"""
    B = [[int(i == j) for j in range(n)] for i in range(n)]        # current basis vectors (as rows)
    for a in rows:
        vals = [sum(x * y for x, y in zip(a, b)) for b in B]
        B = [b[:] for b in B]
        while sum(1 for v in vals if v) > 1:
            nz = [i for i, v in enumerate(vals) if v]; p = min(nz, key=lambda i: abs(vals[i]))
            for i in nz:
                if i != p:
                    k = vals[i] // vals[p]; vals[i] -= k * vals[p]; B[i] = [x - k * y for x, y in zip(B[i], B[p])]
        B = [b for b, v in zip(B, vals) if v == 0]
    return B
def plucker(z1, z2):
    m = [z1[i] * z2[j] - z1[j] * z2[i] for i in range(5) for j in range(i + 1, 5)]
    g = 0
    for x in m: g = gcd(g, x)
    m = [x // g for x in m]
    s = next(x for x in m if x)
    return tuple(x if s > 0 else -x for x in m), g
SHAPES = {"double": (2, -1, 0, 0, 0), "ones": (1, 1, 1, 1, 1)}
def table(z1, N=37):
    R = 6; W = {}
    for z2 in itertools.product(range(-R, R + 1), repeat=5):
        if sum(x * x for x in z2) > N: continue
        key, g = plucker(z1, z2) if any(z1[i] * z2[j] != z1[j] * z2[i] for i in range(5) for j in range(5)) else (None, 0)
        if key is None: continue
        if key not in W: W[key] = (z2, g)
    return W
def excluded(Wb):
    """W lattice basis (3 vectors): coordinate i identically 0, or coords i, j identically equal / opposite"""
    cols = [tuple(b[i] for b in Wb) for i in range(5)]
    if any(all(x == 0 for x in c) for c in cols): return "zero"
    for i in range(5):
        for j in range(i + 1, 5):
            if cols[i] == cols[j] or cols[i] == tuple(-x for x in cols[j]): return "equal"
    return None
def centres(Sb, q):
    """strict safe centres r/q in W + Z^5 (margin > 0), membership via the saturation basis Sb"""
    good = [r for r in range(1, q) if 6 * min(r, q - r) > q]       # distance r/q > 1/6
    out = []
    for r in itertools.product(good, repeat=5):
        if all(sum(s[i] * r[i] for i in range(5)) % q == 0 for s in Sb): out.append(r)
    return out
def naive_centres(z1, z2, q):
    good = [r for r in range(1, q) if 6 * min(r, q - r) > q]
    return [r for r in itertools.product(good, repeat=5) if sum(a * b for a, b in zip(z1, r)) % q == 0 and sum(a * b for a, b in zip(z2, r)) % q == 0]
if __name__ == "__main__":
    res = {}
    for name, z1 in SHAPES.items():
        W = table(z1); st = {"W": len(W), "zero": 0, "equal": 0, "kept": 0, "best_q": {3: 0, 4: 0, 5: 0}, "none": 0,
                             "unsaturated_pair": 0, "naive_says_centre_but_not": 0}
        rows = []
        for key, (z2, g) in W.items():
            Wb = int_kernel([z1, z2]); ex = excluded(Wb)
            if ex: st[ex] += 1; continue
            st["kept"] += 1; Sb = int_kernel(Wb)
            if g != 1: st["unsaturated_pair"] += 1
            best = None
            for q in (3, 4, 5):
                c = centres(Sb, q)
                if c: best = (q, c[0]); break
            nv = next((q for q in (3, 4, 5) if naive_centres(z1, z2, q)), None)
            if best is None:
                st["none"] += 1
                if nv: st["naive_says_centre_but_not"] += 1
            else: st["best_q"][best[0]] += 1
            if nv is not None and (best is None or nv < best[0]): st["naive_says_centre_but_not"] += (best is not None)
            rows.append({"z2": list(z2), "pair_index": g, "W_basis": Wb, "S_basis": Sb, "centre_q": best[0] if best else None,
                         "centre_r": list(best[1]) if best else None})
        res[name] = st; print(name, st, flush=True)
        json.dump(rows, open("wtable_%s.json" % name, "w"))
