import json, sys
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from math import gcd, isqrt
from pathlib import Path
import numpy as np
sys.path.insert(0, 'a47-o08-review/code')
from wtable import int_kernel, excluded
from exactplanes import reduce3

pairs = list(combinations(range(5), 2))
def wedge(a, b):
    return [int(a[i])*int(b[j])-int(a[j])*int(b[i]) for i,j in pairs]
def canon(w):
    d = gcd(*w)
    if next(x for x in w if x)<0: d=-d
    return tuple(x//d for x in w)
def keys(Z, bound):
    z1 = (1,1,-1,0,0) if Z==3 else (1,1,-1,-1,0)
    stored = {}
    for name,a,b,center in json.loads(Path(f'a48-review/hesper/W{Z}.json').read_text()):
        assert name == f'Z{Z}'
        w=wedge(a,b)
        assert gcd(*w)==1
        key=canon(w)
        assert key not in stored
        assert all(sum(i*j for i,j in zip(z1,v))==0 for v in int_kernel([a,b]))
        y,q,n,d,qmax=center
        assert qmax==12 and 1<=q<=12
        assert all(sum(i*j for i,j in zip(y,v))%q==0 for v in (a,b))
        m=Fraction(min(min(v,q-v) for v in y),q)-Fraction(1,6)
        assert Fraction(n,d)==m>0
        stored[key]=m

    radius=isqrt(bound)
    reps={}
    for z2 in product(range(-radius,radius+1),repeat=5):
        if sum(x*x for x in z2)>bound: continue
        w=wedge(z1,z2)
        if any(w): reps.setdefault(canon(w),z2)
    classified={key:z2 for key,z2 in reps.items() if excluded(int_kernel([z1,z2])) is None}
    assert set(classified)<=stored.keys()
    if bound==37: assert set(classified)==stored.keys()
    print('Z',Z,'bound',bound,'spaces',len(reps),'nondeg',len(classified),
          'margin',dict(Counter(stored[key] for key in classified)),flush=True)
    rows=[(z2,Fraction(7,12)/stored[key]**2) for key,z2 in classified.items()]
    blocks=[]
    float_misses=float_extra=total=0
    for idx,(z2,T) in enumerate(rows):
        a,b,c = reduce3(int_kernel([z1,z2]))
        W = np.array([a,b,c],dtype=np.int64)
        G = W @ W.T
        g00,g01,g02 = map(int,G[0])
        _,g11,g12 = map(int,G[1])
        _,_,g22 = map(int,G[2])
        c00,c01,c02 = g11*g22-g12*g12, g02*g12-g01*g22, g01*g12-g02*g11
        c11,c12,c22 = g00*g22-g02*g02,g01*g02-g00*g12,g00*g11-g01*g01
        det = g00*c00+g01*c01+g02*c02
        A,B = T.numerator,T.denominator
        lim = [isqrt((A*x-1)//B) for x in (g00,g11,g22)]
        k = np.array(np.meshgrid(*(np.arange(-x,x+1,dtype=np.int64) for x in lim),indexing='ij')).reshape(3,-1)
        x,y,z = k
        positive = (x>0) | ((x==0) & ((y>0) | ((y==0) & (z>0))))
        k = k[:, positive & (np.gcd(np.gcd(x,y),z)==1)]
        x,y,z = k
        assert (3*max(lim))**2 * max(map(abs,(c00,c01,c02,c11,c12,c22)))*B < 2**63
        numerator = c00*x*x + c11*y*y + c22*z*z + 2*(c01*x*y+c02*x*z+c12*y*z)
        exact = numerator*B < A*det
        float_norm = np.einsum('in,ij,jn->n',k,np.linalg.inv(G.astype(float)),k)
        old = (float_norm<float(T)-1e-9) & (float_norm>1e-12)
        float_misses += np.count_nonzero(exact & ~old)
        float_extra += np.count_nonzero(old & ~exact)
        K = k[:,exact].T
        wb = np.array([wedge(b,c), [-x for x in wedge(a,c)],wedge(a,b)],dtype=np.int64)
        P = K @ wb
        assert np.max(np.abs(P),initial=0) <= 32767
        assert (np.gcd.reduce(P,axis=1)==1).all()
        first = P[np.arange(len(P)),np.argmax(P!=0,axis=1)]
        blocks.append((P*np.sign(first)[:,None]).astype('<i2'))
        total += len(K)
    P = np.concatenate(blocks); del blocks
    uniq = np.unique(P.view('V20').ravel())
    print(Z,'incidences',total,'distinct',len(uniq),'float exclusions',float_misses,'float inclusions',float_extra,flush=True)
    return uniq

if __name__ == '__main__':
    for Z in (3,4):
        planes=keys(Z,37 if Z==3 else 10)
        planes.tofile(f'a48-review/Z{Z}.bin')
