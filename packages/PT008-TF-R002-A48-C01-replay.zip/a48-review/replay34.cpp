#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
#include <vector>
using I=long long; using V=std::array<I,5>; using Key=std::array<int16_t,10>; using T=std::array<I,2>;
I dot(const V&a,const V&b){return std::inner_product(a.begin(),a.end(),b.begin(),0LL);}
I floor_div(I a,I b){I q=a/b;return q-(a%b<0);}
I isqrt(I a){assert(a>=0);I s=std::sqrt((double)a);while((s+1)*(s+1)<=a)++s;while(s*s>a)--s;return s;}
std::array<V,2> basis(std::array<V,5> rows){
    int rank=0;
    for(int j=0;j<5&&rank<2;++j){
        int best=rank;while(best<5&&rows[best][j]==0)++best;
        if(best==5)continue;
        std::swap(rows[best],rows[rank]);
        for(int i=rank+1;i<5;++i)while(rows[i][j]){
            I c=rows[rank][j]/rows[i][j];
            for(int k=j;k<5;++k)rows[rank][k]-=c*rows[i][k];
            std::swap(rows[rank],rows[i]);
        }
        ++rank;
    }
    assert(rank==2);
    V p=rows[0],q=rows[1];
    while(true){
        I A=dot(p,p),C=dot(q,q);
        if(C<A){std::swap(p,q);A=C;}
        I b=dot(p,q);
        if(2*std::abs(b)<=A)return {p,q};
        I c=floor_div(2*b+A,2*A);
        for(int i=0;i<5;++i)q[i]-=c*p[i];
    }
}
T centre(const V&p,const V&q,int d0,int d1,T m){
    for(int d=d0;d>=d1;--d){
        if((6*(d/2)-d)*m[1]<=6*d*m[0])continue;
        I P[5],Q[5];for(int i=0;i<5;++i){P[i]=(p[i]%d+d)%d;Q[i]=(q[i]%d+d)%d;}
        for(int a=0;a<d;++a)for(int b=0;b<d;++b){
            if(a==0&&b==0)continue;
            I least=d/2;
            for(int k=0;k<5;++k){
                I z=(a*P[k]+b*Q[k])%d; least=std::min(least,std::min(z,d-z));
                if((6*least-d)*m[1]<=6*d*m[0])break;
            }
            if((6*least-d)*m[1]>6*d*m[0])m={6*least-d,6*d};
        }
    }
    return m;
}
bool safe(const V&v,I a,I b){
    for(I u:v){I r=u*a%b;if(6*std::min(r,b-r)<b)return false;}return true;
}
bool witness(const V& v){
    for(I q=2;q<=6;++q)if(safe(v,1,q))return true;
    for(I s:v)for(I k=0;k<s;++k)if(safe(v,6*k+1,6*s))return true;
    return false;
}
int main(int argc,char**argv){
    assert(argc==2);
    std::ifstream in(argv[1],std::ios::binary|std::ios::ate);
    assert(in.is_open());
    I bytes=in.tellg();
    assert(bytes>0 && bytes%sizeof(Key)==0);
    I cap=bytes/sizeof(Key);
    in.seekg(0);
    std::vector<Key> K(cap);
    in.read(reinterpret_cast<char*>(K.data()),bytes);
    assert(in.gcount()==bytes);
    I deg=0,none=0,extended=0,rext=0,rt=0,active=0,failed=0,failcent=0;
    #pragma omp parallel for schedule(dynamic,4096) reduction(+:deg,none,extended,rext,rt,active,failed,failcent)
    for(I h=0;h<cap;++h){
        std::array<V,5>M{};int t=0;I D=0,primitive=0;
        for(int i=0;i<5;++i)for(int j=i+1;j<5;++j){
            I x=K[h][t++];M[i][j]=x;M[j][i]=-x;D+=x*x;primitive=std::gcd(primitive,x);
        }
        assert(primitive==1&&D>0);
        bool drop=false;
        for(int i=0;i<5;++i){
            if(M[i]==V{})drop=true;
            for(int j=0;j<i;++j){
                bool plus=true,minus=true;
                for(int k=0;k<5;++k){plus&=M[i][k]==M[j][k];minus&=M[i][k]==-M[j][k];}
                drop|=plus||minus;
            }
        }
        if(drop){++deg;continue;}
        auto [p,q]=basis(M);
        auto A=dot(p,p),B=dot(p,q),C=dot(q,q);
        assert(A*C-B*B==D);
        // q=6, 4, and 2 usually find the useful margins first.
        T m{0,1};
        for(int d:{2,6,4,12,11,10,9,8,7,5,3})m=centre(p,q,d,d,m);
        bool ext=m[0]==0;
        if(ext){++extended;m=centre(p,q,24,13,m);if(m[0]==0){++failcent;continue;}}
        const I scale=4*m[0]*m[0], limit=m[1]*m[1]*D;
        if(limit<=scale*21609){if(!ext)++none;continue;}
        I count=0;
        const I bmax=isqrt((A*limit-1)/(scale*D));
        for(I b=0;b<=bmax;++b){
            I square=isqrt((A*limit-scale*D*b*b-1)/scale);
            I lo=-floor_div(square+B*b,A),hi=floor_div(square-B*b,A);
            for(I a=b==0?std::max<I>(1,lo):lo;a<=hi;++a){
                if(std::gcd(a,b)!=1)continue;
                I Q=A*a*a+2*B*a*b+C*b*b;
                if(Q<21609)continue;
                assert(scale*Q<limit);
                V v{};for(int i=0;i<5;++i)v[i]=std::abs(a*p[i]+b*q[i]);
                std::sort(v.begin(),v.end());
                if(v[0]==0||std::adjacent_find(v.begin(),v.end())!=v.end())continue;
                ++count;
                if(!witness(v)){
                    ++failed;
                    #pragma omp critical
                    {for(I w:v)std::cerr<<w<<' ';std::cerr<<"no witness\n";}
                }
            }
        }
        if(ext)rext+=count;
        else if(count){rt+=count;++active;}
        else ++none;
    }
    std::cout<<"total "<<cap<<" degenerate "<<deg<<" <=12_no_residual "<<none<<" <=12_with_residual "<<active<<" extended "<<extended<<" no_centre "<<failcent<<" residual_regular "<<rt<<" residual_extended "<<rext<<" witness_fail "<<failed<<'\n';
    return failed||failcent;
}
