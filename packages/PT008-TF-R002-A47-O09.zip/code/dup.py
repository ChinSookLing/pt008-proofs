# TEST: duplication of residual U across all planes of a few W (q<=12 centres)
import json, random, sys, time
from fractions import Fraction as F
from wtable import int_kernel
from exactplanes import planes_exact
from level3 import best_centre
from rank1 import residual
random.seed(int(sys.argv[1])); t0 = time.time()
for shape, z1 in (("double", (2, -1, 0, 0, 0)), ("ones", (1, 1, 1, 1, 1))):
    rows = json.load(open("wbounds_%s.json" % shape))
    for r in random.sample(rows, 2):
        P = list(planes_exact(int_kernel([z1, r["z2"]]), F(r["T"])).values()); tot = 0; allU = set(); npl = 0
        for p, q in P:
            cols = [(p[i], q[i]) for i in range(5)]
            if any(c == (0, 0) for c in cols) or any(cols[i] == cols[j] or cols[i] == (-cols[j][0], -cols[j][1]) for i in range(5) for j in range(i + 1, 5)): continue
            m, cen = best_centre(int_kernel([p, q])); npl += 1
            for a, b in residual(p, q, m.numerator, m.denominator):
                U = tuple(a * x + b * y for x, y in zip(p, q))
                if any(u == 0 for u in U): continue
                tot += 1; allU.add(tuple(sorted(abs(u) for u in U)))
        print(shape, r["z2"], "planes", npl, "residual U (with multiplicity)", tot, "distinct speed multisets", len(allU), "%.0f s" % (time.time() - t0), flush=True)
