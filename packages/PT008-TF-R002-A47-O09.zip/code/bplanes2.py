# boundary-plane search: planes given by five pairwise non-parallel-up-to-sign columns c_i in Z^2 with max-norm <= R
# (U_i = <c_i, (a,b)>); saturated basis recomputed.  Report planes with no 2-D safe cell and run polar46 (TAIL 0) on them.
import itertools, json, sys, time
from math import gcd
from wtable import int_kernel
from poly45 import polygons, area2
import polar46
polar46.TAIL = 0
R = int(sys.argv[1]); t0 = time.time()
cols = []
for x in range(-R, R + 1):
    for y in range(-R, R + 1):
        if (x, y) == (0, 0): continue
        if (x, y) > (-x, -y): continue          # one of +-
        cols.append((x, y))
found = []; n = 0; stat = {}
for S in itertools.combinations(cols, 5):
    if any(a[0] * b[1] == a[1] * b[0] and (abs(a[0]) == abs(b[0]) and abs(a[1]) == abs(b[1])) for a, b in itertools.combinations(S, 2)): continue
    p = [c[0] for c in S]; q = [c[1] for c in S]
    pp, qq = int_kernel(int_kernel([p, q]))
    n += 1
    polys = polygons(pp, qq)
    if any(len(set(P)) >= 3 and area2(list(dict.fromkeys(P))) > 0 for k_, P in polys): continue
    kinds = sorted({("seg" if len(set(P)) == 2 else "pt") for k_, P in polys}) or ["EMPTY"]
    o = polar46.certify(pp, qq); stat[o["status"]] = stat.get(o["status"], 0) + 1
    rec = {"cols": S, "p": pp, "q": qq, "cells": kinds, "status": o["status"], "residual": o.get("residual"),
           "misses": [m[:3] for m in o.get("misses", [])][:5]}
    found.append(rec)
print("R=%d: planes %d ; boundary planes (no 2-D cell) %d ; polar46 statuses %s ; %.0f s" % (R, n, len(found), stat, time.time() - t0))
for r in found[:12]: print(r)
json.dump(found, open("bplanes2_R%d.json" % R, "w"))
