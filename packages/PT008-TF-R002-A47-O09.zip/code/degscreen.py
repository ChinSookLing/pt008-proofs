# screen random planes of the exact plane table for the degenerate branch:
#  (1) q<=12 centre search (as in level3); (2) for planes where it fails: exact cell analysis with A45's polygons():
#      some cell of positive area  <=>  a strict centre exists (any denominator); its vertex centroid is a rational
#      strict centre (margin computed exactly).  No 2-D cell  =>  boundary plane (segments/points only) or empty.
import json, random, sys, time
from fractions import Fraction as F
from wtable import int_kernel
from exactplanes import planes_exact
from level3 import best_centre
from poly45 import polygons, area2
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)
def exact_classify(p, q):
    polys = polygons(p, q); best = None; kinds = {"2d": 0, "segment": 0, "point": 0}
    for k, P in polys:
        Pu = list(dict.fromkeys(P))
        if len(Pu) >= 3 and area2(Pu) > 0:
            kinds["2d"] += 1
            cx = sum(v[0] for v in Pu) / len(Pu); cy = sum(v[1] for v in Pu) / len(Pu)
            m = min(dist(cx * pi + cy * qi) for pi, qi in zip(p, q)) - F(1, 6)
            if best is None or m > best: best = m
        elif len(Pu) >= 2: kinds["segment"] += 1
        else: kinds["point"] += 1
    return kinds, best
if __name__ == "__main__":
    random.seed(int(sys.argv[1])); NW = int(sys.argv[2]); PER = int(sys.argv[3]); TL = float(sys.argv[4])
    st = {"planes": 0, "excluded": 0, "q12_centre": 0, "q12_fail": 0, "fail_has_2d_cell": 0, "fail_boundary": 0, "fail_empty": 0}
    hist = {}; fails = []; t0 = time.time()
    for shape, z1 in (("double", (2, -1, 0, 0, 0)), ("ones", (1, 1, 1, 1, 1))):
        rows = json.load(open("wbounds_%s.json" % shape))
        for r in random.sample(rows, NW):
            P = list(planes_exact(int_kernel([z1, r["z2"]]), F(r["T"])).values())
            for p, q in random.sample(P, min(PER, len(P))):
                if time.time() - t0 > TL: break
                cols = [(p[i], q[i]) for i in range(5)]
                if any(c == (0, 0) for c in cols) or any(cols[i] == cols[j] or cols[i] == (-cols[j][0], -cols[j][1]) for i in range(5) for j in range(i + 1, 5)):
                    st["excluded"] += 1; continue
                st["planes"] += 1; m, cen = best_centre(int_kernel([p, q]))
                hist[str(m)] = hist.get(str(m), 0) + 1
                if m > 0: st["q12_centre"] += 1; continue
                st["q12_fail"] += 1; kinds, mb = exact_classify(p, q)
                if kinds["2d"]: st["fail_has_2d_cell"] += 1
                elif kinds["segment"] or kinds["point"]: st["fail_boundary"] += 1
                else: st["fail_empty"] += 1
                fails.append({"shape": shape, "p": p, "q": q, "kinds": kinds, "centroid_margin": str(mb)})
    print("seed %s: %s ; q<=12 margin histogram %s ; %.0f s" % (sys.argv[1], st, dict(sorted(hist.items(), key=lambda x: F(x[0]))), time.time() - t0))
    json.dump(fails, open("degscreen_%s.json" % sys.argv[1], "w"))
