# TEST: exact-ish maximal margin m*_P (LP over each safe cell, scipy, float) vs the q<=12 margin, and residual sizes
# 0.24*sqrt(D)/m^2 ~ #{primitive (a,b) mod +-: 4 m^2 Q < D}; also duplication of residual U across planes of one W.
import json, random, sys, time
import numpy as np
from fractions import Fraction as F
from scipy.optimize import linprog
from wtable import int_kernel
from exactplanes import planes_exact
from level3 import best_centre
from poly45 import polygons, area2
from rank1 import residual
def lp_margin(p, q):
    best = 0.0
    for k, P in polygons(p, q):
        Pu = list(dict.fromkeys(P))
        if len(Pu) < 3 or area2(Pu) == 0: continue
        A = []; b = []
        for i in range(5):
            # mu <= p_i x + q_i y - k_i - 1/6  ;  mu <= k_i + 5/6 - p_i x - q_i y
            A.append([-p[i], -q[i], 1]); b.append(-k[i] - 1 / 6)
            A.append([p[i], q[i], 1]); b.append(k[i] + 5 / 6)
        A += [[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0]]; b += [0, 1, 0, 1]
        r = linprog([0, 0, -1], A_ub=A, b_ub=b, bounds=[(None, None)] * 3, method="highs")
        if r.status == 0: best = max(best, -r.fun)
    return best
random.seed(int(sys.argv[1])); out = []; t0 = time.time()
for shape, z1 in (("double", (2, -1, 0, 0, 0)), ("ones", (1, 1, 1, 1, 1))):
    rows = json.load(open("wbounds_%s.json" % shape))
    for r in random.sample(rows, 10):
        P = list(planes_exact(int_kernel([z1, r["z2"]]), F(r["T"])).values()); U_all = []; tot = 0
        for p, q in random.sample(P, 40):
            cols = [(p[i], q[i]) for i in range(5)]
            if any(c == (0, 0) for c in cols) or any(cols[i] == cols[j] or cols[i] == (-cols[j][0], -cols[j][1]) for i in range(5) for j in range(i + 1, 5)): continue
            m, cen = best_centre(int_kernel([p, q])); mlp = lp_margin(p, q)
            D = (sum(x * x for x in p) * sum(x * x for x in q) - sum(x * y for x, y in zip(p, q)) ** 2)
            n12 = len(residual(p, q, m.numerator, m.denominator))
            out.append((shape, D, float(m), mlp, n12, 0.75 / np.pi * D ** 0.5 / float(m) ** 2, 0.75 / np.pi * D ** 0.5 / mlp ** 2))
print("planes %d (%.0f s)" % (len(out), time.time() - t0))
a = np.array([o[1:] for o in out], dtype=float)
print("D: median %.0f max %.0f ; q<=12 margin median %.4f min %.4f ; LP margin median %.4f min %.4f ; LP/q12 ratio median %.2f"
      % (np.median(a[:, 0]), a[:, 0].max(), np.median(a[:, 1]), a[:, 1].min(), np.median(a[:, 2]), a[:, 2].min(), np.median(a[:, 2] / a[:, 1])))
print("residual per plane (q<=12 centre): mean %.0f, max %.0f ; heuristic 0.24 sqrt(D)/m^2: mean %.0f ; with LP margin (heuristic): mean %.0f"
      % (a[:, 3].mean(), a[:, 3].max(), a[:, 4].mean(), a[:, 5].mean()))
json.dump(out, open("lpmargin_%s.json" % sys.argv[1], "w"))
