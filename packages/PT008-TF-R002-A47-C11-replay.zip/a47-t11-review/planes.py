import json, sys
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from math import gcd, isqrt
from pathlib import Path
import numpy as np
sys.path.insert(0, 'a47-o08-review/code')
from wtable import int_kernel, SHAPES
from exactplanes import reduce3

pairs = list(combinations(range(5), 2))
def wedge(a, b):
    return [int(a[i])*int(b[j])-int(a[j])*int(b[i]) for i,j in pairs]
def canon(w):
    d = gcd(*w)
    if next(x for x in w if x)<0: d=-d
    return tuple(x//d for x in w)
def table(path, name):
    return json.loads((Path('a47-o08-review/code') / (path+'_'+name+'.json')).read_text())

def keys(name):
    z1 = SHAPES[name]
    label = 'A' if name == 'double' else 'B'
    chair = {tuple(-x for x in k):(q,r) for k,q,r in json.loads(Path(f'z5-review/centres_{label}.json').read_text())['certified']}
    base = {canon(wedge(z1,r['z2'])): r for r in table('wtable', name)}
    assert base.keys() == chair.keys()
    margins = Counter()
    rows = []
    max_z3 = 0
    for r in table('wbounds',name):
        z2 = r['z2']
        key = canon(wedge(z1,z2))
        s,t = base[key]['S_basis']
        assert wedge(s,t) in (list(key),[-x for x in key])
        for q, nums in (chair[key],r['centre']):
            assert all(sum(a*b for a,b in zip(v,nums))%q == 0 for v in (s,t))
            assert all(6*min(x,q-x)>q for x in nums)
        q, nums = r['centre']
        m = Fraction(min(min(x,q-x) for x in nums),q)-Fraction(1,6)
        T = Fraction(7,12)/m**2
        assert T == Fraction(r['T']) and m == Fraction(r['m'])
        def dot(x,y): return sum(a*b for a,b in zip(x,y))
        a,b,d=dot(s,s),dot(s,t),dot(t,t)
        rho2=(5+Fraction(a*d-b*b,5))/4
        max_z3=max(max_z3, -((- (T+rho2).numerator)//(T+rho2).denominator)-1)
        margins[m] += 1
        rows.append((z2,T))
    print(name, 'centres', len(rows), 'margin histogram', dict(margins), 'max norm via saturated Babai',max_z3,flush=True)
    blocks=[]
    float_misses=float_extra=total=0
    for idx,(z2,T) in enumerate(rows):
        a,b,c = reduce3(int_kernel([z1,z2]))
        W = np.array([a,b,c],dtype=np.int64)
        G = W @ W.T
        g00,g01,g02 = map(int,G[0])
        _,g11,g12 = map(int,G[1])
        _,_,g22 = map(int,G[2])
        c00,c01,c02 = g11*g22-g12*g12, g02*g12-g01*g22, g01*g12-g02*g11
        c11,c12,c22 = g00*g22-g02*g02,g01*g02-g00*g12,g00*g11-g01*g01
        det = g00*c00+g01*c01+g02*c02
        A,B = T.numerator,T.denominator
        lim = [isqrt((A*x-1)//B) for x in (g00,g11,g22)]
        k = np.array(np.meshgrid(*(np.arange(-x,x+1,dtype=np.int64) for x in lim),indexing='ij')).reshape(3,-1)
        x,y,z = k
        positive = (x>0) | ((x==0) & ((y>0) | ((y==0) & (z>0))))
        k = k[:, positive & (np.gcd(np.gcd(x,y),z)==1)]
        x,y,z = k
        assert (3*max(lim))**2 * max(map(abs,(c00,c01,c02,c11,c12,c22)))*B < 2**63
        numerator = c00*x*x + c11*y*y + c22*z*z + 2*(c01*x*y+c02*x*z+c12*y*z)
        exact = numerator*B < A*det
        float_norm = np.einsum('in,ij,jn->n',k,np.linalg.inv(G.astype(float)),k)
        old = (float_norm<float(T)-1e-9) & (float_norm>1e-12)
        float_misses += np.count_nonzero(exact & ~old)
        float_extra += np.count_nonzero(old & ~exact)
        K = k[:,exact].T
        wb = np.array([wedge(b,c), [-x for x in wedge(a,c)],wedge(a,b)],dtype=np.int64)
        P = K @ wb
        assert np.max(np.abs(P),initial=0) <= 32767
        assert (np.gcd.reduce(P,axis=1)==1).all()
        first = P[np.arange(len(P)),np.argmax(P!=0,axis=1)]
        blocks.append((P*np.sign(first)[:,None]).astype('<i2'))
        total += len(K)
    P = np.concatenate(blocks); del blocks
    uniq = np.unique(P.view('V20').ravel())
    print(name,'incidences',total,'distinct',len(uniq),'float exclusions',float_misses,'float inclusions',float_extra,flush=True)
    return uniq
a=keys('double')
b=keys('ones')
np.union1d(a,b).tofile('a47-t11-review/planes.bin')
