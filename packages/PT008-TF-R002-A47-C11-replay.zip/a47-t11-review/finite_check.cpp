#include <algorithm>
#include <array>
#include <iostream>
#include <numeric>
#include <vector>

using Input=std::array<int,5>;

bool safe(const Input& u,int n,int d) {
    for (int speed:u) {
        int r=speed*n%d;
        if(6*std::min(r,d-r)<d) return false;
    }
    return true;
}

int main() {
    constexpr int limit=21608;
    std::vector<std::array<int,2>> g1,h6;
    for(int d=2;d<=18;++d)
        for(int n=1;2*n<=d;++n)
            if(std::gcd(n,d)==1) (d<=6?g1:h6).push_back({n,d});
    std::array<std::array<long long,4>,2> counts{};
    for(int a=1;5*a*a<=limit;++a)
    for(int b=a+1;a*a+4*b*b<=limit;++b)
    for(int c=b+1;a*a+b*b+3*c*c<=limit;++c)
    for(int d=c+1;a*a+b*b+c*c+2*d*d<=limit;++d) {
        const int partial=a*a+b*b+c*c+d*d;
        const int common=std::gcd(std::gcd(a,b),std::gcd(c,d));
        for(int e=d+1;partial+e*e<=limit;++e) {
            if(std::gcd(common,e)!=1) continue;
            const Input u{a,b,c,d,e};
            auto& cnt=counts[partial+e*e>600];
            ++cnt[0];
            if(std::any_of(g1.begin(),g1.end(),[&](auto t){return safe(u,t[0],t[1]);})) continue;
            ++cnt[1];
            if(std::any_of(h6.begin(),h6.end(),[&](auto t){return safe(u,t[0],t[1]);})) continue;
            ++cnt[2];
            bool found=false;
            for(int speed:u) {
                for(int k=0;k<speed && !found;++k) found=safe(u,6*k+1,6*speed);
                if(found) break;
            }
            if(!found) {for(int x:u) std::cout<<x<<' '; std::cout<<"no safe time\n";return 1;}
            ++cnt[3];
        }
    }
    for(auto c:counts) {
        for(auto n:c) std::cout<<n<<" ";
        std::cout<<'\n';
    }
}
