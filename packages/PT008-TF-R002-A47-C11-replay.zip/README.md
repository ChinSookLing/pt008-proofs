# PT-008 · A47-C11 · 六跑者幾何 Z=5 獨立重放

從解壓後根目錄執行（Python 3 + NumPy、C++17 + OpenMP）。平面檔約 199 MB，由程式重建。

    OPENBLAS_NUM_THREADS=1 python3 a47-t11-review/planes.py
    sha256sum a47-t11-review/planes.bin
    g++ -O3 -fopenmp -std=c++17 a47-t11-review/replay.cpp -o replay
    ./replay
    g++ -O3 -std=c++17 a47-t11-review/finite_check.cpp -o finite_check
    ./finite_check

投影枚舉以整數伴隨矩陣判定。planes.py 另以浮點式做對照，該值不參與取捨。平面鍵是本原帶號標準化的二階普呂克座標。replay.cpp 直接由鍵重建飽和平面基，逐平面核對 Gram 行列式。模 d 下掃描基底的兩個係數等同於掃描平面上的分母 d 中心。平方根的初估經整數修正；二次型枚舉含閉門檻 21609 與嚴格的剩餘上界。有限補段獨立覆蓋所有正、互異、本原且範數平方至多 21608 的五元組。

尾部與有限補段的時間見證均重新產生並逐項核對。兩者的備援枚舉只需使用各速度的左安全端點：任一非空共同安全集合在 [0,1] 有一個最左端點，該點必是至少一個閉安全弧的左端點。原 Hesper 包的未附處置檔未作檔案雜湊比對，結果由本重放獨立重建。O09 的等號與完備性論證適用。此證書範圍為 A47 幾何 Z=5 分支。
