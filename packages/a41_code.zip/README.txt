A41 Z=11 tail (|U|^2>=21609), wedge^2<=521, shapes A=(3,1,1,0,0), B=(2,2,1,1,1). Hesper, WEB OFF.
Replay: python3 bound.py 11; bash run.sh A 3,1,1,0,0; bash run.sh B 2,2,1,1,1; python3 neon_rules.py planes_A.tsv; python3 neon_rules.py planes_B.tsv
Expect A: planes 107752 closed 91960 resid planes 15792 resid inputs 4294272 max|U|^2 1247581 ALL PASS
Expect B: planes 110472 closed 97764 resid planes 12708 resid inputs 868296 max|U|^2 220005 ALL PASS
Closed planes use Lean lemmaT_T6 (commit d2128613), rounding floor(s+1/2); cert does no rounding. Residual times explicit rationals.
