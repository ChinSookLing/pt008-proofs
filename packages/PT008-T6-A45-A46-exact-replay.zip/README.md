# PT-008 T6 A45 及 A46 精確重放補件

此補件整理既存的獨立驗算原碼和留存輸出。原作者證書 ZIP 另取，保持原字節。環境為 C++17 與 zlib 開發函式庫，A45 例外重放另需 Python 3.10+ 和 NumPy。

## A45 上段（729 ≤ D ≤ 4630）

1. 先解壓 a45_t01.zip 到工作根目錄，再將 a45_t01_certs.zip 內 78 份 r_s*_cert.tsv.gz 解至同根的 certs/。在 certs/ 中用原 SHA256SUMS_certs 檢查 78 項。
2. 將本補件 A45/ 的 CPP、INC 和 PY 檔放在工作根目錄。在根目錄編譯及執行。

    g++ -O3 -std=c++17 verify_certs.cpp -lz -o verify_certs
    ./verify_certs 1 78 > certs-verified.tsv 2> cert-exceptions.tsv
    python3 compare_cert_outputs.py
    python3 review_all_exceptions.py

3. C++ 驗算不讀 Hesper 枚舉程式，從約化基界重新列舉且逐批比對完整平面鍵。SPEC 及 POLY 在 C++ 驗算。Python 補驗 R37/ FULL；其精確路徑沿用原 t01.py 的有理胞與逐點取時，並核對輸出。
4. 批表比對應給 16,901,376 張平面且 84,956 筆例外位置／中心全合。最後應有 “Exact replay complete, residual points 56504”。留存的 certs-verified.tsv 與 all-exceptions.log 在本補件 A45/。count_upper.cpp 可按同樣批號另重列計數。輸出中的計時視環境變動。

## A46（1 ≤ D ≤ 744）

1. 解壓 a46_t01.zip，驗 SHA256SUMS_A46。證書分片原件在根目錄，獨立 C++ 驗算需要 certs/ 子目錄，將 r_s*_cert.tsv.gz 複製或連結到 certs/。
2. 將本補件 A46/ 的 CPP 與 INC 放在工作根目錄，編譯執行。

    g++ -O3 -std=c++17 verify_certs.cpp -lz -o verify_certs
    ./verify_certs 1 31 > exact-counts.tsv 2> cert-exceptions.tsv
    python3 exact46.py

3. 前兩個輸出可逐字比對本補件留存檔。exact46.py 是 Hesper 原包內的獨立精確計算路徑，核對全量及 R37 胞族，應得 bad 0。
