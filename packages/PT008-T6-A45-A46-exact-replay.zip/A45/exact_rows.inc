using Wide = __int128_t;
using Vec = std::array<long long,5>;
struct Point { long long x,y,d; };
static long long dot(const Vec& a,const Vec& b) {
    long long x=0; for(int j=0;j<5;++j) x+=a[j]*b[j]; return x;
}

static bool single_cell(const Vec& p,const Vec& q,const Vec& k) {
    std::array<Point,40> vertices;
    int n=0;
    for(int i=0;i<5;++i) for(int j=i+1;j<5;++j) {
        const auto m=p[i]*q[j]-p[j]*q[i];
        if(!m) continue;
        for(int ci : {1,5}) for(int cj : {1,5}) {
            const auto u=6*k[i]+ci,v=6*k[j]+cj;
            Point pt{(u*q[j]-v*q[i]),(p[i]*v-p[j]*u),6*m};
            if(pt.d<0) {pt.x=-pt.x;pt.y=-pt.y;pt.d=-pt.d;}
            bool feasible=true;
            for(int l=0;l<5;++l) {
                const auto a=6*(p[l]*pt.x+q[l]*pt.y);
                if(a<(6*k[l]+1)*pt.d || a>(6*k[l]+5)*pt.d) {feasible=false;break;}
            }
            if(feasible) vertices[n++]=pt;
        }
    }
    if(n<3) return false;
    bool has_edge=false;
    for(int i=0;i<5;++i) {
        long long low=0,high=0,ld=1,hd=1;
        const Point* first[2]{};
        bool edge=false;
        for(int j=0;j<n;++j) {
            const auto& v=vertices[j];
            const auto a=p[i]*v.x+q[i]*v.y;
            if(j==0 || a*ld<low*v.d) {low=a;ld=v.d;}
            if(j==0 || a*hd>high*v.d) {high=a;hd=v.d;}
            for(int side=0;side<2;++side) {
                if(6*a!=(6*k[i]+1+4*side)*v.d) continue;
                if(!first[side]) first[side]=&v;
                else if(first[side]->x*v.d!=v.x*first[side]->d || first[side]->y*v.d!=v.y*first[side]->d) edge=true;
            }
        }
        if(!edge) continue;
        has_edge=true;
        Wide w=Wide(high)*ld-Wide(low)*hd, d=Wide(ld)*hd;
        long long f=0;
        for(int j=0;j<5;++j) {auto v=q[i]*p[j]-p[i]*q[j]; f+=v*v;}
        if(w<=0 || Wide(f)*d*d>Wide(21609)*w*w) return false;
    }
    return has_edge;
}

static void verify_batch(int s,const std::vector<Key>& expected) {
    const std::string fn="certs/r_s"+std::to_string(s)+"_cert.tsv.gz";
    gzFile file=gzopen(fn.c_str(),"rb");
    if(!file) throw std::runtime_error("Cannot open "+fn);
    std::array<long long,4> stage{};
    std::vector<Key> seen;
    char buf[512];
    while(gzgets(file,buf,sizeof buf)) {
        long long d,n,x,y; char label[8]; Vec p,q;
        const int got=sscanf(buf,"%lld,%lld,%lld,%lld,%lld\t%lld,%lld,%lld,%lld,%lld\t%lld\t%lld\t%lld\t%lld\t%7s",
            &p[0],&p[1],&p[2],&p[3],&p[4],&q[0],&q[1],&q[2],&q[3],&q[4],&d,&n,&x,&y,label);
        auto fail=[&](const char* error){throw std::runtime_error(std::string(error)+" "+buf);};
        if(got!=15 || (n!=60 && n!=240) || x<0 || y<0 || x>=n || y>=n) fail("parse");
        for(int i=0;i<5;++i) if(std::abs(p[i])>8 || std::abs(q[i])>69) fail("coordinate bound");
        const long long pp=dot(p,p),qq=dot(q,q),pq=dot(p,q);
        if(pp!=s || pp>qq || 2*std::abs(pq)>pp || pp*qq-pq*pq!=d ||
            d<729 || d>4630 || 2*p[0]+p[1]+p[2]+p[3] || 2*q[0]+q[1]+q[2]+q[3]) fail("basis");
        Key key; int idx=0,g=0; Vec k{};
        long long anum=0,aden=1;
        for(int i=0;i<5;++i) {
            for(int j=i+1;j<5;++j) {const auto m=p[i]*q[j]-p[j]*q[i];g=std::gcd(g,int(m));key[idx++]=m;}
            const auto t=p[i]*x+q[i]*y;
            const auto r=(t%n+n)%n;
            k[i]=(t-r)/n;
            const auto margin=6*std::min(r,n-r)-n, norm=p[i]*p[i]+q[i]*q[i];
            if(margin<=0 || norm==0) fail("center");
            if(i==0 || margin*margin*aden<anum*norm) {anum=margin*margin;aden=norm;}
        }
        if(g!=1) fail("saturation");
        if(key<Key{}) for(auto& v:key) v=-v;
        seen.push_back(key);
        const std::string step=label;
        if(step=="SPEC") {
            const Wide num=Wide(86436)*anum,den=Wide(36)*n*n*aden;
            const Wide a=num-pp*den,b=num-qq*den,c=pq*den;
            if(a<0 || b<0 || a*b<c*c) fail("SPEC");
            ++stage[0];
        } else if(step=="POLY") {
            if(!single_cell(p,q,k)) fail("POLY");
            ++stage[1];
        } else if(step=="R37") {
            std::cerr<<buf;
            ++stage[2];
        } else if(step=="FULL") {
            std::cerr<<buf;
            ++stage[3];
        } else fail("unknown decision");
    }
    if(gzclose(file)!=Z_OK) throw std::runtime_error("gzip completion");
    std::sort(seen.begin(),seen.end());
    if(seen!=expected) throw std::runtime_error("certificate plane set mismatch: "+fn);
    for(auto count:stage) std::cout<<"\t"<<count;
}
