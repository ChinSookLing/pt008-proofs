import ast, concurrent.futures, gzip, math, re, sys, types
from collections import Counter
from fractions import Fraction
from pathlib import Path

def load_original():
    stub=types.ModuleType('numba')
    stub.njit=lambda **kwargs: lambda function:function
    sys.modules['numba']=stub
    original=sys.argv
    sys.argv=['t01.py','1','729','4630','unused']
    module=types.ModuleType('candidate')
    exec(compile(Path('t01.py').read_text().rsplit('\nmain()',1)[0],'t01.py','exec'),module.__dict__)
    sys.argv=original
    return module

def task(row):
    p,q,d,stage,n,x,y,mx,count=row
    result,data=original.slow_path(p,q,(Fraction(x,n),Fraction(y,n)))
    assert result==stage,(row,result,data)
    assert data==(mx,count) if stage=='FULL' else data==mx,(row,result,data)
    return count

original=load_original()
if __name__=='__main__':
    counts=Counter(); tasks={}; keys=set()
    with open('exceptions.txt') as stream, gzip.open('exc_vertices.tsv.gz','rt') as vertices:
        for e, v in zip(stream,vertices,strict=True):
            e=ast.literal_eval(re.sub(r'Fraction\((-?\d+), (\d+)\)',r'(\1,\2)',e))
            stage,p,q,d,info=e
            ps,qs,ds,vs,centre,rest=v.rstrip('\n').split('\t')
            assert ps==','.join(map(str,p)) and qs==','.join(map(str,q)) and int(ds)==d and vs==stage
            n,x,y=map(int,centre.split(','))
            assert n in (60,240) and 0<=x<n and 0<=y<n
            assert sum(x*y for x,y in zip(p,original.Z1))==sum(x*y for x,y in zip(q,original.Z1))==0
            minors=tuple(p[i]*q[j]-p[j]*q[i] for i in range(5) for j in range(i+1,5))
            assert math.gcd(*minors)==1 and sum(m*m for m in minors)==d and 729<=d<=4630
            key=min(minors,tuple(-m for m in minors))
            assert key not in keys
            keys.add(key)
            s=sum(x*x for x in p); qq=sum(x*x for x in q); pq=sum(x*y for x,y in zip(p,q))
            assert s<=qq and 2*abs(pq)<=s
            assert all(z!=(0,0) for z in zip(p,q)) and len({min((a,b),(-a,-b)) for a,b in zip(p,q)})==5
            max_vertex=0
            for item in rest.split(';'):
                coords,value=item.split(':')
                a,b=map(Fraction,coords[1:-1].split(','))
                w=Fraction(value)
                assert w==original.fval(p,q,a,b)
                max_vertex=max(max_vertex,w)
            assert max_vertex>21609
            mx,count=(Fraction(*info[0]),info[1]) if stage=='FULL' else (Fraction(*info) if isinstance(info,tuple) else Fraction(info),0)
            counts[s,stage]+=1; counts[s,'resid']+=count
            if stage=='FULL':
                key=('FULL',tuple(p),tuple(q))
            else:
                rows=tuple(sorted(min((a,b),(-a,-b)) for a,b in zip(p,q)))
                key=(stage,rows,Fraction(x,n),Fraction(y,n))
            if key in tasks:
                assert tasks[key][-2:]==(mx,count)
            else:
                tasks[key]=(p,q,d,stage,n,x,y,mx,count)
    import csv
    totals=Counter()
    with open('batch_stats.tsv') as src:
        for k,row in enumerate(csv.DictReader(src,delimiter='\t'),1):
            r={key:int(value) for key,value in row.items() if key!='max_poly_vertex_f'}
            assert r['S']==k and r['DMIN']==729 and r['DMAX']==4630
            assert r['planes']==sum(r[t] for t in ('spectral','poly','r37','full'))
            assert not (r['fail'] or r['nocell'] or r['amb_exact'])
            assert counts[k,'R37']==r['r37'] and counts[k,'FULL']==r['full'] and counts[k,'resid']==r['full_resid']
            totals.update({j:r[j] for j in ('pairs','planes','spectral','poly','r37','full','full_resid')})
    assert k==78
    print('All exception records and batch stats verified:',dict(totals),flush=True)
    print('Starting exact exception replay:',len(tasks),flush=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=6) as ex:
        count=0
        for idx,k in enumerate(ex.map(task,tasks.values(),chunksize=24),1):
            count+=k
            if idx%300==0: print('Replayed',idx,'residual points',count,flush=True)
    print('Exact replay complete, residual points',count)
