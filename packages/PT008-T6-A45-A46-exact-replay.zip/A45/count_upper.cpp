#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <vector>

using Vector = std::array<int16_t, 5>;
using Key = std::array<int16_t, 10>;

int main(int argc, char** argv) {
    const int first = argc > 1 ? std::stoi(argv[1]) : 1;
    const int last = argc > 2 ? std::stoi(argv[2]) : 78;
    const int d_lo = 729, d_hi = 4630;
    for (int s = first; s <= last; ++s) {
        const int limit = d_hi / s + s / 4 + 1;
        const int r = static_cast<int>(std::sqrt(limit));
        std::vector<Vector> qs, ps;
        std::vector<int> norms;
        for (int j = -r; j <= r; ++j)
            for (int k = -r; k <= r; ++k)
                for (int l = -r; l <= r; ++l) {
                    const int sum = j + k + l;
                    if (sum % 2 || sum > 0) continue;
                    const int i = -sum / 2;
                    if (i == 0 && (j < 0 || (j == 0 && (k < 0 || (k == 0 && l < 0))))) continue;
                    const int norm4 = i*i+j*j+k*k+l*l;
                    if (norm4 > limit) continue;
                    const int cap = static_cast<int>(std::sqrt(limit-norm4));
                    for (int m = norm4 == 0 ? 1 : -cap; m <= cap; ++m) {
                        const int norm = norm4 + m*m;
                        if (norm < s) continue;
                        const Vector v{int16_t(i),int16_t(j),int16_t(k),int16_t(l),int16_t(m)};
                        qs.push_back(v); norms.push_back(norm);
                        if (norm == s) ps.push_back(v);
                    }
                }
        std::vector<Key> keys;
        for (const auto& p : ps) {
            for (size_t idx = 0; idx < qs.size(); ++idx) {
                const auto& q = qs[idx];
                int dot = 0;
                for (int j = 0; j < 5; ++j) dot += p[j]*q[j];
                if (2*std::abs(dot) > s) continue;
                const int d = s*norms[idx] - dot*dot;
                if (d < d_lo || d > d_hi) continue;
                bool ok = true;
                int gcd = 0, n = 0;
                Key key;
                for (int j = 0; j < 5; ++j) {
                    if (!p[j] && !q[j]) ok = false;
                    for (int k = j+1; k < 5; ++k) {
                        if ((p[j]==p[k] && q[j]==q[k]) || (p[j]==-p[k] && q[j]==-q[k])) ok = false;
                        const int minor = p[j]*q[k] - p[k]*q[j];
                        key[n++] = minor;
                        gcd = std::gcd(gcd,minor);
                    }
                }
                if (!ok || gcd!=1) continue;
                if (key < Key{}) for (auto& v : key) v = -v;
                keys.push_back(key);
            }
        }
        const auto pairs = keys.size();
        std::sort(keys.begin(),keys.end());
        const auto planes = std::unique(keys.begin(),keys.end()) - keys.begin();
        std::cout << s << "\t" << pairs << "\t" << planes << std::endl;
    }
}
