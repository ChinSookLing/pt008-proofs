import csv
import gzip
from collections import Counter

with open('certs-verified.tsv') as actual, open('batch_stats.tsv') as baseline:
    expected=csv.DictReader(baseline,delimiter='\t')
    totals=Counter()
    for line,row in zip(actual,expected,strict=True):
        fields=('S','pairs','planes','spectral','poly','r37','full')
        counts=tuple(map(int,line.split()))
        assert counts==tuple(int(row[f]) for f in fields),(row,counts)
        totals.update(dict(zip(fields[1:],counts[1:])))
    assert counts[0]==78
    print(dict(totals))
with open('cert-exceptions.tsv') as actual, gzip.open('exc_vertices.tsv.gz','rt') as pairs:
    indexed=set()
    for expected in pairs:
        p,q,d,stage,center,_=expected.rstrip('\n').split('\t')
        indexed.add((p,q,d,*center.split(','),stage))
    assert len(indexed)==84956
    for line in actual:
        indexed.remove(tuple(line.rstrip('\n').split('\t')))
    assert not indexed
print('All 78 batches, all 84956 exception stage and center records match.')
